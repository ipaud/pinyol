-- view: the picture of the game, all of it made of mesh() calls and a few quads. y up in the game, y down for mesh(); the camera sits behind
-- and above the fox and looks along +z (mesh() has no camera turn: the horizon is where `cy` is).
local Models = require("models")
local M = {}

M.FOCAL, M.CX, M.CY = 213, 240, 112
M.CAM_H, M.CAM_BACK = 58, 112
M.snap, M.dither, M.fog = true, true, true -- the tricks "Cómo funciona" lets the player switch

local LIGHT = {dir = {-0.45, -0.75, -0.5}, ambient = 0.27, gain = 0.42} -- (128 is a texture as it is; 255, twice as bright)
local models = {}

local function ground_y() return M.CAM_H end -- the ground is this far below the camera, in mesh() terms

function M.init()
  local s
  -- the path: slabs of 40, getting longer toward the horizon (one picture each: far ones stretch, as a PlayStation's did)
  -- the path in three runs, each with its own darkness baked into its picture and no light at all (the fog of this look is the picture's)
  s = Models.solid(); s:floor(-46, 46, 0, 40, 0); s:floor(-46, 46, 40, 80, 0); models.path_near = s:build()
  s = Models.solid(); s:floor(-46, 46, 80, 120, 0); s:floor(-46, 46, 120, 160, 0); s:floor(-46, 46, 160, 200, 0); models.path_mid = s:build()
  s = Models.solid()
  local z = 200
  for _, len in ipairs({80, 160, 320, 640}) do s:floor(-46, 46, z, z + len, 0) z = z + len end
  models.path_far = s:build()
  -- a row of three trees, spaced 140 apart, one side (the left; the right is the same mirrored by x). Smaller than they were: the near ones are
  -- the most of the pixels, and each is cut away when it comes too close (the mesh's `near`)
  s = Models.solid()
  local H, W, J = {38, 48, 34}, {30, 40, 26}, {0, 6, -5} -- each tree its own height, width and place across
  for i = 0, 2 do s:box(7, H[i + 1], 7, J[i + 1], H[i + 1] / 2, i * 140 + J[i + 1]) end
  models.trunks = s:build()
  s = Models.solid()
  for i = 0, 2 do s:pyramid(W[i + 1], W[i + 1], H[i + 1] + 2, J[i + 1], H[i + 1] - 8, i * 140 + J[i + 1]) end
  models.leaves = s:build()
  s = Models.solid(); s:box(18, 18, 18, 0, 9, 0); models.crate = s:build()
  s = Models.solid(); s:floor(-46, 46, 0, 40, 0.5); models.pit = s:build()
  s = Models.solid(); s:floor(-14, 14, 0, 14, 0.5); models.spike = s:build()
end

local FADE, FADE_FAR = {260, 980}, {300, 1400}
local OPTS, POS = {pos = {0, 0, 0}, focal = M.FOCAL, cx = M.CX, cy = M.CY, near = 20, light = LIGHT}, {0, 0, 0}
local function call(model, tex, x, y, z, rot, opts) -- (one table of options reused: mesh() reads it at once, and a call a part makes 15 times a frame)
  local o = OPTS
  o.pos = POS
  POS[1], POS[2], POS[3] = x, y, z
  o.rot, o.scale, o.light, o.fade, o.near = rot, nil, LIGHT, M.fog and FADE or nil, 20
  o.snap, o.dither = M.snap, M.dither
  if opts then for k, v in pairs(opts) do o[k] = v end end
  return mesh(model, tex, o)
end
M.call = call

-- a point of the game (x, y up, z) on the screen, its size (1 at 100 away), or nil behind the camera
function M.project(x, y, z, cam)
  local rz = z - cam.z
  if rz < 24 then return nil end
  local k = M.FOCAL / rz
  return M.CX + (x - cam.x) * k, M.CY + (M.CAM_H - y) * k, k
end

-- The sky, the sun, the hills and the ground beside the way never change: they are painted once, at half the screen's size, on a picture that is the
-- PPU's background layer (drawn for next to nothing, and doubled). Drawing them each frame took most of the strips' time on the console (the polygons
-- of the hills alone 29 ms), and copying a full-size picture with img took more. Painted again when the dither is switched.
local backdrop_dither = nil

local function paint_backdrop()
  canvas("BACKDROP", 240, 160); target("BACKDROP")
  local hy = M.CY // 2
  grad(0, 0, 240, hy - 48, 0x0E1C34, 0x4A3468, {dither = M.dither})
  grad(0, hy - 48, 240, 48, 0x4A3468, 0xF4934C, {dither = M.dither})
  -- the sun, low, behind the far hills: a ring of a deeper orange and its disc
  circ(165, hy - 17, 23, 0xF2763A, true)
  circ(165, hy - 17, 18, 0xFFC468, true)
  circ(165, hy - 17, 13, 0xFFE59A, true)
  -- distant hills: three dark teal ridges, nearer ones darker
  for layer = 1, 3 do
    local c = ({0x2E4A5A, 0x203A48, 0x142A36})[layer]
    local base = hy + layer + 2
    local pts = {0, base}
    for x = 0, 240, 20 do pts[#pts + 1] = x; pts[#pts + 1] = base - 7 - layer * 3 - (((x * 2) * (7 + layer * 3) + layer * 53) % 17) // 2 end
    pts[#pts + 1] = 240; pts[#pts + 1] = base + 1
    pts[#pts + 1] = 0; pts[#pts + 1] = base + 1
    poly(pts, c, true)
  end
  -- the ground beside the way: bands of a mossy dark, lighter toward the horizon
  local bands = {0x1E3C3C, 0x183238, 0x142A36, 0x102230}
  local y0 = hy + 2
  for i, c in ipairs(bands) do
    local y1 = i == #bands and 160 or y0 + math.floor((160 - hy - 2) * ({0.12, 0.3, 0.6})[i])
    rect(0, y0, 240, y1 - y0, c)
    y0 = y1
  end
  target()
  bg(3, {image = "BACKDROP"})
  backdrop_dither = M.dither
end

function M.sky(t)
  if backdrop_dither ~= M.dither then paint_backdrop() end
end

function M.haze() end -- (a warm band over the horizon was here: two milliseconds a frame on the console, and the backdrop has the glow)

-- the world seen from `cam` ({x, z}): the rolling path and the two rows of trees
function M.path(cam)
  local oz = -(cam.z % 40) + 40
  local bare = {light = false, fade = false}
  return call(models.path_near, "TEX_PATH", -cam.x, ground_y(), oz, {0, 0, 0}, bare)
       + call(models.path_mid, M.fog and "TEX_PATH_1" or "TEX_PATH", -cam.x, ground_y(), oz, {0, 0, 0}, bare)
       + call(models.path_far, M.fog and "TEX_PATH_2" or "TEX_PATH", -cam.x, ground_y(), oz, {0, 0, 0}, bare)
end

function M.trees(cam)
  local gz = ground_y()
  local toff = cam.z % 140
  local n = 0
  for _, side in ipairs({-1, 1}) do
    local x = side * 84 - cam.x
    n = n + call(models.trunks, "TEX_BARK", x, gz, -toff + 40, {0, 0, 0}, {near = 78})
    n = n + call(models.leaves, "TEX_LEAF", x, gz, -toff + 40, {0, 0, 0}, {near = 78})
  end
  return n
end

-- the things on the path, far to near: a crate, a pit, a spike trap, a fruit (a sprite that turns)
function M.thing(it, cam, t)
  if it.z - cam.z < 24 or it.z - cam.z > 520 then return 0 end
  if it.k == "crate" then return call(models.crate, "TEX_CRATE", it.x - cam.x, ground_y(), it.z - cam.z, {0, 0, 0}) end
  if it.k == "pit" then return call(models.pit, "TEX_PIT", -cam.x, ground_y(), it.z - cam.z - 0, {0, 0, 0}, {light = false, fade = M.fog and FADE_FAR or nil}) end
  if it.k == "spike" then return call(models.spike, "TEX_SPIKE", it.x - cam.x - 0, ground_y(), it.z - cam.z, {0, 0, 0}) end
  if it.k == "fruit" then
    local sx, sy, k = M.project(it.x, it.y + 6, it.z, cam)
    if not sx then return 0 end
    local bob = math.sin(t / 9 + it.z) * 2
    local w = math.max(0.15, 0.52 * k * (1 + 0.12 * math.sin(t / 7 + it.z)))
    img("SPR_FRUIT", sx - 8 * w, sy - 8 * w + bob, {scale_x = w, scale_y = w})
    return 0
  end
  return 0
end

-- a soft dark patch under the fox, smaller the higher it is
function M.shadow(fox, cam)
  local x0, x1 = fox.x - 7 + (fox.y * 0.0), fox.x + 7
  local s = math.max(0.45, 1 - fox.y / 70)
  local w = 9 * s
  local a, b, c, d = {M.project(fox.x - w, 0, fox.z - w * 1.3, cam)}, {M.project(fox.x + w, 0, fox.z - w * 1.3, cam)},
                     {M.project(fox.x + w, 0, fox.z + w * 1.3, cam)}, {M.project(fox.x - w, 0, fox.z + w * 1.3, cam)}
  if a[1] and c[1] then quad("TEX_FOXD", a[1], a[2], b[1], b[2], c[1], c[2], d[1], d[2], {alpha = 0.5}) end
end

return M
