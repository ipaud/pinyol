-- Nube 6, the iaia's synth (a Juno-6 under a sheet in the desván): four chords, one a bar and round again, played
-- by three of the studio's synth voices (tracks 14 to 16). A step lit below strikes the chord again; between two
-- lit steps it holds. BRILLO opens the filter; the switch: saw (strings) or square (organ).
-- ponytail: silent on a firmware without the studio (every Cirera has it); the chords follow their own four bars,
-- not FRUITERA's sections.
local N = {}
N.panel = require("nube_panel")
local P = N.panel

N.TRACK0 = 14
N.CHORDS = {                                           -- close voicings: each moves little to the next
  {name = "LAm", notes = {57, 60, 64}},
  {name = "DO", notes = {55, 60, 64}},
  {name = "REm", notes = {57, 62, 65}},
  {name = "MIm", notes = {55, 59, 64}},
  {name = "FA", notes = {57, 60, 65}},
  {name = "SOL", notes = {55, 59, 62}},
}
N.SOL = 6
N.focus = "n1"

-- The keyboard: four voices on instrument(), all rooted at A3 (220 Hz, whole cycles in a second, so a held note loops
-- without a click). VOZ is the Golpe pad that holds a recording, else its UH.
N.VOICES = {"PIANO", "ÓRGANO", "CUERDAS", "VOZ"}
N.SHORT = {"PIA", "ORG", "CUE", "VOZ"}
local SOUNDS = {
  NB_PIA = {wave = "fm", freq = 220, fm_ratio = 1, fm_index = 1.6, sustain = 0.05, decay = 1.4, volume = 0.7},
  NB_ORG = {wave = "square", freq = 220, duty = 0.5, sustain = 1, decay = 0, lowpass = 0.55, volume = 0.45},
  NB_STR = {wave = "saw", freq = 220, sustain = 1, decay = 0, lowpass = 0.4, volume = 0.45},
}
local ADSR = {
  {a = 0.003, d = 0.4, s = 0.3, r = 0.35},
  {a = 0.01, d = 0.05, s = 0.9, r = 0.08},
  {a = 0.18, d = 0.2, s = 0.8, r = 0.5},
  {a = 0.005, d = 0.1, s = 0.8, r = 0.15},
}
local inst, inst_for = {}, nil
local ROOT_NAMES = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"}

function N.make_sounds()
  if not instrument then return end
  for id, def in pairs(SOUNDS) do sound(id, def) end
  inst[1] = instrument{sample = "NB_PIA", root = "A3", adsr = ADSR[1], gain = 0.9, reverb = 0.25}
  inst[2] = instrument{sample = "NB_ORG", root = "A3", loop = true, adsr = ADSR[2], gain = 0.8, reverb = 0.15}
  inst[3] = instrument{sample = "NB_STR", root = "A3", loop = true, adsr = ADSR[3], gain = 0.8, reverb = 0.4}
end

local function voice_inst()                            -- VOZ follows Golpe's recording, made again when it changes
  local v = N.patch.voice
  if v < 4 then return inst[v] end
  local pad = 4
  for i = 1, 4 do if golpe.pads[i].rec then pad = i end end
  local root = golpe.pads[pad].rec and golpe.pads[pad].root or 57           -- the note it was sung at, else an A
  local key = pad .. ":" .. (golpe.recorded or 0)
  if inst_for ~= key or not inst[4] then
    inst[4] = instrument{sample = "PAD" .. pad, root = ROOT_NAMES[root % 12 + 1] .. (root // 12 - 1), adsr = ADSR[4], gain = 0.9, reverb = 0.2}
    inst_for = key
  end
  return inst[4]
end

-- A note now. The handle is kept to let it go; the music's volume and the mixer's channel 8 apply.
local function note_on(midi)
  local i = voice_inst()
  if not i then return nil end
  local vol = (seq.mute and 0 or 1) * seq.volume * (mesa and mesa.gain(8) or 1)
  return {midi = midi, i = i, h = i:play(440 * 2 ^ ((midi - 69) / 12), 0.85 * vol)}   -- (a number is Hz, not MIDI)
end
local function note_off(n) if n and n.i and n.h then n.i:release(n.h) end end

function N.reset()
  if N.accident and N.accident.mic then mic(false) end
  N.accident, N.tune_pending, N.tune_done, N.detune = nil, false, false, 0
  N.slots = {0, 0, 0, 0}                               -- silent until someone plays it: under the sheet
  N.steps = {}
  for s = 1, 16 do N.steps[s] = s == 1 and 1 or 0 end
  N.patch = {bright = 0.45, square = false, voice = 1, arp = 0}
  N.mel = {}                                           -- the recorded melody: a MIDI note a step, 0 none
  for k = 1, 16 do N.mel[k] = 0 end
  N.rec = false
  N.held, N.auto, N.touch_note, N.touch_tick = {}, {}, nil, 0
  N.bar, N.queued, N.sent = nil, nil, {}
end

local function slot_at(bar) return (math.max(bar or 1, 1) - 1) % 4 + 1 end
function N.now() return N.bar and slot_at(N.bar) or nil end

-- The arpeggiator: the chord's three notes one a step in turn (SUBE: 1 2 3; OCHO: the same, a note every other step;
-- ZIGZ: 1 2 3 2), each on its own voice; the steps below are not read while it runs.
local ARP_ORDER = {{1, 2, 3}, {1, 2, 3}, {1, 2, 3, 2}}
local function notes_for(slot, v)                      -- voice v's sixteen steps for that bar
  local c = N.CHORDS[N.slots[slot]]
  local t, on = {}, false
  if N.patch.arp > 0 then
    local order, skip = ARP_ORDER[N.patch.arp], N.patch.arp == 2 and 2 or 1
    for s = 1, 16 do
      local idx = (s - 1) % skip == 0 and order[((s - 1) // skip) % #order + 1] or 0
      t[s] = (c and idx == v) and {c.notes[v], accent = (s - 1) % 4 == 0} or 0
    end
    return t
  end
  for s = 1, 16 do
    on = on or N.steps[s] > 0
    t[s] = (c and on) and {c.notes[v], slide = s < 16 and N.steps[s + 1] == 0} or 0
  end
  return t
end

local function send(slot, next_bar)
  for v = 1, 3 do studio.notes(N.TRACK0 + v - 1, notes_for(slot, v), next_bar) end
end

local function sig_of(slot)
  local n = N.slots[slot]
  for s = 1, 16 do n = n * 2 + (N.steps[s] > 0 and 1 or 0) end
  return n + N.patch.arp * 1e9
end

-- The studio told only what changed; the next bar's chord goes in the second half of this one, for its bar line.
function N.sync()
  if not seq.engine then return end
  local p, sent = N.patch, N.sent
  local vol = seq.mute and 0 or (p.arp > 0 and 0.5 or 0.22) * seq.volume * (mesa and mesa.gain(8) or 1)   -- (one note at a time is quieter than a chord)
  if sent.vol ~= vol or sent.bright ~= p.bright or sent.square ~= p.square or sent.tune ~= N.detune or sent.arp ~= p.arp then
    for v = 0, 2 do
      studio.synth(N.TRACK0 + v, {wave = p.square and "square" or "saw", cutoff = p.bright, res = 0.15, env = 0.2,
                                  decay = p.arp > 0 and 0.3 or 1.5, accent = p.arp > 0 and 0.4 or 0, drive = 0.1, volume = vol, tune = N.detune, reverb = 0.35})
    end
    sent.vol, sent.bright, sent.square, sent.tune, sent.arp = vol, p.bright, p.square, N.detune, p.arp
  end
  local now = slot_at(N.bar)
  local sig = sig_of(now) + now * 1e6
  if sent.sig ~= sig then send(now); sent.sig, N.queued = sig, nil end
  if seq.playing and N.bar and seq.step >= 8 and N.queued ~= N.bar then
    send(slot_at(N.bar + 1), true)
    N.queued = N.bar
  end
end

-- Called once by the story. The real microphone recognizes a sustained whistle; A/B can always finish the repair.
function N.queue_accident()
  if N.tune_done then return end
  N.tune_pending = true
  N.save()
end

function N.start_accident(ctx)
  if N.accident then return end
  N.tune_pending = true
  N.detune = 0.8
  N.accident = {mic = mic() ~= nil, pitch = nil, stable = 0}
  if ctx and ctx.toast then
    ctx.toast(N.accident.mic and "LA NUBE SE DESAFINA: SILBA O PULSA B" or "LA NUBE SE DESAFINA: PULSA A", 180)
  end
end

function N.finish_accident(ctx)
  if not N.accident then return end
  if N.accident.mic then mic(false) end
  N.accident, N.tune_pending, N.tune_done, N.detune = nil, false, true, 0
  N.save()
  if ctx and ctx.touched then ctx.touched() end
  if ctx and ctx.toast then ctx.toast("¡NUBE AFINADA!", 120) end
end

function N.update_accident(ctx)
  if station ~= "nube" then
    if N.accident then
      if N.accident.mic then mic(false) end
      N.accident, N.detune = nil, 0
    end
    return
  end
  if N.tune_pending and not N.accident and station == "nube" then N.start_accident(ctx) end
  local a = N.accident
  if not a or not a.mic then return end
  local level, pitch, _, _, kind = mic()
  if not level then a.mic, a.stable, a.pitch = false, 0, nil return end
  -- No clear note, ordinary speech and the instrument's own sound cannot tune it.
  if kind ~= "whistle" or level < 0.2 or not pitch or pitch < 500 then
    a.stable, a.pitch = 0, nil
    return
  end
  if a.pitch and math.abs(pitch - a.pitch) <= a.pitch * 0.06 then
    a.stable = a.stable + 1
  else
    a.stable = 1
  end
  a.pitch = pitch
  if a.stable >= 12 then N.finish_accident(ctx) end
end

local last_step, mel_step
local function release_all()
  for b, n in pairs(N.held) do note_off(n); N.held[b] = nil end
  if N.touch_note then note_off(N.touch_note); N.touch_note = nil end
end
N.release_all = release_all

local function step_ticks() return 60 * 15 / math.max(seq.bpm(), 30) end   -- a 16th, in 60 Hz ticks

local function melody()                                -- the recorded melody plays on its step; notes let go after one
  local t = ticks()
  for k = #N.auto, 1, -1 do
    if N.auto[k].off <= t then note_off(N.auto[k]); table.remove(N.auto, k) end
  end
  if not seq.playing or seq.mute then mel_step = nil return end
  if seq.step == mel_step then return end
  mel_step = seq.step
  local m = N.mel[seq.step + 1]
  if m > 0 then
    local n = note_on(m)
    if n then n.off = t + step_ticks() * 0.9; N.auto[#N.auto + 1] = n end
  end
end

function N.update()                                    -- the bars, counted on the bar line
  if station ~= "nube" then release_all()
  elseif N.touch_note and ticks() - N.touch_tick > 1 then note_off(N.touch_note); N.touch_note = nil end
  melody()
  if not seq.playing then N.bar, last_step = nil, nil return end
  if not N.bar then N.bar, last_step = 0, seq.step end
  if seq.step < last_step then N.bar = N.bar + 1 end
  last_step = seq.step
end

function N.sounding(s)
  local c = N.slots[slot_at(N.bar)]
  return c > 0 and (N.patch.arp > 0 or N.steps[s] > 0)
end

function N.hear(slot)                                  -- a chord's preview, the music stopped
  local c = N.CHORDS[N.slots[slot]]
  if not c or seq.playing or not seq.engine then return end
  N.sync()
  for v = 1, 3 do studio.note(N.TRACK0 + v - 1, c.notes[v]) end
end

-- ===== playing it =====

-- A key played by hand; if armed and the music runs, it lands on the step nearest to it.
local function strike(midi, ctx)
  local n = note_on(midi)
  if N.rec and seq.playing then
    local k = seq.nearest() + 1
    if N.mel[k] ~= midi then N.mel[k] = midi; ctx.touched() end
  end
  return n
end

N.KNOBS = {
  nbrillo = {get = function() return N.patch.bright end,
             turn = function(d) N.patch.bright = math.max(0, math.min(1, N.patch.bright + d * 0.05)) end},
}

function N.aim(h)
  local s = P.SPOTS[N.focus]
  h.point(s.tip[1], s.tip[2], s.kind == "knob" and "pinch" or "point")
end

local function turn(id, d, ctx)
  local k = N.KNOBS[id]
  local before = k.get()
  k.turn(d)
  if k.get() ~= before then hands.twist(); ctx.touched() end
end
N.turn = turn

local function cycle(slot, d)
  N.slots[slot] = (N.slots[slot] + d) % (#N.CHORDS + 1)
  N.hear(slot)
end

function N.press(id, ctx, back)
  local s = P.SPOTS[id]
  hands.press()
  if s.kind == "slot" then cycle(s.slot, back and -1 or 1); ctx.touched()
  elseif s.kind == "step" then
    N.steps[s.step + 1] = N.steps[s.step + 1] > 0 and 0 or 1
    ctx.touched()
  elseif id == "nonda" then N.patch.square = not N.patch.square; ctx.touched()
  elseif id == "narp" then N.patch.arp = (N.patch.arp + (back and 3 or 1)) % 4; ctx.touched()
  elseif id == "nvoz" then
    N.patch.voice = (N.patch.voice - 1 + (back and 3 or 1)) % 4 + 1
    ctx.touched()
    local n = note_on(57); if n then N.auto[#N.auto + 1] = n; n.off = ticks() + 30 end   -- hear it: an A
  elseif id == "nrec" then
    if back then
      for k = 1, 16 do N.mel[k] = 0 end
      N.rec = false
      ctx.toast("MELODÍA BORRADA", 90)
    else
      N.rec = not N.rec
      if N.rec and not seq.playing then ctx.toggle_play() end
    end
    ctx.touched()
  elseif id == "nplay" then ctx.toggle_play() end
end

-- DIRECTO: the buttons are the keys of A minor (the iaia's chords all live in it): A, B, C, D, E, G and A above.
local PADS = {a = 57, left = 59, b = 60, right = 62, c = 64, down = 67, up = 69}
local PAD_HAND = {a = "right", b = "right", c = "right", up = "left", down = "left", left = "left", right = "left"}

local function input_directo(ctx)
  for b, midi in pairs(PADS) do
    if btnp(b) then
      N.held[b] = strike(midi, ctx)
      ctx.hands.press(PAD_HAND[b])
    elseif N.held[b] and not btn(b) then
      note_off(N.held[b]); N.held[b] = nil
    end
  end
end

function N.input(ctx)
  if N.accident then
    if btnp("b") or (not N.accident.mic and btnp("a")) then N.finish_accident(ctx) end
    return
  end
  if ctx.mode() == "directo" then input_directo(ctx) return end
  if next(N.held) then release_all() end
  if btnp("c") then ctx.set_mode("directo") return end
  local s = P.SPOTS[N.focus]
  if s.kind == "knob" and btn("a") then
    if btnp("left", 10, 3) or btnp("down", 10, 3) then turn(N.focus, -1, ctx) end
    if btnp("right", 10, 3) or btnp("up", 10, 3) then turn(N.focus, 1, ctx) end
    return
  end
  local dx = (btnp("right", 12, 4) and 1 or 0) - (btnp("left", 12, 4) and 1 or 0)
  local dy = (btnp("down", 12, 4) and 1 or 0) - (btnp("up", 12, 4) and 1 or 0)
  if dx ~= 0 or dy ~= 0 then
    N.focus = P.move(N.focus, dx, dx == 0 and dy or 0)
    N.aim(hands)
  end
  if btnp("a") and s.kind ~= "knob" then N.press(N.focus, ctx) end
  if btnp("b") and (s.kind == "slot" or N.focus == "nvoz" or N.focus == "nrec" or N.focus == "narp") then N.press(N.focus, ctx, true) end
end

-- A finger: a chord button changes, a key toggles (a drag along the keys paints them), the knob turns up and down.
local drag
function N.touch(tx, ty, first, ctx)
  if N.accident then
    if first then N.finish_accident(ctx) end
    return
  end
  local key = (first or (drag and drag.keys)) and P.key_at(tx, ty)
  if key or (drag and drag.keys and not first) then            -- on the keys: a note under the finger, sliding between
    if first then drag = {keys = true}; N.focus = "n1"; N.aim(hands) end
    N.touch_tick = ticks()
    if key and (not N.touch_note or N.touch_note.midi ~= key) then
      if N.touch_note then note_off(N.touch_note) end
      N.touch_note = strike(key, ctx)
      hands.point(tx, ty, "point")
      if first then hands.press() end
    end
    return
  end
  if first then
    local id = P.at(tx, ty)
    drag = {id = id, y = ty}
    if not id then return end
    N.focus = id
    N.aim(hands)
    local s = P.SPOTS[id]
    if s.kind ~= "knob" then N.press(id, ctx) end
    if s.kind == "step" then drag.paint, drag.done = N.steps[s.step + 1], {[id] = true} end
    return
  end
  if not drag or not drag.id then return end
  if drag.paint then
    local id = P.at(tx, ty)
    local s = id and P.SPOTS[id]
    if s and s.kind == "step" and not drag.done[id] then
      drag.done[id] = true
      N.steps[s.step + 1] = drag.paint
      hands.point(s.tip[1], s.tip[2], "point")
      hands.press()
      ctx.touched()
    end
  elseif N.KNOBS[drag.id] then
    local acc = drag.y - ty
    if math.abs(acc) >= 4 then
      turn(drag.id, acc > 0 and 1 or -1, ctx)
      drag.y = ty
    end
  end
end

local NAMES = {"DO", "DO#", "RE", "RE#", "MI", "FA", "FA#", "SOL", "SOL#", "LA", "LA#", "SI"}
local function chord_name(slot) local c = N.CHORDS[N.slots[slot]]; return c and c.name end

function N.lcd()
  if N.accident then return N.accident.mic and "SILBA / B AFINA" or "A: AFINAR" end
  local s = P.SPOTS[N.focus]
  local playing = N.touch_note or next(N.held)
  if playing then return "NOTA " .. (N.rec and seq.playing and "REC " or "") .. NAMES[(N.touch_note or select(2, next(N.held))).midi % 12 + 1] end
  if N.focus == "narp" then return N.patch.arp == 0 and "ARPEGIADOR: NO" or "ARP: " .. ({"SUBE", "OCHO", "ZIGZAG"})[N.patch.arp] end
  if N.focus == "nvoz" then return "VOZ: " .. N.VOICES[N.patch.voice] end
  if N.focus == "nrec" then return N.rec and (seq.playing and "GRABANDO" or "LISTO") or "GRABAR" end
  if s.kind == "slot" then return "COMPÁS " .. s.slot .. ": " .. (chord_name(s.slot) or "-") end
  if s.kind == "step" then return "PASO " .. (s.step + 1) end
  if N.focus == "nbrillo" then return "BRILLO " .. math.floor(N.patch.bright * 100 + 0.5) end
  if N.focus == "nonda" then return N.patch.square and "ONDA: ÓRGANO" or "ONDA: CUERDAS" end
  return seq.playing and "STOP" or string.format("PLAY  %d BPM", seq.bpm())
end

local HINTS = {slot = "A OTRO ACORDE   B EL DE ANTES", step = "A PASO: AHÍ VUELVE A SONAR",
               knob = "MANTÉN A Y MUEVE LA CRUCETA", switch = "A CAMBIAR LA ONDA", button = "A PULSAR   C: TECLAS   MENU: SALA"}
function N.hint(ctx)
  if N.accident then return N.accident.mic and "SILBA AL MICRO O PULSA B" or "PULSA A PARA AFINAR" end
  if ctx and ctx.mode() == "directo" then return "A B C Y CRUCETA: TECLAS   MENU: PASOS" end
  if N.focus == "narp" then return "A OTRO ARPEGIO   B EL DE ANTES" end
  if N.focus == "nvoz" then return "A OTRA VOZ   B LA DE ANTES" end
  if N.focus == "nrec" then return "A GRABAR TOCANDO   B BORRA" end
  return HINTS[P.SPOTS[N.focus].kind]
end

local view = {names = {}, lit = {}}
function N.view(lcd_text, ctx)
  local s = P.SPOTS[N.focus]
  view.chords = N.slots
  for i = 1, 4 do view.names[i] = chord_name(i) end
  view.sel = s.kind == "slot" and s.slot or nil
  view.now = seq.playing and N.now() or nil
  local shown = view.now or view.sel or 1                -- the keys: the chord that sounds, or the one in hand
  local c = N.CHORDS[N.slots[shown]]
  for k in pairs(view.lit) do view.lit[k] = nil end
  if c then for _, m in ipairs(c.notes) do view.lit[m] = true end end
  local sig = c and N.slots[shown] or 0
  local function held(m) view.lit[m] = 2; sig = sig + 2 ^ (m - 40) end        -- played notes light brighter
  if N.touch_note then held(N.touch_note.midi) end
  for _, n in pairs(N.held) do held(n.midi) end
  for _, n in ipairs(N.auto) do held(n.midi) end
  view.lit_sig = sig
  view.arp = N.patch.arp
  view.voice, view.rec, view.mel = N.SHORT[N.patch.voice], N.rec and (seq.playing and 2 or 1) or 0, N.mel
  view.steps, view.playing, view.step = N.steps, seq.playing, seq.step
  view.bright, view.square, view.lcd = N.patch.bright, N.patch.square, lcd_text
  return view
end

-- ===== kept =====

function N.save()
  local st = {}
  for s = 1, 16 do st[s] = N.steps[s] > 0 and "x" or "." end
  store("nube", {slots = N.slots, steps = table.concat(st), bright = N.patch.bright,
                 square = N.patch.square, voice = N.patch.voice, arp = N.patch.arp, mel = table.concat(N.mel, ","), tune_pending = N.tune_pending, tune_done = N.tune_done})
end

function N.load()
  N.reset()
  local t = stored("nube")
  if type(t) ~= "table" then return end
  if type(t.slots) == "table" then
    for i = 1, 4 do
      local c = t.slots[i]
      if type(c) == "number" and c >= 0 and c <= #N.CHORDS then N.slots[i] = math.floor(c) end
    end
  end
  if type(t.steps) == "string" and #t.steps == 16 then
    for s = 1, 16 do N.steps[s] = t.steps:sub(s, s) == "x" and 1 or 0 end
  end
  if type(t.bright) == "number" then N.patch.bright = math.max(0, math.min(1, t.bright)) end
  N.patch.square = t.square == true
  if type(t.voice) == "number" and t.voice >= 1 and t.voice <= 4 then N.patch.voice = math.floor(t.voice) end
  if type(t.arp) == "number" and t.arp >= 0 and t.arp <= 3 then N.patch.arp = math.floor(t.arp) end
  if type(t.mel) == "string" then
    local k = 1
    for v in t.mel:gmatch("%d+") do
      if k <= 16 then N.mel[k] = math.max(0, math.min(127, tonumber(v) or 0)) end
      k = k + 1
    end
  end
  N.tune_pending = t.tune_pending == true
  N.tune_done = t.tune_done == true
end

N.reset()
return N
