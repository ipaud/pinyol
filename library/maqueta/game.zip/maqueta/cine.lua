-- The cutscenes' stage: a picture (or the room, or the train's Mode 7 floor) on layer 2 and what happens on it,
-- done the GBA way, with register effects that cost no memory: mosaic in, line waves, brightness flashes, a
-- letterbox, the LED. The story (story/es.txt) says which scene with [do escena("...")]; the words go on top.
local hands = require("hands")
local sala = require("sala")
local C = {}

local SCENES = {
  atardecer = {pic = "CINE_CIRERA", bands = true},
  plaza = {pic = "CINE_PLAZA", fuegos = true, bands = true},
  concierto = {pic = "CINE_PLAZA"},
  batalla = {pic = "CINE_BATALLA", neon = true},
  -- the prologue and chapter 1, in pictures (tools/prologo_imgs.sh)
  casa = {pic = "CINE_CASA", wide = 1, bands = true},      -- from the attic's round window to the iaia at her door
  escalera = {pic = "CINE_ESCALERA", bands = true},
  sabana = {pic = "CINE_SABANA", bands = true},
  cireres = {pic = "CINE_CIRERES", wide = 1, bands = true, hiss = true},
  cinta = {pic = "CINE_CINTA", bands = true},
  iaia = {pic = "CINE_IAIA", bands = true},
  kiko = {pic = "CINE_KIKO"},
  armario = {pic = "CINE_ARMARIO"},
  anden = {pic = "CINE_PLAZA", lineas = true, bands = true},
  cinta83 = {pic = "CINE_1983", ondas = true, hiss = true, bands = true},
  cocina = {pic = "CINE_COCINA", bands = true},
  azotea = {pic = "CINE_AZOTEA", lluvia = 0.35, neon = true, bands = true},
  desvan = {room = "desvan"},
  sala = {room = true},
  noche = {room = "habitacion", dark = 7},
  manana = {room = "habitacion", light = 4},
  temporal = {room = "faro", lluvia = 1, rayos = true, bands = true},
  noche_desvan = {room = "desvan", dark = 12},
  faro_noche = {room = "faro", lluvia = 0.5, dark = 4},
  tren = {tren = "alba"},
  tren_vuelta = {tren = "ocaso"},
  negro = {black = true},
}

local SKY = {                                    -- the train's sky, top to horizon
  alba = {0x1C2448, 0x4A3A6A, 0xB0607A, 0xF0A070, 0xFFD8A0},
  ocaso = {0x2A1A3A, 0x7A2A4A, 0xD0503A, 0xF08A3A, 0xFFC060},
}
local HORIZON = 48
local TUNNEL_TICKS, TUNNEL_EDGE = 48, 0.5   -- how long the tunnel takes to swallow the floor, and how soft its front is
local PAN_TICKS = 420                            -- a wide picture's crossing: seven seconds

local function mix(a, b, k)                      -- two colours, k of the way from a to b
  local function ch(sh) return math.floor(((a >> sh) & 255) * (1 - k) + ((b >> sh) & 255) * k + 0.5) end
  return (ch(16) << 16) | (ch(8) << 8) | ch(0)
end

C.name, C.s, C.t = nil, nil, 0
local mos, shake, flash, cam_y = 0, 0, 0, 0
local fx                                        -- the shell's particles
local rain = {}

function C.init(particles) fx = particles end

local function clear_fx()
  line_off()
  fx_off()
  window_off(0)
  mosaic(1, 1)
  tone(2)
end

-- The stage as the scene wants it. restore(): the shell puts its station back when the story is over.
function C.show(name)
  local s = SCENES[name]
  if not s then error("cine: no scene " .. tostring(name)) end
  clear_fx()
  C.name, C.s, C.t, mos, shake, flash = name, s, 0, 10, 0, 0
  hands.hidden = not (s.room and not s.dark and not s.light and not s.lluvia)   -- hands only at the desk
  backdrop(0x000000)
  if s.pic then
    local cid = s.wide and "CINE_W" or "CINE"       -- a canvas keeps its size: one for the wide pictures
    canvas(cid, s.pic)
    bg(2, {image = cid, prio = 2, mosaic = true, x = s.wide and s.wide < 0 and 120 or 0, y = 0})
  elseif s.room then
    if s.room ~= true then sala.build(s.room) end
    bg(2, {image = sala.canvas_id, prio = 2, mosaic = true, x = 0, y = 0})
    scroll(2, sala.cam())
  elseif s.tren then
    bg(2, {map = "TREN", mode = "affine", prio = 2, wrap = true, mosaic = true})
    local sky = SKY[s.tren]
    for y = 0, HORIZON do                          -- the sky, a colour a line, as a GBA gradient
      local k = y / HORIZON * (#sky - 1)
      local i = math.floor(k)
      line_backdrop(y, mix(sky[i + 1], sky[math.min(#sky, i + 2)], k - i))
    end
  else
    bg(2)
  end
  if s.hiss then tone(2, 2000, {wave = "noise", vol = 0.04, sustain = 1, attack = 0.2}) end
  rain = {}
  if s.lineas then
    for i = 1, 16 do rain[i] = {math.random(0, 600), math.random(30, 290), math.random(18, 30), true} end
  end
  if s.lluvia then
    for i = 1, math.floor(70 * s.lluvia) do rain[i] = {math.random(0, 479), math.random(0, 319), math.random(6, 10)} end
  end
end

function C.off()                                 -- always: the station's picture may have changed under the scene
  if C.name then clear_fx() end
  C.name, C.s = nil, nil
  hands.hidden = false
  backdrop(0x150e12)
  if C.restore then C.restore() end
end

function C.shake(n) shake = n end
function C.flash(n) flash = n end

-- The story's [do] run one after another the moment the text gets to them, so what takes time goes in a queue:
-- each move starts when the one before has finished (it returns a test that says so, or nothing: at once), and
-- the next line waits for the queue to be empty. A train ride, then a chapter's card, then words.
local queue, current = {}, nil
function C.add(fn) queue[#queue + 1] = fn end
function C.wait_for(n)
  C.add(function() local t = 0 return function() t = t + 1 return t >= n end end)
end
local function run_queue()
  while true do
    if current then
      if not current() then return end
      current = nil
    end
    local fn = table.remove(queue, 1)
    if not fn then return end
    current = fn()
  end
end
function C.busy() return current ~= nil or #queue > 0 or C.card ~= nil end
function C.flush() queue, current = {}, nil end

-- A chapter's card: two bars, black, its number and its name, then out with a mosaic.
function C.chapter(n, title)
  C.card = {n = n, title = title, t = 0}
end

local function update_tren()
  cam_y = 4096 - (C.t * 3) % 4096                 -- forward is up the map
  mode7(2, 128, cam_y, 0, 20, HORIZON, 150)
  if C.t > 340 and C.t <= 340 + TUNNEL_TICKS + 1 then  -- the tunnel's mouth comes down the floor: dark at the horizon first
    local p = math.min(1, (C.t - 340) / TUNNEL_TICKS)  -- how far it has come: 0 not yet, 1 the whole floor
    fade("dark", BG2, 0)                               -- (the amount is each line's own: line_fx)
    for y = 0, 159 do
      local d = math.max(0, y - HORIZON) / (159 - HORIZON)   -- 0 at the horizon, 1 at the bottom of the window
      local dark = (p * (1 + TUNNEL_EDGE) - d) / TUNNEL_EDGE    -- the front passes line by line, TUNNEL_EDGE wide
      line_fx(y, math.floor(math.max(0, math.min(1, dark)) * 16 + 0.5))
    end
  end
  if C.t % 32 == 0 then tone(1, 90, {wave = "noise", vol = 0.12, decay = 0.05}) end  -- the rails, on the beat
  if C.t % 32 == 12 then tone(1, 70, {wave = "noise", vol = 0.08, decay = 0.05}) end
end

function C.update()
  run_queue()
  if C.card then
    C.card.t = C.card.t + 1
    if C.card.t > 150 then C.card = nil; mos = 8 end
  end
  if not C.s then return end
  C.t = C.t + 1
  local s = C.s
  if mos > 0 then mos = mos - 1 end
  mosaic(1 + mos // 2, 1 + mos // 2)
  if s.tren then update_tren() end
  if s.wide then                                     -- a wide picture (360x160): the camera crosses it, slowing down
    local k = math.min(1, C.t / PAN_TICKS)
    local x = math.floor(120 * (1 - (1 - k) * (1 - k)) + 0.5)
    scroll(2, s.wide < 0 and 120 - x or x, 0)
  end
  if s.ondas then                                    -- the tape's memory wobbles, line by line
    for y = 0, 159 do line_scroll(2, y, math.floor(math.sin(y * 0.09 + C.t * 0.06) * 2 + 0.5), 0) end
  end
  if s.rayos and C.t % 170 == 40 then flash = 6; tone(1, 60, {wave = "noise", vol = 0.35, decay = 0.9}) end
  if s.neon and C.t % 37 == 0 and math.random() < 0.5 then flash = 2 end
  if shake > 0 then
    shake = shake - 1
    local x, y = 0, 0
    if s.room then x, y = sala.cam() end
    scroll(2, x + math.random(-2, 2), y + math.random(-2, 2))
    if shake == 0 then scroll(2, x, y) end
  end
  if flash > 0 then
    flash = flash - 1
    fade("light", BG2, flash > 0 and 10 or 0)
  elseif s.dark then fade("dark", BG2 | OBJ, s.dark)
  elseif s.light then fade("light", BG2, s.light) end
  if s.fuegos and C.t % 36 == 0 and fx then
    local cols = ({{0xFFE070, 0xFFFFFF}, {0xFF5040, 0xFFB0A0}, {0x60FF80, 0xD0FFD0}})[C.t // 36 % 3 + 1]
    fx:burst(math.random(60, 420), math.random(20, 120), 26, {colours = cols, speed = 3, life = 40, size = 2, gravity = 0.04})
    tone(1, 80, {wave = "noise", vol = 0.18, decay = 0.4})
  end
end

local BAND = 26
local CARD_TITLE = {font = "hint", color = 0xFFE9B0, align = "center", scale = 2, shadow = 0x5A2A10}
local CARD_NUM = {font = "hint", color = 0xE8742A, align = "center"}

function C.draw()
  if C.s then
    local s = C.s
    for _, r in ipairs(rain) do
      if r[4] then                                   -- speed lines: someone runs
        r[1] = r[1] - r[3]
        if r[1] < -90 then r[1], r[2] = 500 + math.random(0, 80), math.random(30, 290) end
        rect(r[1], r[2], 70, 2, 0xFFF4E0)
      else                                           -- rain over the glass
        r[2] = r[2] + r[3]
        r[1] = r[1] - 2
        if r[2] > 320 then r[2], r[1] = -10, math.random(0, 520) end
        line(r[1], r[2], r[1] - 3, r[2] + 9, 0x9AB0D0)
      end
    end
    if s.tren then
      local dusk = s.tren == "ocaso"
      circ(dusk and 330 or 380, dusk and 84 or 62, 20, dusk and 0xFFB060 or 0xFFE8B0)        -- the sun
      local hy = HORIZON * 2
      tri(0, hy, 70, hy - 26, 150, hy, 0x3A2A48)                                            -- the hills inland
      tri(90, hy, 190, hy - 38, 280, hy, 0x46344F)
      tri(0, hy, 40, hy - 12, 90, hy, 0x2E2238)
      for k = 6, 0, -1 do                            -- the poles go by: the metronome
        local px, py, sc, vis = project(2, 100, cam_y // 64 * 64 - k * 64)
        if vis and sc and sc > 0.02 then
          local h = 44 * sc
          rect(math.floor(px * 2 - sc * 4), math.floor((py - h) * 2), math.max(2, math.floor(sc * 8)), math.floor(h * 2), 0x2A1A14)
          rect(math.floor(px * 2 - sc * 14), math.floor((py - h) * 2), math.max(4, math.floor(sc * 28)), math.max(1, math.floor(sc * 4)), 0x2A1A14)
        end
      end
      rect(0, 0, 480, 22, 0x2A1E1A)                  -- the carriage's window
      rect(0, 286, 480, 34, 0x2A1E1A)
      rect(0, 0, 16, 320, 0x2A1E1A)
      rect(464, 0, 16, 320, 0x2A1E1A)
      box(16, 22, 448, 264, 0x5A4038)
      box(17, 23, 446, 262, 0x120C0A)
    end
    if s.bands then
      local b = math.min(BAND, C.t * 4)              -- the letterbox closes 4 px a frame
      rect(0, 0, 480, b, 0x000000)
      rect(0, 320 - b, 480, b, 0x000000)
    end
  end
  if C.card then
    local t = C.card.t
    rect(0, 0, 480, 320, 0x0A0608)
    local w = math.min(480, t * 16)
    rect(240 - w // 2, 118, w, 84, 0x1E1418)
    line(240 - w // 2, 118, 240 + w // 2, 118, 0xE8742A)
    line(240 - w // 2, 201, 240 + w // 2, 201, 0xE8742A)
    if t > 10 then
      text(C.card.n == 0 and "PRÓLOGO" or ("CAPÍTULO " .. C.card.n), 240, 132, CARD_NUM)
      text(C.card.title, 240, 156, CARD_TITLE)
    end
  end
end

-- The eight notes of the tape, hummed (voice 3): «Cirera», the leitmotiv. A minor, two octaves above the bass.
C.MOTIF = {57, 60, 64, 62, 60, 59, 57, 52}
local hum
function C.hum(notes, wave, every)
  hum = {notes = notes or C.MOTIF, i = 0, t = 0, every = every or 18, wave = wave or "triangle"}
end
function C.humming() return hum ~= nil end
function C.update_hum()
  if not hum then return end
  hum.t = hum.t + 1
  if hum.t % hum.every == 1 then
    hum.i = hum.i + 1
    local m = hum.notes[hum.i]
    if not m then hum = nil; return end
    tone(3, 440 * 2 ^ ((m - 69) / 12), {wave = hum.wave, vol = 0.35 * seq.volume, decay = 0.5, sustain = 0.3,
                                         len = hum.every / 60 * 0.9})
  end
end

return C
