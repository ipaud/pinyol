-- Nogal, the lead synth: one voice (tone() voice 2) that glides from the note held to the next, with a vibrato, a pitch
-- wheel and a mod wheel. Played by finger on the keys, or in DIRECTO with the buttons; REC puts what is played on the
-- sixteen steps (a note played over another held one is a slide), and it comes round with the music.
-- ponytail: one note a step and one voice; it follows the studio's step, not FRUITERA's sections; silent where
-- tone() is missing.
local N = {}
N.panel = require("nogal_panel")
local P = N.panel

local VOICE = 2
N.WAVES, N.SHORT, N.LONG = {"saw", "square", "triangle"}, {"SIE", "CUA", "TRI"}, {"SIERRA", "HUECA", "SUAVE"}
N.focus = "nglide"
local NAMES = {"DO", "DO#", "RE", "RE#", "MI", "FA", "FA#", "SOL", "SOL#", "LA", "LA#", "SI"}

function N.reset()
  if N.cur then tone(VOICE) end
  N.patch = {wave = 1, glide = 0.4, vib = 0.15, vol = 0.7}
  N.notes, N.tie = {}, {}
  for k = 1, 16 do N.notes[k], N.tie[k] = 0, false end
  N.rec, N.cur, N.held, N.touch_note, N.touch_tick, N.roll = false, nil, {}, nil, 0, false
  N.wheel, N.mod, N.dive, N.mod_hold, N.last_note, N.played = 0, 0, 0, false, 57, 0
  N.sent = {}
end

local function hz(m) return 440 * 2 ^ ((m - 69) / 12) end
local function volume() return 0.5 * N.patch.vol * seq.volume * (mesa and mesa.gain(8) or 1) * (seq.mute and 0 or 1) end
local function glide_ticks() return 1 + 24 * N.patch.glide end

-- A note: from the one that is held (a slide) if there is one, else fresh. Mono: it takes the voice.
local function start(midi, pat)
  if not tone then return end
  local from = (N.cur and N.patch.glide > 0.02) and N.cur.midi - midi or 0
  tone(VOICE, hz(midi), {wave = N.WAVES[N.patch.wave], vol = volume(), sustain = 1, attack = 0.01, release = 0.1, bend = from})
  N.cur = {midi = midi, gl = from, t0 = ticks(), pat = pat}
  N.sent = {}
end
local function stop()
  if N.cur and tone then tone(VOICE) end
  N.cur = nil
end

local last_rec
local function strike(midi, ctx)
  local over = N.cur ~= nil and not N.cur.pat
  start(midi)
  N.last_note, N.played = midi, N.played + 1
  if N.rec and seq.playing then
    local k = seq.nearest() + 1
    if over and last_rec and last_rec ~= k then N.tie[last_rec] = true end
    N.notes[k], N.tie[k], last_rec = midi, false, k
    ctx.touched()
  end
end
local function release(midi)
  if N.cur and not N.cur.pat and N.cur.midi == midi then stop() end
end
function N.release_all()
  for b, m in pairs(N.held) do release(m); N.held[b] = nil end
  if N.touch_note then release(N.touch_note); N.touch_note = nil end
end

-- ===== humming it =====
-- The microphone's pitch, a step at a time, becomes the step's note: the median of what a voice or a whistle held in
-- it, snapped to the nearest note of A minor and folded into the keyboard's two octaves.
local SCALE = {[0] = true, [2] = true, [3] = true, [5] = true, [7] = true, [8] = true, [10] = true}   -- from A
function N.snap(hz)
  if not hz or hz < 70 then return nil end
  local m = 69 + 12 * math.log(hz / 440, 2)
  local best, bd = nil, 99
  local r = math.floor(m + 0.5)
  for c = r - 2, r + 2 do
    if SCALE[(c - 9) % 12] and math.abs(c - m) < bd then best, bd = c, math.abs(c - m) end
  end
  while best < 48 do best = best + 12 end
  while best > 71 do best = best - 12 end
  return best
end

local function median(t)
  table.sort(t)
  return t[(#t + 1) // 2]
end

local function hum_off(done)
  if N.hum then mic(false) end
  N.hum = nil
  if done and N.toast then N.toast("MELODÍA LISTA: SUENA EN EL NOGAL", 120) end
end
N.hum_off = hum_off

local function hum_update()
  local h = N.hum
  if not h then return end
  if station ~= "nogal" or not seq.playing then hum_off() return end
  local level, pitch, _, _, kind = mic()
  if not level then hum_off(); if N.toast then N.toast("NO HAY MICRÓFONO", 90) end return end
  if h.step ~= seq.step then
    if h.on then                                        -- the step that ended gets its note (or a rest)
      N.notes[h.step + 1], N.tie[h.step + 1] = N.snap(median(h.buf) or 0) or 0, false
      h.count = h.count + 1
      if h.count >= 16 then hum_off(true) N.touched() return end
    elseif seq.step == 0 then h.on, h.count = true, 0   -- the music's first step: the sixteen start here
    end
    h.step, h.buf = seq.step, {}
  end
  if h.on and (kind == "voice" or kind == "whistle") and pitch > 0 and level > 0.12 then h.buf[#h.buf + 1] = pitch end
end

local pat_step
local function step_ticks() return 60 * 15 / math.max(seq.bpm(), 30) end
local function pattern()                               -- the recorded line on its step
  if not seq.playing or seq.mute then
    pat_step = nil
    if N.cur and N.cur.pat then stop() end
    return
  end
  if seq.step ~= pat_step then
    local prev = pat_step
    pat_step = seq.step
    local m = N.notes[seq.step + 1]
    if m > 0 and not (N.cur and not N.cur.pat) then
      if not (prev and N.tie[prev + 1] and N.cur) then stop() end   -- a tied note slides on; else a fresh one
      start(m, true)
      N.cur.off = not N.tie[seq.step + 1] and ticks() + 0.85 * step_ticks() or nil
    end
  end
  if N.cur and N.cur.pat and N.cur.off and ticks() >= N.cur.off then stop() end
end

-- every tick: the touch lifted, the wheels, the glide's end and the vibrato, told to the voice only when they change
function N.update()
  if station ~= "nogal" then N.release_all()
  elseif N.touch_note and ticks() - N.touch_tick > 1 then release(N.touch_note); N.touch_note = nil end
  if N.dive > 0 then N.dive = N.dive - 1; N.wheel = N.dive / 24 end
  if N.wheel_touch and ticks() - N.wheel_touch > 1 and N.dive == 0 then N.wheel, N.wheel_touch = 0, nil end
  if N.mod_touch and ticks() - N.mod_touch > 1 and not N.mod_hold then N.mod, N.mod_touch = 0, nil end
  if N.mod_hold then N.mod = 1 end
  hum_update()
  pattern()
  local c = N.cur
  if not (c and tone_set) then return end
  local g = c.gl * math.max(0, 1 - (ticks() - c.t0) / glide_ticks())
  local vib = (N.patch.vib * 0.5 + N.mod * 0.6) * math.sin(ticks() * 0.575)
  local bend, vol = g + N.wheel * 2 + vib, volume()
  if math.abs(bend - (N.sent.bend or 1e9)) > 0.004 or vol ~= N.sent.vol then
    tone_set(VOICE, {vol = vol, bend = bend})
    N.sent.bend, N.sent.vol = bend, vol
  end
end

-- ===== playing it =====

N.KNOBS = {
  nglide = {get = function() return N.patch.glide end, turn = function(d) N.patch.glide = math.max(0, math.min(1, N.patch.glide + d * 0.05)) end},
  nvib = {get = function() return N.patch.vib end, turn = function(d) N.patch.vib = math.max(0, math.min(1, N.patch.vib + d * 0.05)) end},
  nvol = {get = function() return N.patch.vol end, turn = function(d) N.patch.vol = math.max(0, math.min(1, N.patch.vol + d * 0.05)) end},
}

function N.aim(h)
  local s = P.SPOTS[N.focus]
  h.point(s.tip[1], s.tip[2], s.kind == "knob" and "pinch" or "point")
end

function N.turn(id, d, ctx)
  local k = N.KNOBS[id]
  local before = k.get()
  k.turn(d)
  if k.get() ~= before then hands.twist(); ctx.touched() end
end

function N.press(id, ctx, back)
  local s = P.SPOTS[id]
  hands.press()
  if s.kind == "step" then
    local k = s.step + 1
    if back then
      if N.notes[k] > 0 then N.tie[k] = not N.tie[k]; ctx.touched() end
    else
      N.notes[k], N.tie[k] = N.notes[k] > 0 and 0 or N.last_note, false
      if N.notes[k] > 0 and not seq.playing then start(N.notes[k], true); N.cur.off = ticks() + 12 end
      ctx.touched()
    end
  elseif id == "nonda" then
    N.patch.wave = (N.patch.wave - 1 + (back and 2 or 1)) % 3 + 1
    ctx.touched()
    start(57, true); N.cur.off = ticks() + 18        -- hear it: an A
  elseif id == "nrec" then
    if back then
      for k = 1, 16 do N.notes[k], N.tie[k] = 0, false end
      N.rec = false
      ctx.toast("MELODÍA BORRADA", 90)
    else
      N.rec = not N.rec
      if N.rec and not seq.playing then ctx.toggle_play() end
    end
    ctx.touched()
  elseif id == "nhum" then
    if N.hum then hum_off()
    else
      if not mic() then ctx.toast("NO HAY MICRÓFONO", 90) return end
      N.rec, N.toast, N.touched = false, ctx.toast, ctx.touched
      N.hum = {step = seq.playing and seq.step or -1, buf = {}}
      stop()
      if not seq.playing then ctx.toggle_play() end
    end
  elseif id == "nroll" then
    N.release_all()
    N.roll = not N.roll
  elseif id == "nplay" then ctx.toggle_play()
  elseif id == "nbend" then N.dive = 24             -- a dive from the top wheel, back down
  elseif id == "nmod" then N.mod_hold = not N.mod_hold; if not N.mod_hold then N.mod = 0 end end
end

-- DIRECTO: the buttons are the keys of A minor, A to A.
local PADS = {a = 57, left = 59, b = 60, right = 62, c = 64, down = 67, up = 69}
local PAD_HAND = {a = "right", b = "right", c = "right", up = "left", down = "left", left = "left", right = "left"}
local function input_directo(ctx)
  for b, midi in pairs(PADS) do
    if btnp(b) then
      N.held[b] = midi
      strike(midi, ctx)
      ctx.hands.press(PAD_HAND[b])
    elseif N.held[b] and not btn(b) then
      release(N.held[b]); N.held[b] = nil
    end
  end
end

function N.input(ctx)
  if ctx.mode() == "directo" then input_directo(ctx) return end
  if next(N.held) then N.release_all() end
  if btnp("c") then ctx.set_mode("directo") return end
  local s = P.SPOTS[N.focus]
  if s.kind == "knob" and btn("a") then
    if btnp("left", 10, 3) or btnp("down", 10, 3) then N.turn(N.focus, -1, ctx) end
    if btnp("right", 10, 3) or btnp("up", 10, 3) then N.turn(N.focus, 1, ctx) end
    return
  end
  local dx = (btnp("right", 12, 4) and 1 or 0) - (btnp("left", 12, 4) and 1 or 0)
  local dy = (btnp("down", 12, 4) and 1 or 0) - (btnp("up", 12, 4) and 1 or 0)
  if dx ~= 0 or dy ~= 0 then
    N.focus = P.move(N.focus, dx, dx == 0 and dy or 0)
    N.aim(hands)
  end
  if btnp("a") and s.kind ~= "knob" then N.press(N.focus, ctx) end
  if btnp("b") and (s.kind == "step" or N.focus == "nonda" or N.focus == "nrec") then N.press(N.focus, ctx, true) end
end

-- A finger: a key plays (sliding along the keys glides), a wheel follows up and down, a knob turns, the rest presses.
local drag
function N.touch(tx, ty, first, ctx)
  if N.roll and (first or (drag and drag.roll)) then      -- the piano roll: a cell is a step's note, a drag paints
    local c, note = P.roll_at(tx, ty)
    if first and c then
      drag = {roll = true, last = nil}
      N.focus = "nglide"
    end
    if not (drag and drag.roll) then drag = nil end
    if drag and drag.roll and c and drag.last ~= c then
      if first and N.notes[c] == note then drag.erase = true end
      N.notes[c], N.tie[c] = drag.erase and 0 or note, false
      drag.last = c
      if not drag.erase then
        N.last_note = note
        if not seq.playing then start(note, true); N.cur.off = ticks() + 10 end
      end
      hands.point(tx, ty, "point")
      if first then hands.press() end
      ctx.touched()
    end
    if drag then return end
  end
  local key = not N.roll and (first or (drag and drag.keys)) and P.key_at(tx, ty)
  if key or (drag and drag.keys and not first) then
    if first then drag = {keys = true}; N.focus = "nglide"; N.aim(hands) end
    N.touch_tick = ticks()
    if key and N.touch_note ~= key then
      local old = N.touch_note
      N.touch_note = key
      strike(key, ctx)
      if old and N.cur then N.cur.midi = key end
      hands.point(tx, ty, "point")
      if first then hands.press() end
    end
    return
  end
  if first then
    local id = P.at(tx, ty)
    drag = {id = id, y = ty}
    if not id then return end
    N.focus = id
    N.aim(hands)
    local s = P.SPOTS[id]
    if s.kind ~= "knob" and s.kind ~= "wheel" then N.press(id, ctx) end
    if s.kind == "step" then drag.paint, drag.done = N.notes[s.step + 1] > 0, {[id] = true} end
  end
  if not drag or not drag.id then return end
  local s = P.SPOTS[drag.id]
  if s.kind == "wheel" then
    local v = math.max(-1, math.min(1, (s.y + s.h / 2 - ty) / (s.h / 2 - 5)))
    if drag.id == "nbend" then N.wheel, N.wheel_touch, N.dive = v, ticks(), 0
    else N.mod, N.mod_touch, N.mod_hold = math.max(0, v), ticks(), false end
  elseif N.KNOBS[drag.id] then
    local acc = drag.y - ty
    if math.abs(acc) >= 4 then N.turn(drag.id, acc > 0 and 1 or -1, ctx); drag.y = ty end
  elseif drag.paint ~= nil and not first then
    local id = P.at(tx, ty)
    local st = id and P.SPOTS[id]
    if st and st.kind == "step" and not drag.done[id] then
      drag.done[id] = true
      N.notes[st.step + 1], N.tie[st.step + 1] = drag.paint and 0 or N.last_note, false
      hands.point(st.tip[1], st.tip[2], "point")
      hands.press()
      ctx.touched()
    end
  end
end

function N.lcd()
  local m = N.touch_note or select(2, next(N.held))
  if m then return "NOTA " .. (N.rec and seq.playing and "REC " or "") .. NAMES[m % 12 + 1] end
  local s = P.SPOTS[N.focus]
  local id = N.focus
  if id == "nglide" then return "GLIDE " .. math.floor(N.patch.glide * 100 + 0.5) end
  if id == "nvib" then return "VIBRATO " .. math.floor(N.patch.vib * 100 + 0.5) end
  if id == "nvol" then return "VOLUMEN " .. math.floor(N.patch.vol * 100 + 0.5) end
  if id == "nonda" then return "ONDA: " .. N.LONG[N.patch.wave] end
  if id == "nbend" then return "RUEDA DE TONO" end
  if id == "nmod" then return N.mod_hold and "VIBRATO FIJO" or "RUEDA MOD" end
  if id == "nhum" then return N.hum and (N.hum.on and "ESCUCHANDO..." or "CANTA EN EL 1") or "TARAREAR" end
  if id == "nroll" then return N.roll and "VISTA: ROLLO" or "VISTA: TECLADO" end
  if id == "nrec" then return N.rec and (seq.playing and "GRABANDO" or "LISTO") or "GRABAR" end
  if s.kind == "step" then
    local n = N.notes[s.step + 1]
    return "PASO " .. (s.step + 1) .. (n > 0 and (": " .. NAMES[n % 12 + 1] .. (N.tie[s.step + 1] and " ~" or "")) or "")
  end
  return seq.playing and "STOP" or string.format("PLAY  %d BPM", seq.bpm())
end

local HINTS = {knob = "MANTÉN A Y MUEVE LA CRUCETA", button = "A PULSAR   C: TECLAS   MENU: SALA",
               wheel = "ARRASTRA EL DEDO   A: PRUEBA", step = "A PASO   B ENLAZA (SLIDE)"}
function N.hint(ctx)
  if ctx and ctx.mode() == "directo" then return "A B C Y CRUCETA: TECLAS   MENU: PASOS" end
  if N.focus == "nonda" then return "A OTRA ONDA   B LA DE ANTES" end
  if N.focus == "nrec" then return "A GRABAR TOCANDO   B BORRA" end
  if N.focus == "nroll" then return "A: ROLLO DE NOTAS / TECLADO" end
  if N.focus == "nhum" then return "A: CANTA UN COMPÁS AL MICRO" end
  return HINTS[P.SPOTS[N.focus].kind]
end

local view = {lit = {}}
function N.view(lcd_text)
  local sig = 0
  for k in pairs(view.lit) do view.lit[k] = nil end
  local m = N.cur and N.cur.midi
  if m then view.lit[m] = true; sig = 2 ^ (m - 40) end
  view.glide, view.vib, view.vol, view.wave = N.patch.glide, N.patch.vib, N.patch.vol, N.SHORT[N.patch.wave]
  view.bend, view.mod = math.floor(N.wheel * 20) / 20, math.floor(N.mod * 20) / 20
  view.roll = N.roll
  view.hum = N.hum and (N.hum.on and 2 or 1) or 0
  view.rec, view.steps, view.playing, view.step = N.rec and (seq.playing and 2 or 1) or 0, N.notes, seq.playing, seq.step
  view.lit_sig, view.lcd = sig, lcd_text
  return view
end

-- ===== kept =====

function N.save()
  store("nogal", {wave = N.patch.wave, glide = N.patch.glide, vib = N.patch.vib, vol = N.patch.vol,
                  notes = table.concat(N.notes, ","), ties = table.concat((function() local t = {} for k = 1, 16 do t[k] = N.tie[k] and "x" or "." end return t end)())})
end

local function num(v, lo, hi, d) return type(v) == "number" and math.max(lo, math.min(hi, v)) or d end
function N.load()
  N.reset()
  local t = stored("nogal")
  if type(t) ~= "table" then return end
  N.patch.wave = math.floor(num(t.wave, 1, 3, 1))
  N.patch.glide, N.patch.vib, N.patch.vol = num(t.glide, 0, 1, 0.4), num(t.vib, 0, 1, 0.15), num(t.vol, 0, 1, 0.7)
  if type(t.notes) == "string" then
    local k = 1
    for v in t.notes:gmatch("%d+") do
      if k <= 16 then N.notes[k] = math.max(0, math.min(127, tonumber(v) or 0)) end
      k = k + 1
    end
  end
  if type(t.ties) == "string" and #t.ties == 16 then
    for k = 1, 16 do N.tie[k] = t.ties:sub(k, k) == "x" end
  end
end

N.reset()
return N
