-- The room: the studio seen from the chair, a screen and a half each way (360x240). Left and right turn the head to
-- the next machine (the picture scrolls), up looks up at the window, A (or a finger on it) sits down at it; MENU
-- on a machine stands up, back here. Each chapter's studio has its own picture and the machines there are by then.
local pointer = require("pointer")
local S = {}

-- Where each machine is in each room's picture (pixels of the 360x240 picture).
S.ROOMS = {
  desvan = {image = "SALA_DES", spots = {
    {st = "ritmo", x = 120, y = 130, w = 120, h = 40},
    {st = "nogal", x = 258, y = 196, w = 96, h = 32},
    {st = "nube", x = 268, y = 92, w = 92, h = 56},
  }},
  habitacion = {image = "SALA_HAB", spots = {
    {st = "ritmo", x = 56, y = 120, w = 132, h = 40},
    {st = "pantalla", x = 200, y = 80, w = 102, h = 75},
  }},
  sotano = {image = "SALA_SOT", spots = {
    {st = "ritmo", x = 20, y = 138, w = 110, h = 42},
    {st = "linea", x = 137, y = 136, w = 111, h = 36},
    {st = "golpe", x = 178, y = 174, w = 87, h = 31},
    {st = "pantalla", x = 262, y = 92, w = 84, h = 62},
    {st = "mesa", x = 268, y = 156, w = 90, h = 44},
  }},
  faro = {image = "SALA_FAR", spots = {
    {st = "ritmo", x = 2, y = 137, w = 106, h = 38},
    {st = "golpe", x = 62, y = 170, w = 71, h = 30},
    {st = "linea", x = 120, y = 131, w = 115, h = 39},
    {st = "nube", x = 140, y = 170, w = 82, h = 30},
    {st = "mesa", x = 230, y = 170, w = 66, h = 30},
    {st = "rack", x = 242, y = 118, w = 74, h = 52},
    {st = "nogal", x = 296, y = 190, w = 64, h = 22},
    {st = "pantalla", x = 312, y = 118, w = 48, h = 70},
  }},
  gransala = {image = "SALA_GRA", w = 400, h = 200, spots = {
    {st = "ritmo", x = 0, y = 120, w = 75, h = 35},
    {st = "linea", x = 0, y = 85, w = 92, h = 33},
    {st = "golpe", x = 5, y = 150, w = 55, h = 35},
    {st = "nube", x = 62, y = 155, w = 73, h = 25},
    {st = "mesa", x = 85, y = 103, w = 255, h = 55},
    {st = "nogal", x = 262, y = 168, w = 70, h = 24},
    {st = "rack", x = 322, y = 35, w = 58, h = 60},
    {st = "pantalla", x = 350, y = 97, w = 50, h = 55},
  }},
}
S.NAME = {ritmo = "RITMO 88", linea = "LÍNEA 3", rack = "EL RACK", pantalla = "FRUITERA 4", golpe = "GOLPE 60", mesa = "MESA 8", nube = "NUBE 6", nogal = "NOGAL"}

S.room, S.focus = "habitacion", 1
S.cx, S.cy, S.tx, S.ty = 0, 0, 0, 0               -- the camera (the picture's pixel at the screen's top-left) and where it goes
local MAX_X, MAX_Y = 360 - 240, 240 - 160
S.canvas_id = "SALA"

function S.spots() return S.ROOMS[S.room].spots end

local function centre(sp) return sp.x + sp.w // 2, sp.y + sp.h // 2 end
local function clamp(v, lo, hi) return math.max(lo, math.min(hi, v)) end

-- The picture into its canvas, once a room (the flash keeps it packed, the canvas whole).
-- Each studio's own acoustics, for what the keyboard and the foley send to reverb(): the attic wood, the cellar
-- small and dead, the lighthouse a hall, the big studio a large dry room.
local ACOUSTIC = {desvan = {"room", 0.4}, habitacion = {"room", 0.25}, sotano = {"studio_small", 0.3},
                  faro = {"hall", 0.55}, gransala = {"studio_large", 0.45}}

function S.build(room)
  if room == S.built then return end
  S.room, S.built = room or S.room, room or S.room
  local a = ACOUSTIC[S.room]
  if a and reverb then reverb(a[1], a[2]) end
  local r = S.ROOMS[S.room]
  MAX_X, MAX_Y = (r.w or 360) - 240, (r.h or 240) - 160
  S.canvas_id = r.w and "SALA_" .. r.w or "SALA"      -- a canvas keeps its size: one per picture size
  canvas(S.canvas_id, r.image)
  S.focus = math.min(S.focus, #S.spots())
  S.look()
  S.cx, S.cy = S.tx, S.ty
end

-- A machine that is not in the picture, drawn on it: the Golpe 60 sampler, small, on the desk (seen from the chair).
function S.look()                                -- the head turns so the machine in focus is in the middle
  local x, y = centre(S.spots()[S.focus])
  S.tx, S.ty = clamp(x - 120, 0, MAX_X), clamp(y - 96, 0, MAX_Y)
end

function S.cam() return math.floor(S.cx + 0.5), math.floor(S.cy + 0.5) end

function S.aim(hands)
  local x, y = centre(S.spots()[S.focus])
  local cx, cy = S.cam()
  hands.point(x - cx, y - cy, "point")
end

function S.update(ctx)
  local up = btn("up")
  if btnp("up") then ctx.hands.rest_all() end
  if btnr("up") then S.look() end
  if up then S.ty = 0 end                        -- up: the head goes up to the window
  S.cx = S.cx + (S.tx - S.cx) * 0.18
  S.cy = S.cy + (S.ty - S.cy) * 0.18
  scroll(2, S.cam())
  if up then return end
  local d = (btnp("right", 12, 4) and 1 or 0) - (btnp("left", 12, 4) and 1 or 0)
  if d ~= 0 then
    S.focus = (S.focus - 1 + d) % #S.spots() + 1
    S.look()
  end
  S.aim(ctx.hands)
  if btnp("a") then ctx.hands.press(); ctx.go(S.spots()[S.focus].st) end
end

-- A finger (lib/pointer.lua, in screen pixels: the room's are half): a tap on a machine sits down at it; a drag
-- sideways turns the head to the next one (as left/right), once a stroke.
local turned
function S.finger(ctx)
  if pointer.began then turned = false end
  if pointer.down and pointer.stroke and not turned then
    local dx = (pointer.x - pointer.stroke[1][1]) / 2
    if math.abs(dx) >= 14 then
      turned = true
      S.focus = (S.focus - 1 + (dx < 0 and 1 or -1)) % #S.spots() + 1   -- the picture follows the finger
      S.look()
      ctx.hands.rest_all()
    end
  end
  if pointer.tapped then
    local cx, cy = S.cam()
    local spots = {}
    for i, sp in ipairs(S.spots()) do spots[i] = {x = (sp.x - cx) * 2, y = (sp.y - cy) * 2, w = sp.w * 2, h = sp.h * 2, i = i} end
    local hit = pointer.pick(spots, pointer.x, pointer.y)
    if hit then
      S.focus = hit.i
      S.look()
      ctx.hands.press()
      ctx.go(S.spots()[hit.i].st)
    end
  end
end

function S.hint()
  if #S.spots() == 1 then return "A: " .. S.NAME[S.spots()[1].st] .. "   ARRIBA: MIRA" end
  return "< > MIRA   A: " .. S.NAME[S.spots()[S.focus].st]
end

-- The machine in focus framed by four corners that breathe (on the 480x320 overlay, over the picture).
function S.draw()
  if btn("up") then return end
  local sp = S.spots()[S.focus]
  local cx, cy = S.cam()
  local g = 2 + (ticks() // 10) % 2
  local x0, y0 = (sp.x - cx) * 2 - g, (sp.y - cy) * 2 - g
  local x1, y1 = (sp.x + sp.w - cx) * 2 + g, (sp.y + sp.h - cy) * 2 + g
  local L, c = 10, 0xFFE9B0
  rect(x0, y0, L, 2, c); rect(x0, y0, 2, L, c)
  rect(x1 - L, y0, L, 2, c); rect(x1 - 2, y0, 2, L, c)
  rect(x0, y1 - 2, L, 2, c); rect(x0, y1 - L, 2, L, c)
  rect(x1 - L, y1 - 2, L, 2, c); rect(x1 - 2, y1 - L, 2, L, c)
end

function S.has(st)
  for _, sp in ipairs(S.spots()) do if sp.st == st then return true end end
  return false
end

return S
