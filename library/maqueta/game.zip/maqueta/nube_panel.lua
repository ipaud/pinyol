-- Nube 6, the iaia's synth (a Juno-6 seen from above), drawn by code on its own 240x160 canvas: charcoal with
-- wooden cheeks, the coloured stripes under its name, a red LED display, four chord buttons (one a bar), two octaves
-- of keys that light with the chord, BRILLO, the wave switch, PLAY, and the sixteen steps where the chord strikes.
-- Same rules as panel.lua: icons and short names, only what changed is drawn again.
local P = {}

local C = {
  body = 0x2B2C30, body_hi = 0x45474D, body_lo = 0x151618, band = 0x1E1F22, ink = 0x111214, cream = 0xF2EBDD,
  wood = 0x7A4A28, wood_hi = 0x9C6438, wood_lo = 0x4A2A14, red = 0xE0452C, orange = 0xE8742A, yellow = 0xE9B632,
  slot = 0x3A3B40, slot_hi = 0x55575E, slot_off = 0x7A7C84, sel = 0xE9B632, led_off = 0x3a1010, led_on = 0xFF3A1E,
  white = 0xEDE6D6, white_lo = 0xB8B0A0, black = 0x18181A, lit = 0xF0A040, lit_black = 0xC86A20, knob = 0x18191C,
  mark = 0xEDEDE8, icon = 0x9A9EA8, key = 0x5A5D66, key_hi = 0x7A7E88, key_on = 0xE8742A, key_on_hi = 0xFFA060,
  head = 0xFFF4E0, held = 0xFF6A38, held_black = 0xC83C14, lcd = 0x2A0806, lcd_ink = 0xFF6A4A, lcd_edge = 0x120302,
}
P.C = C
P.PANEL = {x = 6, y = 14, w = 228, h = 124}
local LCD = {x = 100, y = 17, w = 104, h = 12}
P.LCD = LCD                                          -- (tests/textos.script: every LCD text fits)
P.KEY_Y = 118
P.SLOT_X, P.SLOT_Y, P.SLOT_W, P.SLOT_H = {16, 60, 104, 148}, 36, 40, 20
local KB = {x = 16, y = 62, n = 14, w = 9, h = 44}   -- two octaves from C3 (MIDI 48)

local BLACK_LEFT = {[1] = 0, [3] = 1, [6] = 3, [8] = 4, [10] = 5}
local WHITE_PC = {0, 2, 4, 5, 7, 9, 11}

P.SPOTS, P.ROWS = {}, {{}, {}, {}}
local function spot(id, row, kind, x, y, w, h, tip, extra)
  local s = {id = id, row = row, kind = kind, x = x, y = y, w = w, h = h, tip = tip}
  for k, v in pairs(extra or {}) do s[k] = v end
  P.SPOTS[id] = s
  table.insert(P.ROWS[row], id)
end
for i = 1, 4 do
  local x = P.SLOT_X[i]
  spot("n" .. i, 1, "slot", x, P.SLOT_Y, P.SLOT_W, P.SLOT_H, {x + 20, P.SLOT_Y + 11}, {slot = i})
end
spot("narp", 1, "button", 192, 38, 30, 14, {207, 45})
spot("nbrillo", 2, "knob", 159, 64, 19, 28, {168, 79}, {cx = 168, cy = 82, r = 8})
spot("nonda", 2, "switch", 190, 70, 22, 9, {201, 74})
spot("nplay", 2, "button", 190, 86, 24, 20, {202, 96})
spot("nvoz", 2, "button", 146, 97, 19, 12, {155, 103})
spot("nrec", 2, "button", 167, 97, 19, 12, {176, 103})
for s = 0, 15 do
  local x = 9 + s * 14
  spot("nstep" .. s, 3, "step", x, P.KEY_Y, 12, 16, {x + 6, P.KEY_Y + 7}, {step = s})
end

-- The key under a finger (MIDI), black keys first; nil off the keyboard.
function P.key_at(x, y)
  if x < KB.x or x >= KB.x + KB.n * KB.w or y < KB.y or y >= KB.y + KB.h then return nil end
  if y < KB.y + 26 then
    for oct = 0, 1 do
      for pc, left in pairs(BLACK_LEFT) do
        local bx = KB.x + (oct * 7 + left + 1) * KB.w - 3
        if x >= bx and x < bx + 5 then return 48 + oct * 12 + pc end
      end
    end
  end
  local k = (x - KB.x) // KB.w
  return 48 + (k // 7) * 12 + WHITE_PC[k % 7 + 1]
end

function P.at(x, y)
  for id, s in pairs(P.SPOTS) do
    if x >= s.x - 1 and x < s.x + s.w + 1 and y >= s.y - 1 and y < s.y + s.h + 1 then return id end
  end
end

function P.move(id, dx, dy)
  local s = P.SPOTS[id]
  if dx ~= 0 then
    local row = P.ROWS[s.row]
    for i, other in ipairs(row) do
      if other == id then return row[(i - 1 + dx) % #row + 1] end
    end
  end
  local r = (s.row - 1 + dy) % 3 + 1
  local best, bd = id, 1e9
  for _, other in ipairs(P.ROWS[r]) do
    local d = math.abs(P.SPOTS[other].tip[1] - s.tip[1])
    if d < bd then best, bd = other, d end
  end
  return best
end

local function body()
  local p = P.PANEL
  rect(p.x + 1, p.y, p.w - 2, p.h, C.body)
  rect(p.x, p.y + 1, p.w, p.h - 2, C.body)
  line(p.x + 1, p.y, p.x + p.w - 2, p.y, C.body_hi)
  line(p.x + 1, p.y + p.h - 1, p.x + p.w - 2, p.y + p.h - 1, C.body_lo)
  for _, x in ipairs({p.x, p.x + p.w - 5}) do                    -- the wooden cheeks
    rect(x, p.y + 1, 5, p.h - 2, C.wood)
    line(x, p.y + 1, x, p.y + p.h - 2, C.wood_hi)
    line(x + 4, p.y + 1, x + 4, p.y + p.h - 2, C.wood_lo)
  end
  rect(p.x + 6, p.y + 2, p.w - 12, 14, C.band)
  text("NUBE 6", 14, 19, {font = "brand", color = C.cream})
  for k, col in ipairs({C.red, C.orange, C.yellow}) do line(p.x + 6, p.y + 16 + k, p.x + p.w - 7, p.y + 16 + k, col) end
  rect(LCD.x - 1, LCD.y - 1, LCD.w + 2, LCD.h + 2, C.lcd_edge)
  local s = P.SPOTS.nbrillo
  for k = 0, 10 do
    local a = math.rad(-135 + 27 * k)
    pset(math.floor(s.cx + math.sin(a) * (s.r + 2) + 0.5), math.floor(s.cy - math.cos(a) * (s.r + 2) + 0.5), C.body_hi)
  end
  for k = 0, 4 do pset(163 + k * 2, 66 - (k % 2), C.icon) end    -- the knob's icon: a sun's rays
  rect(167, 63, 3, 3, C.icon)
  for k = 0, 5 do pset(190 + k, 65 - k % 3, C.icon) end            -- the switch's two waves: saw, square
  line(193, 63, 193, 65, C.icon)
  line(206, 63, 208, 63, C.icon); line(208, 63, 208, 65, C.icon); line(208, 65, 211, 65, C.icon); line(211, 63, 211, 65, C.icon)
  rect(14, P.KEY_Y - 3, 212, 1, C.body_lo)
end

local last = {}
function P.build()
  last = {}
  canvas("PANEL_N", "DESK")
  target("PANEL_N")
  body()
  target()
end

local function changed(key, sig)
  if last[key] == sig then return false end
  last[key] = sig
  return true
end

local NAME = {font = "lcd", color = C.cream, align = "center"}
local NAME_OFF = {font = "lcd", color = C.slot_off, align = "center"}
local function draw_slot(i, chord, selected, now)
  local x, y, w, h = P.SLOT_X[i], P.SLOT_Y, P.SLOT_W, P.SLOT_H
  rect(x - 1, y - 1, w + 2, h + 2, selected and C.sel or C.body_lo)
  rect(x, y, w, h, C.slot)
  line(x, y, x + w - 1, y, C.slot_hi)
  rect(x + w - 6, y + 2, 4, 3, now and C.led_on or C.led_off)
  text(chord and chord or "-", x + w // 2, y - 1, chord and NAME or NAME_OFF)
end

local function draw_keyboard(lit)                    -- lit: MIDI note -> true
  rect(KB.x - 1, KB.y - 1, KB.n * KB.w + 1, KB.h + 2, C.ink)
  for k = 0, KB.n - 1 do
    local oct, idx = k // 7, k % 7
    local pc = ({0, 2, 4, 5, 7, 9, 11})[idx + 1]
    local x = KB.x + k * KB.w
    local l = lit[48 + oct * 12 + pc]
    rect(x, KB.y, KB.w - 1, KB.h, l == 2 and C.held or l and C.lit or C.white)
    line(x, KB.y + KB.h - 3, x + KB.w - 2, KB.y + KB.h - 3, C.white_lo)
  end
  for oct = 0, 1 do
    for pc, left in pairs(BLACK_LEFT) do
      local x = KB.x + (oct * 7 + left + 1) * KB.w - 3
      local l = lit[48 + oct * 12 + pc]
      rect(x, KB.y, 5, 26, l == 2 and C.held_black or l and C.lit_black or C.black)
    end
  end
end

local function draw_knob(s, v)
  circ(s.cx, s.cy, s.r + 1, C.body)
  circ(s.cx + 1, s.cy + 1, s.r, C.body_lo)
  circ(s.cx, s.cy, s.r, C.knob)
  circ(s.cx, s.cy, s.r - 3, 0x2a2a2d)
  local a = math.rad(-135 + 270 * math.max(0, math.min(1, v)))
  line(s.cx, s.cy, math.floor(s.cx + math.sin(a) * (s.r - 1) + 0.5), math.floor(s.cy - math.cos(a) * (s.r - 1) + 0.5), C.mark)
end

local function draw_switch(square)
  local s = P.SPOTS.nonda
  rect(s.x, s.y, s.w, s.h, C.ink)
  rect(s.x + (square and s.w - 11 or 1), s.y + 1, 10, s.h - 2, C.cream)
end

local function draw_play(on)
  local s = P.SPOTS.nplay
  rect(s.x, s.y, s.w, s.h, C.body)
  rect(s.x, s.y, s.w, s.h - 2, on and 0xFFD84A or C.yellow)
  rect(s.x, s.y + s.h - 2, s.w, 2, 0x8A6A14)
  if on then rect(s.x + 9, s.y + 6, 6, 6, C.ink)
  else tri(s.x + 9, s.y + 5, s.x + 9, s.y + 13, s.x + 15, s.y + 9, C.ink) end
end

local function draw_key(st, on, head)
  local x, y = 9 + st * 14, P.KEY_Y
  rect(x - 1, y - 1, 14, 18, C.body)
  local c = on and C.key_on or C.key
  if head then c = on and C.head or C.key_hi end
  rect(x, y, 12, 14, c)
  line(x, y, x + 11, y, on and C.key_on_hi or C.key_hi)
  rect(x + 1, y + 14, 11, 2, C.body_lo)
end

local ARP_LABEL = {[0] = "ARP", "SUBE", "OCHO", "ZIGZ"}
local function draw_arp(mode)
  local s = P.SPOTS.narp
  rect(s.x, s.y, s.w, s.h, C.body_lo)
  rect(s.x, s.y, s.w, s.h - 2, mode > 0 and C.body_hi or C.key)
  line(s.x, s.y, s.x + s.w - 1, s.y, C.key_hi)
  text(ARP_LABEL[mode], s.x + s.w // 2, s.y - 1, {font = "lcd", color = mode > 0 and C.lit or C.slot_off, align = "center"})
end

local function draw_voice(name)
  local s = P.SPOTS.nvoz
  rect(s.x, s.y, s.w, s.h, C.body_lo)
  rect(s.x, s.y, s.w, s.h - 2, C.key)
  line(s.x, s.y, s.x + s.w - 1, s.y, C.key_hi)
  text(name, s.x + s.w // 2, s.y - 1, {font = "lcd", color = C.cream, align = "center"})
end

local function draw_rec(state)                       -- state: 0 off, 1 armed, 2 recording (the music runs)
  local s = P.SPOTS.nrec
  rect(s.x, s.y, s.w, s.h, C.body_lo)
  rect(s.x, s.y, s.w, s.h - 2, state > 0 and C.body_hi or C.key)
  circ(s.x + s.w // 2, s.y + 5, 3, state == 2 and C.led_on or state == 1 and C.red or C.slot_off)
end

local function draw_melody(st, on)                   -- a dot over the step key where the melody has a note
  rect(9 + st * 14 + 4, P.KEY_Y - 6, 4, 2, on and C.held or C.body)
end

local function draw_lcd(str)
  rect(LCD.x, LCD.y, LCD.w, LCD.h, C.lcd)
  text(str, LCD.x + 3, LCD.y - 4, {font = "lcd", color = C.lcd_ink})
end

local SLOT_ID, KEY_ID = {}, {}
for i = 1, 4 do SLOT_ID[i] = "s" .. i end
for k = 0, 15 do KEY_ID[k] = "k" .. k end

-- v = {arp (0 off, 1..3), voice (3 letters), rec (0, 1, 2), mel (step -> MIDI or 0), chords (slot -> chord number, 0 none), names (slot -> its name or nil), sel (slot in hand or nil), now (slot
--      sounding or nil), lit (MIDI -> true), lit_sig, steps, playing, step, bright, square, lcd}
function P.draw(v)
  target("PANEL_N")
  for i = 1, 4 do
    if changed(SLOT_ID[i], v.chords[i] * 4 + (v.sel == i and 2 or 0) + (v.now == i and 1 or 0)) then   -- numbers: no garbage
      draw_slot(i, v.names[i], v.sel == i, v.now == i)
    end
  end
  if changed("kb", v.lit_sig) then draw_keyboard(v.lit) end
  if changed("brillo", v.bright) then draw_knob(P.SPOTS.nbrillo, v.bright) end
  if changed("onda", v.square) then draw_switch(v.square) end
  if changed("play", v.playing) then draw_play(v.playing) end
  for st = 0, 15 do
    local head = v.playing and v.step == st
    if changed(KEY_ID[st], (v.steps[st + 1] > 0 and 1 or 0) + (head and 2 or 0)) then
      draw_key(st, v.steps[st + 1] > 0, head)
    end
  end
  if changed("arp", v.arp) then draw_arp(v.arp) end
  if changed("voz", v.voice) then draw_voice(v.voice) end
  if changed("rec", v.rec) then draw_rec(v.rec) end
  for st = 0, 15 do
    if changed("mel" .. st, v.mel[st + 1] > 0 and 1 or 0) then draw_melody(st, v.mel[st + 1] > 0) end
  end
  if changed("lcd", v.lcd) then draw_lcd(v.lcd) end
  target()
end

return P
