-- Call and response, the game's first lesson and its last scene: the iaia plays, you answer. In the attic it is
-- drums on A, B and C, and the answer must be the same; at the end it is the bridge, her four notes and then
-- yours, any four, kept in the song for good. Big pads on the screen say which button is which, light up as each
-- note sounds (hers too, so you learn them by ear and by eye) and can be played with a finger.
local hands = require("hands")
local pointer = require("pointer")
local dlg = require("dialogo")
local R = {}

local DRUMS = {                                           -- as Ritmo 88's DIRECTO: A, B, C
  {v = 1, key = "a", label = "A", name = "BOMBO", col = 0xE0452C},
  {v = 2, key = "b", label = "B", name = "CAJA", col = 0xE8742A},
  {v = 4, key = "c", label = "C", name = "CHARLES", col = 0xE9E1CF},
}
local NOTES = {                                           -- as Línea 3's DIRECTO; the sixth only with a finger
  {v = 1, key = "a", label = "A"}, {v = 2, key = "left", label = "<"}, {v = 3, key = "b", label = "B"},
  {v = 4, key = "right", label = ">"}, {v = 5, key = "c", label = "C"}, {v = 6, label = ""},
  {v = 7, key = "down", label = "v"}, {v = 8, key = "up", label = "^"},
}
local HAND = {a = "right", b = "right", c = "right", up = "left", down = "left", left = "left", right = "left"}
local ROUNDS = {{1, 2, 1, 2}, {1, 1, 2, 4}, {1, 4, 2, 4, 1, 2}}
R.BRIDGE = {10, 12, 13, 12}                               -- her half, scale degrees of Línea 3 (C E F E)

local PANEL = {x = 36, y = 56, w = 408, h = 240}
local PAD_Y, PAD_H = 186, 98

R.on = nil

local function pads_of(kind) return kind == "pads" and DRUMS or NOTES end

-- Where each pad is on the 480x320 screen.
local function pad_rect(kind, i)
  if kind == "pads" then return 52 + (i - 1) * 130, PAD_Y, 116, PAD_H end
  return 50 + (i - 1) * 48, PAD_Y, 44, PAD_H
end

local function pad_targets(kind) -- the pads as lib/pointer.lua picks among them
  local list = {}
  for i, pad in ipairs(pads_of(kind)) do
    local x, y, w, h = pad_rect(kind, i)
    list[i] = {x = x, y = y, w = w, h = h, pad = pad}
  end
  return list
end

-- kind "pads" or "puente"; done(answer) when it is over
function R.start(kind, done)
  R.on = {kind = kind, round = 1, phase = "call", t = 0, got = {}, done = done, lit = nil, lit_t = 0}
  R.on.call = kind == "pads" and ROUNDS[1] or R.BRIDGE
  hands.rest_all()
end

local function light(r, v) r.lit, r.lit_t = v, 12 end

local function play(r, v, hand)
  if r.kind == "pads" then seq.hit(v, false) else linea.play(v, false) end
  if hand then hands.press(hand) end
end

local function answer(r, pad)
  if #r.got >= #r.call then return end
  local val = r.kind == "pads" and pad.v or pad.v + 7      -- the answer an octave up, where her notes are
  r.got[#r.got + 1] = val
  light(r, pad.v)
  play(r, val, HAND[pad.key or "a"])
end

local GAP = 26
function R.update()
  local r = R.on
  if not r then return end
  pointer.update()
  r.t = r.t + 1
  if r.lit_t > 0 then r.lit_t = r.lit_t - 1 end
  if r.phase == "call" then                              -- she plays, one a beat
    if r.t % GAP == 1 then
      local k = r.t // GAP + 1
      local v = r.call[k]
      if v then
        play(r, v)
        r.k = k
        light(r, r.kind == "pads" and v or v - 7)
      else
        r.phase, r.t, r.k = "answer", 0, nil
      end
    end
  elseif r.phase == "answer" and dlg.auto then
    for i, v in ipairs(r.call) do r.got[i] = v end
    r.phase, r.t = "ok", 0
  elseif r.phase == "answer" then
    for _, pad in ipairs(pads_of(r.kind)) do
      if pad.key and btnp(pad.key) then answer(r, pad) end
    end
    if pointer.began then -- a drum sounds when the finger lands, not when it lifts
      local hit = pointer.pick(pad_targets(r.kind), pointer.x, pointer.y)
      if hit then answer(r, hit.pad) end
    end
    if #r.got == #r.call then
      local same = true
      for i, v in ipairs(r.call) do if r.got[i] ~= v then same = false end end
      r.phase, r.t = (same or r.kind == "puente") and "ok" or "bad", 0
    end
  elseif r.t > 50 then
    if r.phase == "bad" then
      r.phase, r.t, r.got = "call", 0, {}
    elseif r.kind == "pads" and r.round < #ROUNDS then
      r.round = r.round + 1
      r.call, r.phase, r.t, r.got = ROUNDS[r.round], "call", 0, {}
    else
      local got = r.got
      R.on = nil
      r.done(got)
    end
  end
end

local TITLE = {font = "hint", color = 0xFFE9B0, align = "center", shadow = 0x000000}
local LABEL = {font = "hint", color = 0xE9D8B0}
local ROUND = {font = "lcd", color = 0x8A7A60, align = "right"}
local BIG = {font = "hint", scale = 2, color = 0x120E16, align = "center"}
local NAME = {font = "lcd", color = 0x120E16, align = "center"}
local DOT = {font = "hint", color = 0x120E16, align = "center"}

local function dim(c) return (c >> 1) & 0x7F7F7F end
local function pad_of(kind, v)
  for _, p in ipairs(pads_of(kind)) do if p.v == v then return p end end
end

-- A row of the sequence: hers or yours, each note a circle in its pad's colour with its button's letter.
local function row(r, list, y, n, now)
  for i = 1, n do
    local x = 150 + (i - 1) * 40
    circ(x, y, 16, 0x2A2030)
    local v = list[i]
    if v then
      local p = pad_of(r.kind, r.kind == "pads" and v or v - 7)
      local col = r.kind == "pads" and p.col or 0xE9B632
      circ(x, y, 15, (now == nil or now == i) and col or dim(col))
      if p and p.label ~= "" then text(p.label, x, y - 10, DOT) end
    end
  end
end

function R.draw()
  local r = R.on
  if not r then return end
  local P = PANEL
  rect(P.x, P.y, P.w, P.h, 0x120E16)
  box(P.x + 2, P.y + 2, P.w - 4, P.h - 4, 0xE9D8B0)
  local head = r.phase == "call" and "ESCUCHA A LA IAIA..." or r.phase == "answer" and (r.kind == "puente" and "¡CONTESTA! CUATRO NOTAS" or "¡TU TURNO! REPÍTELO") or
               r.phase == "ok" and (r.kind == "puente" and "..." or "¡ESO ES!") or "CASI. OTRA VEZ"
  text(head, 240, P.y + 10, TITLE)
  if r.kind == "pads" then text(r.round .. "/" .. #ROUNDS, P.x + P.w - 12, P.y + 10, ROUND) end
  text("IAIA", P.x + 16, 96, LABEL)
  text("TÚ", P.x + 16, 138, LABEL)
  local shown = {}
  if r.phase == "call" then for i = 1, (r.k or 0) do shown[i] = r.call[i] end else shown = r.call end
  row(r, shown, 106, #r.call, r.phase == "call" and r.k or nil)
  row(r, r.got, 148, #r.call, nil)
  for i, pad in ipairs(pads_of(r.kind)) do               -- the pads: lit when they sound, a finger plays them
    local x, y, w, h = pad_rect(r.kind, i)
    local on = r.lit == pad.v and r.lit_t > 0
    local col = r.kind == "pads" and pad.col or 0xE9E1CF
    rect(x, y + (on and 2 or 0), w, h - 2, on and 0xFFF4C0 or (r.phase == "answer" and col or dim(col)))
    rect(x, y + h - 4, w, 4, dim(dim(col)))
    if r.kind == "pads" then
      text(pad.label, x + w // 2, y + 14 + (on and 2 or 0), BIG)
      text(pad.name, x + w // 2, y + 62 + (on and 2 or 0), NAME)
    elseif pad.label ~= "" then
      text(pad.label, x + w // 2, y + 64 + (on and 2 or 0), DOT)
    end
  end
end

return R
