-- Mesa 8, the mixing desk: eight channels (the drums in five, the bass, the sampler, the keys: Nube and Nogal) with a fader each
-- (8 is as it comes, 10 a quarter louder, 0 gone), MUTE and SOLO. The machines ask it how loud they are:
-- mesa.drum(i) for Ritmo 88's tracks, mesa.gain(ch) for the rest. The LEDs jump with what sounds.
local M = {}
M.panel = require("mesa_panel")
local P = M.panel

M.N = 8
M.NAME = {"BOMBO", "CAJA", "PALMAS", "CHARLES", "PERCUSIÓN", "BAJO", "GOLPE", "TECLAS"}
M.UNITY = 8
local DRUM_CH = {1, 2, 3, 4, 4, 5, 5, 5}               -- Ritmo 88's tracks: the hats share one, tom/aro/cencerro too
M.focus = "f1"

function M.reset()
  M.fader, M.mute, M.solo, M.meter = {}, {}, {}, {}
  for c = 1, M.N do M.fader[c], M.mute[c], M.solo[c], M.meter[c] = M.UNITY, false, false, 0 end
end

function M.soloing()
  for c = 1, M.N do if M.solo[c] then return true end end
  return false
end

function M.gain(ch)
  if M.mute[ch] or (not M.solo[ch] and M.soloing()) then return 0 end
  return M.fader[ch] / M.UNITY
end
function M.drum(i) return M.gain(DRUM_CH[i] or 5) end

-- ===== the LEDs =====

local function peak(ch, v)
  local n = math.min(10, math.floor(v * 8 * M.gain(ch) + 0.5))
  if n > M.meter[ch] then M.meter[ch] = n end
end

local last_step
function M.update()
  if ticks() % 3 == 0 then
    for c = 1, M.N do if M.meter[c] > 0 then M.meter[c] = M.meter[c] - 1 end end
  end
  for i, f in pairs(seq.flash) do if f >= 7 then peak(DRUM_CH[i] or 5, seq.tracks[i].level / 8) end end  -- (a hit by
  for i, n in pairs(golpe.lit) do if n >= 7 then peak(7, golpe.pads[i].level / 8) end end                -- hand is 7 here)
  if not seq.playing or seq.mute then last_step = nil return end
  if seq.step == last_step then return end
  last_step = seq.step
  local s = seq.step + 1
  if linea.deg[s] > 0 and linea.pat ~= 0 then peak(6, linea.acc[s] and 1.1 or 0.9) end
  for i, pd in ipairs(golpe.pads) do if pd.steps[s] > 0 then peak(7, pd.level / 8) end end
  if nube and nube.sounding(s) then peak(8, 0.9) end
  if nogal and nogal.notes[s] > 0 then peak(8, 0.9) end
end

-- ===== playing it =====

function M.aim(h)
  local s = P.SPOTS[M.focus]
  if s.kind == "fader" then h.point(s.tip[1], P.cap_y(M.fader[s.ch]), "pinch") return end
  h.point(s.tip[1], s.tip[2], "point")
end

local function set_fader(ch, v, ctx)
  v = math.max(0, math.min(10, v))
  if v == M.fader[ch] then return end
  M.fader[ch] = v
  hands.twist()
  ctx.touched()
  if M.focus == "f" .. ch then M.aim(hands) end
end
M.set_fader = set_fader

function M.press(id, ctx)
  local s = P.SPOTS[id]
  if s.kind == "mute" then M.mute[s.ch] = not M.mute[s.ch]
  elseif s.kind == "solo" then M.solo[s.ch] = not M.solo[s.ch]
  else return end
  hands.press()
  ctx.touched()
end

function M.input(ctx)
  local s = P.SPOTS[M.focus]
  if s.kind == "fader" and btn("a") then
    if btnp("up", 8, 3) then set_fader(s.ch, M.fader[s.ch] + 1, ctx) end
    if btnp("down", 8, 3) then set_fader(s.ch, M.fader[s.ch] - 1, ctx) end
    if btnp("left", 12, 4) or btnp("right", 12, 4) then          -- A still held: the next channel's fader
      M.focus = P.move(M.focus, btnp("right", 12, 4) and 1 or -1, 0)
      M.aim(hands)
    end
    return
  end
  local dx = (btnp("right", 12, 4) and 1 or 0) - (btnp("left", 12, 4) and 1 or 0)
  local dy = (btnp("down", 12, 4) and 1 or 0) - (btnp("up", 12, 4) and 1 or 0)
  if dx ~= 0 or dy ~= 0 then
    M.focus = P.move(M.focus, dx, dx == 0 and dy or 0)
    M.aim(hands)
  end
  if btnp("a") then M.press(M.focus, ctx) end
end

-- A finger: MUTE and SOLO toggle, a fader follows the finger's height (and a drag sideways takes the next ones).
local drag
function M.touch(tx, ty, first, ctx)
  local id = P.at(tx, ty)
  if first then
    drag = {fader = id and P.SPOTS[id].kind == "fader"}
    if not id then return end
    M.focus = id
    M.aim(hands)
    if not drag.fader then M.press(id, ctx) end
  end
  if not drag or not drag.fader then return end
  if id and P.SPOTS[id].kind == "fader" and M.focus ~= id then M.focus = id end
  set_fader(P.SPOTS[M.focus].ch, P.value_at(ty), ctx)
  M.aim(hands)
end

function M.lcd()
  local s = P.SPOTS[M.focus]
  local name = M.NAME[s.ch]
  if s.kind == "mute" then return fit_lcd(name .. (M.mute[s.ch] and ": MUTE" or ": SUENA"), name .. (M.mute[s.ch] and " MUTE" or " ON")) end
  if s.kind == "solo" then return M.solo[s.ch] and fit_lcd("SOLO " .. name, "SOLO") or "SOLO: NO" end
  return fit_lcd(name .. "  NIVEL " .. M.fader[s.ch], name .. " " .. M.fader[s.ch])
end

local HINTS = {mute = "A MUTE: CALLA EL CANAL   MENU: SALA", solo = "A SOLO: SOLO SUENA ESE   MENU: SALA",
               fader = "MANTÉN A Y SUBE O BAJA   MENU: SALA"}
function M.hint() return HINTS[P.SPOTS[M.focus].kind] end

local view = {}
function M.view(lcd_text)
  local s = P.SPOTS[M.focus]
  view.fader, view.mute, view.solo, view.meter, view.lcd = M.fader, M.mute, M.solo, M.meter, lcd_text
  view.sel = s.kind == "fader" and s.ch or nil
  return view
end

-- ===== kept (not the solos: a solo left on would silence the rest after a restart) =====

function M.save()
  local mutes = {}
  for c = 1, M.N do mutes[c] = M.mute[c] and "x" or "." end
  store("mesa", {fader = M.fader, mute = table.concat(mutes)})
end

function M.load()
  M.reset()
  local t = stored("mesa")
  if type(t) ~= "table" then return end
  if type(t.fader) == "table" then
    for c = 1, M.N do
      local v = t.fader[c]
      if type(v) == "number" then M.fader[c] = math.max(0, math.min(10, math.floor(v))) end
    end
  end
  if type(t.mute) == "string" and #t.mute == M.N then
    for c = 1, M.N do M.mute[c] = t.mute:sub(c, c) == "x" end
  end
end

M.reset()
return M
