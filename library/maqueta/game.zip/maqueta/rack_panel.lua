-- The rack, drawn by code on its own canvas: three units between two rails, as a studio's outboard:
-- ECO 201 (a tape echo, green as a Space Echo's face), PLACA 140 (a plate reverb, cream as an EMT's) and a box the
-- colour of a GBA whose screen is this machine's LCD. Icons, no small words; only what changed is drawn again.
local P = {}

local C = {
  rail = 0x2a2a2e, screw = 0x8a8a90, screw_hole = 0x121214, ink = 0x1a1a1c, shadow = 0x0a080c,
  eco_top = 0x1d1d20, eco = 0x3f6b4a, eco_hi = 0x5d8e68, eco_lo = 0x24402c, chrome = 0xD8D8DC, chrome_lo = 0x8a8a90,
  plate = 0xD8CFB8, plate_hi = 0xEFE8D4, plate_lo = 0x9C937C, gba = 0x5A4FA0, gba_hi = 0x7A70C0, gba_lo = 0x3A3070,
  knob = 0x1d1d1f, mark = 0xEDEDE8, cream = 0xF2EBDD, led_off = 0x3a1010, led_on = 0xFF3A1E, yellow = 0xE9B632,
  lcd = 0x9BBC0F, lcd_ink = 0x0F380F, lcd_edge = 0x1f2a1a,
}
P.C = C
P.PANEL = {x = 6, y = 14, w = 228, h = 124}
local LCD = {x = 110, y = 112, w = 112, h = 12}
P.LCD = LCD                                          -- (tests/textos.script: every LCD text fits)

local ICON = {
  tiempo = {"..###....", ".#...#...", "#..#..#..", "#..##.#..", "#.....#..", ".#...#...", "..###...."},
  repet = {"#........", "#.#......", "#.#.#....", "#.#.#.#..", "#.#.#.#.#", "#.#.#....", "#.#......"},
  tono = {"..#...##.", ".###..#.#", "#.#.#.#..", "..#...#..", "..#.###..", "..#.###..", "........."},
  ritmo = {"..#####..", ".#.....#.", "#..###..#", "#..###..#", "#.......#", ".#.....#.", "..#####.."},
  bajo = {"....#####", "....#...#", "....#...#", "....#...#", ".###..###", "####.####", ".##...##."},
  tamano = {"#########", "#.......#", "#.#####.#", "#.#...#.#", "#.#####.#", "#.......#", "#########"},
  brillo = {"#...#...#", ".#..#..#.", "..#####..", "###...###", "..#####..", ".#..#..#.", "#...#...#"},
  placa = {"#######", "#.....#", "#######", "......."},
  gba = {"#.#.#.#", ".#.#.#.", "#.#.#.#", "......."},
}

local function icon(rows, x, y, colour)
  for r, row in ipairs(rows) do
    for k = 1, #row do
      if row:sub(k, k) == "#" then pset(x + k - 1, y + r - 1, colour) end
    end
  end
end

P.SPOTS, P.ROWS = {}, {{}, {}, {}}
local function spot(id, row, kind, x, y, w, h, tip, extra)
  local s = {id = id, row = row, kind = kind, x = x, y = y, w = w, h = h, tip = tip}
  for k, v in pairs(extra or {}) do s[k] = v end
  P.SPOTS[id] = s
  table.insert(P.ROWS[row], id)
end
local function knob(id, row, cx, cy, look, icon_id)
  spot(id, row, "knob", cx - 9, cy - 18, 19, 28, {cx, cy - 3}, {cx = cx, cy = cy, r = 8, look = look, icon = icon_id})
end
knob("tiempo", 1, 50, 44, "chrome", "tiempo")
knob("repet", 1, 80, 44, "chrome", "repet")
knob("etono", 1, 110, 44, "chrome", "tono")
knob("eco_ritmo", 1, 160, 44, "chrome", "ritmo")
knob("eco_bajo", 1, 190, 44, "chrome", "bajo")
knob("tamano", 2, 50, 86, "black", "tamano")
knob("brillo", 2, 80, 86, "black", "brillo")
spot("modo_rev", 2, "switch", 100, 82, 22, 8, {111, 86})
spot("talkback", 2, "button", 125, 80, 12, 13, {131, 86})
knob("rev_ritmo", 2, 160, 86, "black", "ritmo")
knob("rev_bajo", 2, 190, 86, "black", "bajo")
spot("lofi", 3, "switch", 40, 112, 30, 14, {55, 118})
spot("rplay", 3, "button", 80, 108, 20, 22, {90, 118})

function P.at(x, y)
  for id, s in pairs(P.SPOTS) do
    if x >= s.x - 1 and x < s.x + s.w + 1 and y >= s.y - 1 and y < s.y + s.h + 1 then return id end
  end
end

function P.move(id, dx, dy)
  local s = P.SPOTS[id]
  if dx ~= 0 then
    local row = P.ROWS[s.row]
    for i, other in ipairs(row) do
      if other == id then return row[(i - 1 + dx) % #row + 1] end
    end
  end
  local r = (s.row - 1 + dy) % 3 + 1
  local best, bd = id, 1e9
  for _, other in ipairs(P.ROWS[r]) do
    local d = math.abs(P.SPOTS[other].tip[1] - s.tip[1])
    if d < bd then best, bd = other, d end
  end
  return best
end

local function screws(y)
  for _, x in ipairs({10, 229}) do
    circ(x, y, 2, C.screw)
    pset(x, y, C.screw_hole)
  end
end

local function unit(y, h, face, hi, lo)
  rect(16, y, 208, h, face)
  line(16, y, 223, y, hi)
  line(16, y + h - 1, 223, y + h - 1, lo)
  rect(6, y, 10, h, face)
  rect(224, y, 10, h, face)                                   -- the rack ears
  screws(y + 5)
  screws(y + h - 6)
end

local function body()
  rect(6, 14, 228, 124, C.rail)
  unit(16, 42, C.eco, C.eco_hi, C.eco_lo)
  rect(16, 16, 208, 8, C.eco_top)                             -- the echo's black top and its chrome strip
  line(16, 24, 223, 24, C.chrome)
  text("ECO 201", 20, 15, {font = "brand", color = C.cream})
  unit(60, 42, C.plate, C.plate_hi, C.plate_lo)
  text("PLACA 140", 20, 62, {font = "brand", color = C.ink})
  unit(104, 32, C.gba, C.gba_hi, C.gba_lo)
  text("GBA", 20, 106, {font = "brand", color = C.cream})
  rect(LCD.x - 2, LCD.y - 2, LCD.w + 4, LCD.h + 4, C.lcd_edge)
  for _, id in ipairs({"tiempo", "repet", "etono", "eco_ritmo", "eco_bajo", "tamano", "brillo", "rev_ritmo", "rev_bajo"}) do
    local s = P.SPOTS[id]
    local col = s.row == 1 and C.cream or C.ink
    icon(ICON[s.icon], s.cx - 4, s.cy - 16, col)
    for k = 0, 10 do
      local a = math.rad(-135 + 27 * k)
      pset(math.floor(s.cx + math.sin(a) * (s.r + 2) + 0.5), math.floor(s.cy - math.cos(a) * (s.r + 2) + 0.5), col)
    end
  end
  line(140, 30, 140, 56, C.eco_lo)                            -- the sends, apart from the echo's own knobs
  line(140, 72, 140, 100, C.plate_lo)
  icon(ICON.placa, 100, 74, C.ink)
  icon(ICON.gba, 115, 74, C.ink)
  text("TB", 124, 70, {font = "brand", color = C.ink})
end

local last = {}

function P.build()
  last = {}
  canvas("PANEL_R", "DESK")
  target("PANEL_R")
  body()
  target()
end

local function changed(key, sig)
  if last[key] == sig then return false end
  last[key] = sig
  return true
end

local function draw_knob(s, v)
  local face = s.row == 1 and C.eco or C.plate
  circ(s.cx, s.cy, s.r + 1, face)
  circ(s.cx + 1, s.cy + 1, s.r, C.shadow)
  circ(s.cx, s.cy, s.r, s.look == "chrome" and C.chrome or C.knob)
  circ(s.cx, s.cy, s.r - 3, s.look == "chrome" and 0xB8B8BE or 0x2a2a2d)
  pset(s.cx - s.r // 2, s.cy - s.r // 2, 0xFFFFFF)
  local a = math.rad(-135 + 270 * math.max(0, math.min(1, v)))
  line(s.cx, s.cy, math.floor(s.cx + math.sin(a) * (s.r - 1) + 0.5), math.floor(s.cy - math.cos(a) * (s.r - 1) + 0.5),
       s.look == "chrome" and C.ink or C.mark)
end

local function draw_switch(id, right)
  local sw = P.SPOTS[id]
  rect(sw.x, sw.y, sw.w, sw.h, C.ink)
  local w = id == "lofi" and 13 or 10
  rect(sw.x + (right and sw.w - w - 1 or 1), sw.y + 1, w, sw.h - 2, C.cream)
  if id == "lofi" then rect(sw.x + sw.w + 4, sw.y + 4, 4, 4, right and C.led_on or C.led_off) end
end

local function draw_play(on)
  local play = P.SPOTS.rplay
  rect(play.x, play.y, play.w, play.h, C.gba)
  rect(play.x, play.y, play.w, play.h - 2, on and 0xFFD84A or C.yellow)
  line(play.x, play.y, play.x + play.w - 1, play.y, 0xFFE9A0)
  rect(play.x, play.y + play.h - 2, play.w, 2, 0x8A6A14)
  if on then rect(play.x + 7, play.y + 7, 6, 6, C.ink)
  else tri(play.x + 7, play.y + 5, play.x + 7, play.y + 13, play.x + 13, play.y + 9, C.ink) end
end

local function draw_talkback(on)
  local sw = P.SPOTS.talkback
  rect(sw.x, sw.y, sw.w, sw.h, C.ink)
  rect(sw.x + 1, sw.y + 1, sw.w - 2, sw.h - 2, on and C.led_on or C.chrome_lo)
  rect(sw.x + 4, sw.y + 3, 4, 5, C.ink)
  line(sw.x + 6, sw.y + 8, sw.x + 6, sw.y + 10, C.ink)
end

local function draw_lcd(str)
  rect(LCD.x, LCD.y, LCD.w, LCD.h, C.lcd)
  text(str, LCD.x + 3, LCD.y - 4, {font = "lcd", color = C.lcd_ink})
end

-- v = {knobs = {id = 0..1}, gba (reverb mode), gate, lofi, playing, lcd}
function P.draw(v)
  target("PANEL_R")
  for id, val in pairs(v.knobs) do
    if changed(id, val) then draw_knob(P.SPOTS[id], val) end
  end
  if changed("modo_rev", v.gba) then draw_switch("modo_rev", v.gba) end
  if changed("talkback", v.gate) then draw_talkback(v.gate) end
  if changed("lofi", v.lofi) then draw_switch("lofi", v.lofi) end
  if changed("play", v.playing) then draw_play(v.playing) end
  if changed("lcd", v.lcd) then draw_lcd(v.lcd) end
  target()
end

return P
