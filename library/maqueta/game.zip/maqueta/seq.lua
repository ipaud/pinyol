-- Ritmo 88's brain: eight drum tracks of 16 steps, their sounds, the euclidean generator, the "variants"
-- button, recording from the pads or the microphone. The pattern lives here; the engine's studio plays it
-- (every step on its sample, any tempo). On a firmware without the studio, the game's ticks play it.
local M = {}

M.INSTS = {
  {id = "BOMBO", name = "BOMBO", col = 0xE0452C},
  {id = "CAJA", name = "CAJA", col = 0xE8742A},
  {id = "PALMAS", name = "PALMAS", col = 0xE9B632},
  {id = "CHARLES", name = "CHARLES", col = 0xE9E1CF},
  {id = "ABIERTO", name = "ABIERTO", col = 0xE9E1CF},
  {id = "TOM", name = "TOM", col = 0xE9B632},
  {id = "ARO", name = "ARO", col = 0xE8742A},
  {id = "CENCERRO", name = "CENCERRO", col = 0xE0452C},
}
local CLOSED, OPEN = 4, 5
M.DECAY_TAG = {"C", "M", "L"}
M.BPM_MIN, M.BPM_MAX, M.SWING_MIN, M.SWING_MAX = 60, 180, 50, 74
local MASTER = 0.62                   -- headroom: several drums at once stay under the limiter
local ACCENT, NORMAL = 1, 0.72
M.engine = studio ~= nil              -- ponytail: the tick clock goes once every console has the studio

-- The pattern the machine still had in it when it came out of the attic: no blank canvas.
local SEED = {
  BOMBO = "x.....x...x.....", CAJA = "....X.......X...", CHARLES = "x.x.x.x.x.x.x.X.",
  ABIERTO = "..............x.", ARO = ".......x........",
}

local function blank()
  local t = {}
  for s = 1, 16 do t[s] = 0 end
  return t
end

local function copy(t)
  local c = {}
  for k, v in ipairs(t) do c[k] = v end
  return c
end

local function from_text(str)
  local t = blank()
  for s = 1, 16 do
    local ch = str:sub(s, s)
    t[s] = ch == "X" and 2 or (ch == "x" and 1 or 0)
  end
  return t
end

local function to_text(steps)
  local out = {}
  for s = 1, 16 do out[s] = steps[s] == 2 and "X" or (steps[s] == 1 and "x" or ".") end
  return table.concat(out)
end

function M.count(steps)
  local c = 0
  for s = 1, 16 do if steps[s] > 0 then c = c + 1 end end
  return c
end

-- k hits spread as evenly as they go over n steps, turned by rot (Toussaint 2005): E(3,8) is the tresillo.
function M.euclid(k, n, rot)
  local t = {}
  for s = 0, n - 1 do
    local i = (s - rot) % n
    t[s + 1] = (i * k) % n < k and 1 or 0
  end
  return t
end

M.NPAT = 4                                     -- patterns A to D; 0 in a song is silence
function M.reset()
  M.tempo, M.swing = 112, 56
  M.tracks, M.pats, M.pat = {}, {{}, {}, {}, {}}, 1
  for i, inst in ipairs(M.INSTS) do
    local steps = SEED[inst.id] and from_text(SEED[inst.id]) or blank()
    M.tracks[i] = {steps = steps, tune = 0, level = 8, decay = 2, dens = M.count(steps), rot = 0}
    M.pats[1][i] = steps
  end
  M.queued = false
  M.playing, M.step, M.clock, M.mute = false, 15, 0, false
  M.flash, M.skip, M.hold, M.sent = {}, {}, {}, {}
  M.cap = nil
end

function M.bpm() return M.tempo end
function M.swing_pct() return M.swing end

local function sound_of(i) return M.INSTS[i].id .. "_" .. M.DECAY_TAG[M.tracks[i].decay] end
M.volume = 1                                   -- the game's own volume (the bench plays quietly)
local function mix_of(i) return mesa and mesa.drum(i) or 1 end  -- the mixer's channel (mesa.lua), when there is one
local function gain_of(i) return M.mute and 0 or M.tracks[i].level / 10 * MASTER * M.volume * mix_of(i) end
local function pitch_of(i) return 2 ^ (M.tracks[i].tune / 12) end

-- The game's tick clock, for a firmware without the studio: the nearest whole number of ticks a step.
local function len() return math.max(4, math.floor(900 / M.tempo + 0.5)) end
local function step_time(s)
  local l = len()
  return s * l + (s % 2 == 1 and math.min(math.floor((M.swing - 50) / 50 * l + 0.5), l // 2 - 1) or 0)
end

local function vel_of(steps)
  local vel = {}
  for k = 1, 16 do vel[k] = steps[k] == 2 and ACCENT or (steps[k] == 1 and NORMAL or 0) end
  return vel
end

-- What the studio has of each track, so only what changed is sent to it. Run every tick: numbers and
-- bit masks only, no strings or tables unless something changed (the console's Lua has 16 ms a frame).
local function sync()
  for i, tr in ipairs(M.tracks) do
    local sent = M.sent[i]
    if not sent then sent = {}; M.sent[i] = sent end
    local mix = mix_of(i)
    if sent.tune ~= tr.tune or sent.level ~= tr.level or sent.decay ~= tr.decay or sent.mute ~= M.mute or sent.mix ~= mix then
      local s = sound_of(i)
      studio.track(i, {sound = s ~= sent.sound and s or nil, gain = gain_of(i), pitch = pitch_of(i),
                       choke = (i == CLOSED or i == OPEN) and 1 or 0})
      sent.sound, sent.tune, sent.level, sent.decay, sent.mute, sent.mix = s, tr.tune, tr.level, tr.decay, M.mute, mix
    end
    local on, acc, st = 0, 0, tr.steps
    for k = 1, 16 do
      local v = st[k]
      if v > 0 then
        on = on | (1 << k)
        if v == 2 then acc = acc | (1 << k) end
      end
    end
    if (sent.on ~= on or sent.acc ~= acc) and M.hold[i] == nil and not M.queued then -- a hit ahead of its step, or a
      -- pattern queued for the bar line, waits
      studio.steps(i, vel_of(st))
      sent.on, sent.acc = on, acc
    end
  end
end

function M.hit(i, accent)
  M.flash[i] = 8
  if M.engine then sync(); studio.hit(i, accent and ACCENT or NORMAL) return end
  local gain = gain_of(i) * (accent and ACCENT or NORMAL)
  if gain <= 0 then return end
  if i == CLOSED and M.open_h then sfx_stop(M.open_h) end -- the closed hat chokes the open one, as on an 808
  local h = sfx(sound_of(i), gain, {pitch = pitch_of(i)})
  if i == OPEN then M.open_h = h end
end

-- Recording claps from the microphone: a bar to count in (heard), a bar to listen (the speaker quiet,
-- or it would hear itself), then the part plays back. The studio plays ahead of what is heard, so it
-- goes quiet on the count's last step and comes back on the listening bar's last step.
local function capture_step(s)
  local c = M.cap
  if s == 15 then
    if c.phase == "count" and c.started then M.mute = true end
    if c.phase == "rec" then M.mute = false end
  elseif s == 0 then
    if c.phase == "count" and c.started then
      c.phase, M.mute = "rec", true
      M.set_steps(c.inst, blank())
    elseif c.phase == "rec" then
      M.cap, M.mute = nil, false
      if M.on_capture then M.on_capture(c.inst) end
      return
    end
    c.started = true
  end
end

local function arrive(s)                       -- a new step is heard
  M.step = s
  if M.on_heard then M.on_heard(s) end         -- the song: its sections change on the bar line
  for i, t in pairs(M.hold) do if t == s then M.hold[i] = nil end end
  if M.cap then capture_step(s) end
  if M.engine then
    for i, tr in ipairs(M.tracks) do if tr.steps[s + 1] > 0 and not M.mute then M.flash[i] = 8 end end
  end
  if M.on_step then M.on_step(s) end
end

local function fire(s)                         -- the tick clock: play the step's hits, then it is heard
  arrive(s)
  if M.on_fire then M.on_fire(s) end           -- the bass, on a firmware without the studio
  for i, tr in ipairs(M.tracks) do
    if M.skip[i] == s then
      M.skip[i] = nil                          -- just played by hand: do not play it twice
    elseif tr.steps[s + 1] > 0 and not M.mute then
      M.hit(i, tr.steps[s + 1] == 2)
    end
  end
end

function M.update()
  for i, f in pairs(M.flash) do M.flash[i] = f > 1 and f - 1 or nil end
  if M.engine then
    sync()
    local s = studio.pos()
    if M.playing and s and s - 1 ~= M.step then arrive(s - 1) end
    return
  end
  if not M.playing then return end
  if M.clock == step_time((M.step + 1) % 16) then fire((M.step + 1) % 16) end
  M.clock = (M.clock + 1) % (16 * len())
end

function M.start()
  M.playing, M.step, M.clock, M.hold = true, 15, 0, {}
  if M.engine then sync(); studio.tempo(M.tempo, M.swing); studio.play() end
end

function M.stop()
  M.playing, M.mute, M.cap = false, false, nil
  if M.engine then studio.stop() end
end

function M.set_tempo(bpm)
  M.tempo = math.max(M.BPM_MIN, math.min(M.BPM_MAX, bpm))
  if M.engine then studio.tempo(M.tempo, M.swing)
  else M.clock = (step_time(M.step) + 1) % (16 * len()) end -- carry on from the same step
end

function M.set_swing(pct)
  M.swing = math.max(M.SWING_MIN, math.min(M.SWING_MAX, pct))
  if M.engine then studio.tempo(M.tempo, M.swing) end
end

-- The step nearest to what is heard now, for a hit played by hand or heard by the microphone.
function M.nearest()
  if M.engine then
    local s, f = studio.pos()
    if not s then return 0 end
    return (s - 1 + (f >= 0.5 and 1 or 0)) % 16
  end
  return math.floor(M.clock / len() + 0.5) % 16
end

function M.record(i, accent)
  local s = M.nearest()
  M.tracks[i].steps[s + 1] = accent and 2 or 1
  M.tracks[i].vars = nil
  if s ~= M.step then                          -- it has not sounded yet this bar: it just did, by hand
    if M.engine then M.hold[i] = s else M.skip[i] = s end
  end
  return s
end

-- Edit and play pattern p (1-4): a pattern never used starts as a copy of the one before, so a variation is one
-- step away. 0 is silence (a song's section without drums): nothing to edit there.
function M.select(p)
  if M.pat > 0 then for i, tr in ipairs(M.tracks) do M.pats[M.pat][i] = tr.steps end end
  if p > 0 and not M.pats[p][1] then
    for i, tr in ipairs(M.tracks) do M.pats[p][i] = copy(tr.steps) end
  end
  M.pat, M.queued = p, false
  for i, tr in ipairs(M.tracks) do
    tr.steps, tr.vars = p > 0 and M.pats[p][i] or blank(), nil
    tr.dens = M.count(tr.steps)
  end
end

-- A song's next section: pattern p goes to the studio for the next bar line; select(p) follows when it is heard.
function M.queue(p)
  if not M.engine then return end
  if M.pat > 0 then for i, tr in ipairs(M.tracks) do M.pats[M.pat][i] = tr.steps end end
  for i = 1, #M.tracks do studio.steps(i, vel_of(p > 0 and M.pats[p][i] or blank()), true) end
  M.queued = true
end

function M.used(p) return p > 0 and M.pats[p][1] ~= nil end

function M.set_steps(i, steps)
  local tr = M.tracks[i]
  tr.steps, tr.vars = steps, nil
end

function M.apply_euclid(i)
  local tr = M.tracks[i]
  M.set_steps(i, M.euclid(tr.dens, 16, tr.rot))
end

local function mutate(steps, kind)
  local k = M.count(steps)
  if kind == 1 then return M.euclid(math.max(k, 3), 16, 2) end -- as many hits, spread and moved
  local out = copy(steps)
  if kind == 2 then                                            -- one hit nudged on, one ghost note
    for _ = 1, 2 do
      local s = math.random(16)
      if out[s] > 0 then
        out[s % 16 + 1], out[s] = out[s], 0
      else
        out[s] = 1
      end
    end
    return out
  end
  for s = 1, 15, 2 do                                          -- denser: each hit answered on the offbeat
    if steps[s] > 0 then out[s + 1] = 1 end
  end
  if M.count(out) == k then return M.euclid(math.min(16, k + 3), 16, 0) end
  return out
end

-- C: the same part one step away (Compton & Mateas 2015, "mutant shopping"). The original is
-- always one of them, so pressing C round the cycle gets back to where you were.
function M.next_variant(i)
  local tr = M.tracks[i]
  if not tr.vars then
    tr.vars = {copy(tr.steps), mutate(tr.steps, 1), mutate(tr.steps, 2), mutate(tr.steps, 3)}
    tr.var = 1
  end
  tr.var = tr.var % #tr.vars + 1
  tr.steps = copy(tr.vars[tr.var])
  return tr.var - 1                            -- 0: the original
end

function M.capture(i)
  M.cap = {inst = i, phase = "count"}
  M.start()
end

function M.capture_hit()
  local c = M.cap
  if c and c.phase == "rec" then return M.record(c.inst, false) end
end

function M.save()
  if M.pat > 0 then for i, tr in ipairs(M.tracks) do M.pats[M.pat][i] = tr.steps end end
  local t = {bpm = M.tempo, swing_pct = M.swing, pat = M.pat, tracks = {}, pats = {}}
  for i, tr in ipairs(M.tracks) do
    t.tracks[i] = {tune = tr.tune, level = tr.level, decay = tr.decay, dens = tr.dens, rot = tr.rot}
  end
  for p = 1, M.NPAT do
    if M.pats[p][1] then
      local texts = {}
      for i = 1, #M.tracks do texts[i] = to_text(M.pats[p][i]) end
      t.pats[p] = texts
    else
      t.pats[p] = false
    end
  end
  store("patron", t)
end

local function num(v, lo, hi, default)
  if type(v) ~= "number" or v ~= v then return default end
  return math.max(lo, math.min(hi, math.floor(v)))
end

function M.load()
  M.reset()
  local t = stored("patron")
  if type(t) ~= "table" or type(t.tracks) ~= "table" then return false end
  M.tempo = num(t.bpm, M.BPM_MIN, M.BPM_MAX, M.tempo)
  M.swing = num(t.swing_pct, M.SWING_MIN, M.SWING_MAX, M.swing)
  for i, tr in ipairs(M.tracks) do
    local s = t.tracks[i]
    if type(s) == "table" then
      if type(s.steps) == "string" and #s.steps == 16 then tr.steps = from_text(s.steps); M.pats[1][i] = tr.steps end
      tr.tune, tr.level = num(s.tune, -12, 12, 0), num(s.level, 0, 10, 8)
      tr.decay, tr.dens, tr.rot = num(s.decay, 1, 3, 2), num(s.dens, 0, 16, 0), num(s.rot, 0, 15, 0)
    end
  end
  if type(t.pats) == "table" then                -- the four patterns (a save from before them has only one)
    for p = 1, M.NPAT do
      local texts = t.pats[p]
      M.pats[p] = {}
      if type(texts) == "table" then
        for i = 1, #M.tracks do
          M.pats[p][i] = type(texts[i]) == "string" and #texts[i] == 16 and from_text(texts[i]) or blank()
        end
      end
    end
    if not M.pats[1][1] then for i = 1, #M.tracks do M.pats[1][i] = blank() end end
    for i, tr in ipairs(M.tracks) do tr.steps = M.pats[1][i] end -- A is in hand, then the one saved as current
    M.pat = 1
    M.select(num(t.pat, 1, M.NPAT, 1))
  end
  return true
end

M.reset()
return M
