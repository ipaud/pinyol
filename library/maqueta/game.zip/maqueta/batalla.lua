-- The beat battle at La Nave, chapter 4: Brillo plays two bars, you answer two in DIRECTO over the house groove
-- (Ritmo 88's buttons), three rounds, and the crowd votes. Each hit counts by how close it falls to its step
-- (a mashed button loses points), each different instrument adds, and claps from the crowd (the microphone) too.
-- Lose and Brillo asks for the rematch. Your patterns, tempo and mix are put back as they were; nothing is saved.
local B = {}

local ROUNDS = 3
local BRILLO = {30, 38, 34}                               -- his rounds: a tidy player beats them, a masher barely
local TEMPO = 108
local PADS = {a = 1, b = 2, c = 4, up = 5, down = 6, left = 7, right = 3}  -- as Ritmo 88's DIRECTO
local HAND = {a = "right", b = "right", c = "right", up = "left", down = "left", left = "left", right = "left"}
local KEYS = {"a", "b", "c", "right", "up", "down", "left"}
local LABEL = {a = "A", b = "B", c = "C", right = ">", up = "^", down = "v", left = "<"}
local HIT_CAP = 24                                        -- hits counted a turn
local CLAP_CAP = 6

local function row(...)                                   -- a track's 16 steps from the steps that sound (2: accent)
  local t = {}
  for k = 1, 16 do t[k] = 0 end
  for _, s in ipairs({...}) do if s < 0 then t[-s] = 2 else t[s] = 1 end end
  return t
end
-- Brillo's three beats (steps 1-16; negative: accented), and the house groove you play over.
local PATTERNS = {
  {row(-1, 7, 11), row(-5, -13), nil, row(1, 3, 5, 7, 9, 11, 13, 15)},                                    -- boom bap
  {row(-1, 4, 7, -11, 14), row(-5, -13), row(13), row(-1, 2, 3, 4, -5, 6, 7, 8, -9, 10, 11, 12, -13, 14, 15, 16),
   nil, nil, nil, row(8, 16)},                                                                              -- busy
  {row(-1, 3, 7, 9, 11), row(-5, 13, 15, 16), nil, row(1, 5, 9, 13), row(8), row(12, 14), row(3, 10)},   -- showing off
}
local HOUSE = {row(-1, 5, -9, 13), nil, nil, row(3, 7, 11, 15)}

B.on = nil
local SAID = {font = "hint", color = 0x9FE07A, align = "center", shadow = 0x000000}   -- a hit's verdict

local function vel(steps)
  local v = {}
  for k = 1, 16 do v[k] = steps[k] == 2 and 1 or (steps[k] == 1 and 0.72 or 0) end
  return v
end

local EMPTY = row()
-- The pattern for the next bar line: queued on the studio (as a song's next section), in the tracks once heard.
local function queue(b, pat)
  if seq.engine then
    for i = 1, 8 do studio.steps(i, vel(pat[i] or EMPTY), true) end
    seq.queued = true
  end
  b.next = pat
end

-- The battle bar by bar: a bar of the house groove, then each round Brillo's two, your two, the crowd's vote.
local function plan()
  local p = {{phase = "intro", pat = HOUSE, round = 1}}
  for r = 1, ROUNDS do
    p[#p + 1] = {phase = "brillo", pat = PATTERNS[r], round = r}
    p[#p + 1] = {phase = "brillo", pat = PATTERNS[r], round = r}
    p[#p + 1] = {phase = "tu", pat = HOUSE, round = r, left = 2}
    p[#p + 1] = {phase = "tu", pat = HOUSE, round = r, left = 1}
    p[#p + 1] = {phase = "voto", pat = HOUSE, round = r}
  end
  return p
end

local function begin(b)
  b.plan, b.k, b.you, b.him, b.last, b.next, b.queued_k, b.started = plan(), 1, 0, 0, nil, nil, nil, false
  for i = 1, 8 do seq.set_steps(i, HOUSE[i] or EMPTY) end
  seq.start()
end

function B.start(done)
  local b = {done = done, t = 0, lit = {}, phase = "intro",
             saved = {tempo = seq.tempo, mode = song.mode, steps = {}, vars = {}, mute = {}}}
  for i = 1, 8 do b.saved.steps[i], b.saved.vars[i] = seq.tracks[i].steps, seq.tracks[i].vars end
  for c = 6, 8 do b.saved.mute[c] = mesa.mute[c]; mesa.mute[c] = true end   -- the bass, the sampler, the Nube quiet
  song.mode = "patron"
  if seq.playing then seq.stop() end
  seq.set_tempo(TEMPO)
  hands.rest_all()
  begin(b)
  B.on = b
end

local function finish(b)
  for i = 1, 8 do seq.set_steps(i, b.saved.steps[i]); seq.tracks[i].vars = b.saved.vars[i] end
  for c = 6, 8 do mesa.mute[c] = b.saved.mute[c] end
  seq.stop()
  seq.queued = false
  seq.set_tempo(b.saved.tempo)
  song.mode = b.saved.mode
  mic(false)
  B.on = nil
  b.done(true)
end

-- A hit of yours: its instrument sounds, and on your turn it counts by how close it fell to its step.
local function hit(b, key)
  local inst = PADS[key]
  seq.hit(inst, false)
  hands.press(HAND[key])
  b.lit[inst] = 8
  if b.phase ~= "tu" or b.hits >= HIT_CAP then return end
  b.hits = b.hits + 1
  local err = 0
  if seq.engine then
    local _, f = studio.pos()
    err = f and math.min(f, 1 - f) or 0
  end
  local pts = err < 0.2 and 2 or err < 0.35 and 1 or -1
  b.turn = b.turn + pts
  b.used[inst] = true
  b.said, b.said_t = pts == 2 and "¡CLAVADO!" or pts == 1 and "BIEN" or "A DESTIEMPO", 30
  SAID.color = pts == 2 and 0x9FE07A or pts == 1 and 0xE9B632 or 0xFF6A50
end

local function score(b)                                   -- your turn's points: hits, variety, the crowd
  local kinds = 0
  for _ in pairs(b.used) do kinds = kinds + 1 end
  return math.max(0, b.turn) + 3 * math.min(4, kinds) + math.min(CLAP_CAP, b.claps)
end

local function bar_line(b)                                -- a new bar is heard
  if b.next then
    for i = 1, 8 do seq.set_steps(i, b.next[i] or EMPTY) end
    seq.queued, b.next = false, nil
  end
  local was = b.plan[b.k]
  b.k = b.k + 1
  local now = b.plan[b.k]
  if not now then
    b.phase, b.t = b.you > b.him and "gana" or "pierde", 0
    seq.stop()
    return
  end
  if now.phase == "tu" and was.phase ~= "tu" then b.turn, b.hits, b.claps, b.used = 0, 0, 0, {} end
  if now.phase == "voto" then
    b.mine, b.his = score(b), BRILLO[now.round]
    b.you, b.him = b.you + b.mine, b.him + b.his
  end
  b.phase = now.phase
end

function B.update()
  local b = B.on
  if not b then return end
  b.t = b.t + 1
  for i, n in pairs(b.lit) do b.lit[i] = n > 1 and n - 1 or nil end
  if b.said_t and b.said_t > 0 then b.said_t = b.said_t - 1 end
  if b.phase == "gana" or b.phase == "pierde" then
    if b.t > 150 then
      if b.phase == "gana" then finish(b) return end
      b.phase, b.t = "intro", 0                       -- the rematch
      begin(b)
    end
    return
  end
  if dlg.auto and b.t > 120 then                       -- the autopilot wins
    seq.stop()
    b.you, b.him, b.phase, b.t = 1, 0, "gana", 140
    return
  end
  local s = seq.step
  if b.last and s < b.last then                         -- (the first step after the start is not a new bar)
    if b.started then bar_line(b) else b.started = true end
  end
  if b.phase == "gana" or b.phase == "pierde" then return end
  local nxt = b.plan[b.k + 1]
  if s >= 8 and b.queued_k ~= b.k and nxt and nxt.pat ~= b.plan[b.k].pat then   -- the next bar's, for its bar line
    queue(b, nxt.pat)
    b.queued_k = b.k
  end
  b.last = s
  for _, k in ipairs(KEYS) do if btnp(k) then hit(b, k) end end
  if b.phase == "tu" then
    local _, _, clap = mic()
    if clap and b.claps < CLAP_CAP then b.claps = b.claps + 1; cine.flash(2) end
  end
end

-- ===== drawing =====

local TITLE = {font = "hint", color = 0xFFE9B0, align = "center", shadow = 0x000000}
local BIG = {font = "hint", color = 0xFFFFFF, align = "center", scale = 2, shadow = 0x5A2A10}
local SMALL = {font = "lcd", color = 0xE9D8B0, align = "center", shadow = 0x000000}
local NAME_L = {font = "hint", color = 0xFFE9B0, shadow = 0x000000}
local NAME_R = {font = "hint", color = 0xFFE9B0, align = "right", shadow = 0x000000}
local KEY = {font = "hint", color = 0x120E16, align = "center"}
local INST = {"BOMBO", "CAJA", "PALMAS", "CHARLES", "ABIERTO", "TOM", "ARO"}
local COL = {0xE0452C, 0xE8742A, 0xE9B632, 0xE9E1CF, 0xE9E1CF, 0xE9B632, 0xE8742A}

local function tug(b)                                      -- the crowd's vote: a bar pulled to whoever leads
  local x, y, w = 124, 34, 232
  rect(x, y, w, 14, 0x120E16)
  box(x, y, w, 14, 0x8A7A60)
  local lead = math.max(-1, math.min(1, (b.you - b.him) / 40))
  local mid = x + w // 2 + math.floor(lead * (w // 2 - 4))
  rect(x + 2, y + 2, mid - x - 2, 10, 0x60C0FF)
  rect(mid, y + 2, x + w - 2 - mid, 10, 0xFF5040)
  line(x + w // 2, y - 2, x + w // 2, y + 15, 0xFFFFFF)
  text("TÚ " .. b.you, x - 6, y - 2, NAME_R)
  text(b.him .. " BRILLO", x + w + 6, y - 2, NAME_L)
end

function B.draw()
  local b = B.on
  if not b then return end
  local now = b.plan[b.k] or b.plan[#b.plan]
  text("BATALLA EN LA NAVE · RONDA " .. now.round .. "/" .. ROUNDS, 240, 4, TITLE)
  tug(b)
  local msg, sub
  if b.phase == "intro" then msg = "¡PREPÁRATE!"
  elseif b.phase == "brillo" then msg, sub = "BRILLO...", "ESCUCHA SU RITMO"
  elseif b.phase == "tu" then
    msg, sub = "¡TU TURNO!", (now.left == 1 and "ÚLTIMO COMPÁS" or "2 COMPASES") .. ": A TIEMPO Y CON VARIOS INSTRUMENTOS"
  elseif b.phase == "voto" then msg, sub = "TÚ " .. b.mine .. "  BRILLO " .. b.his, "LA GENTE VOTA"
  elseif b.phase == "gana" then msg = "¡LA NAVE ES TUYA!"
  else msg, sub = "GANA BRILLO", "¡REVANCHA!" end
  rect(0, 62, 480, sub and 64 or 42, 0x120E16)              -- a band for the words over the crowd
  text(msg, 240, 66, BIG)
  if sub then text(sub, 240, 104, SMALL) end
  if b.phase == "tu" and b.said_t and b.said_t > 0 then text(b.said, 240, 134, SAID) end
  for k, key in ipairs(KEYS) do                           -- the pads, as on the Ritmo's DIRECTO
    local inst = PADS[key]
    local x, y = 18 + (k - 1) * 64, 262
    local on = b.lit and b.lit[inst]
    rect(x, y + (on and 2 or 0), 58, 40, on and 0xFFF4C0 or COL[inst])
    text(LABEL[key], x + 29, y + 2 + (on and 2 or 0), KEY)
    text(INST[inst], x + 29, y + 22 + (on and 2 or 0), {font = "lcd", color = 0x120E16, align = "center"})
  end
end

return B
