-- The hero's journey, room by room: the chapters, what each client asks for (checked on the machines' state),
-- and the [do] functions story/es.txt calls to move the game (globals: the story's code sees the game's globals).
local cine = require("cine")
local dlg = require("dialogo")
local respuesta = require("respuesta")
local keyboard = require("keyboard")
local H = {}

H.CAP = {
  [0] = {title = "EL DESVÁN", room = "desvan"},
  [1] = {title = "LA HABITACIÓN", room = "habitacion"},
  [2] = {title = "EL SÓTANO", room = "sotano"},
  [3] = {title = "EL FARO", room = "faro"},
  [4] = {title = "LA GRAN SALA", room = "gransala"},
  [5] = {title = "MAQUETA", room = "desvan"},
  [6] = {title = "ESTUDI REMEI", room = "gransala"},   -- the epilogue: free, every studio
}
H.ROOMS = {"desvan", "habitacion", "sotano", "faro", "gransala"}

local function hits(i) return seq.count(seq.tracks[i].steps) end
local function linea_count(field)
  local n = 0
  for s = 1, 16 do if linea.deg[s] > 0 and linea[field][s] then n = n + 1 end end
  return n
end
local function drum_pats_used()
  local seen, n = {}, 0
  for _, sec in ipairs(song.sections) do
    if sec.d > 0 and not seen[sec.d] then seen[sec.d], n = true, n + 1 end
  end
  return n
end
function recorded_pad()                               -- the pad with a sound of the player's (the last such)
  local best
  for i = 1, 4 do if golpe.pads[i].rec then best = i end end
  return best
end
local function instruments()
  local n = 0
  for i = 1, #seq.tracks do if hits(i) > 0 then n = n + 1 end end
  return n
end

-- Each client: who, what, and the conditions (shown on the card; the first unmet one is what they say is missing).
H.ENC = {
  primer_ritmo = {who = "IAIA", title = "TU PRIMER RITMO", reqs = {
    {"BOMBO: 4 GOLPES", function() return hits(1) >= 4 end, "Un bombo que pise: cuatro golpes, por lo menos."},
    {"PALMAS: 2 GOLPES", function() return hits(3) >= 2 end, "Y unas palmas que contesten. Dos."},
  }},
  kiko = {who = "KIKO", title = "UNA BASE A 90", reqs = {
    {"TEMPO 86 A 94", function() return seq.tempo >= 86 and seq.tempo <= 94 end, "Más lento, tete: a noventa. El mando TEMPO."},
    {"SWING 60%", function() return seq.swing >= 60 end, "Que se balancee. Súbele el SWING, al sesenta por lo menos."},
    {"CAJA EN EL 2 Y EL 4", function() return seq.tracks[2].steps[5] > 0 and seq.tracks[2].steps[13] > 0 end,
     "La caja en el dos y el cuatro: pasos 5 y 13."},
  }},
  xafec = {who = "PONS", title = "UN PASODOBLE NUEVO", reqs = {
    {"CENCERRO: 2 GOLPES", function() return hits(8) >= 2 end, "Sin cencerro no hay fiesta. Dos golpes, por lo menos."},
    {"6 INSTRUMENTOS", function() return instruments() >= 6 end, "Más percusión: seis instrumentos sonando."},
    {"TEMPO 110 O MÁS", function() return seq.tempo >= 110 end, "Más rápido, que es para bailar: 110 o más."},
  }},
  radio = {who = "TONI", title = "LA SINTONÍA", song = true, reqs = {
    {"3 SECCIONES", function() return #song.sections >= 3 end, "Tres partes: principio, medio y final."},
    {"2 RITMOS DISTINTOS", function() return drum_pats_used() >= 2 end, "Dos patrones de ritmo distintos en las secciones."},
  }},
  marta = {who = "MARTA", title = "BAJO DE SÓTANO", reqs = {
    {"TEMPO 120 A 135", function() return seq.tempo >= 120 and seq.tempo <= 135 end, "Más rápido. Entre 120 y 135."},
    {"3 SLIDES", function() return linea_count("slide") >= 3 end, "Que resbale: tres notas con slide, con C."},
    {"CORTE 20% O MENOS", function() return linea.patch.cutoff <= 0.2 end, "Ciérrale el filtro. El CORTE, al veinte."},
  }},
  nerea = {who = "NEREA", title = "PALMAS", reqs = {
    {"PALMAS AL MICRO", function() return H.flags.mic_palmas == true end,
     "Grábalas al micro: en la Ritmo, PALMAS y el botón rojo."},
    {"PALMAS: 6 GOLPES", function() return hits(3) >= 6 end, "Más palmas. Seis, por lo menos."},
    {"SWING 58%", function() return seq.swing >= 58 end, "Y con swing, que esto no es una marcha."},
  }},
  golpe = {who = "MARTA", title = "UN SONIDO TUYO", reqs = {
    {"UN PAD GRABADO", function() return recorded_pad() ~= nil end,
     "En el Golpe 60: REC, y haz un sonido al micro. Tu voz, una palmada, lo que sea."},
    {"2 GOLPES DE ESE PAD", function()
      local i = recorded_pad()
      return i ~= nil and seq.count(golpe.pads[i].steps) >= 2
    end, "Ponlo en el ritmo: dos pasos de ese pad, por lo menos."},
    {"SU TONO CAMBIADO", function()
      local i = recorded_pad()
      return i ~= nil and golpe.pads[i].tune ~= 0
    end, "Súbele o bájale el TONO: así suena a otra cosa."},
  }},
  grillos = {who = "ROBER", title = "LA MEZCLA", setup = function()   -- their mix as it came: drums up, bass buried
    mesa.reset()
    mesa.fader[1], mesa.fader[2], mesa.fader[6] = 10, 10, 4
    mesa.save()
  end, reqs = {
    {"BOMBO Y CAJA A 6 O MENOS", function() return mesa.gain(1) <= 0.75 and mesa.gain(2) <= 0.75 end,
     "La batería se lo come todo. En la Mesa 8, el BOMBO y la CAJA a 6 o menos."},
    {"EL BAJO A 8 O MÁS", function() return mesa.gain(6) >= 1 end, "Y el bajo, que no se oye. Su canal, BAJ, a 8 o más."},
    {"UN CANAL EN MUTE", function()
      for c = 1, mesa.N do if mesa.mute[c] then return true end end
      return false
    end, "Algo sobra. Cállalo: su M, el MUTE."},
  }},
  faro = {who = "FARO", title = "MENOS ES MÁS", reqs = {
    {"4 INSTRUMENTOS", function() return instruments() <= 4 end, "Cuatro instrumentos en la Ritmo. Ni uno más."},
    {"PLACA RITMO 50%", function() return rack.send.ritmo_r >= 0.5 end, "La PLACA en el ritmo, a la mitad."},
    {"ECO BAJO 50%", function() return rack.send.bajo_d >= 0.5 end, "Y el ECO en el bajo, a la mitad."},
  }},
  single = {who = "FARO", title = "TU SINGLE", song = true, reqs = {
    {"4 SECCIONES", function() return #song.sections >= 4 end, "Cuatro secciones. Un single tiene viaje."},
    {"LA CINTA: LÍNEA D", function()
      for _, sec in ipairs(song.sections) do if sec.b == 4 then return true end end
      return false
    end, "Las ocho notas de la cinta: la Línea en D, en alguna sección."},
  }},
  nube = {who = "IAIA", title = "LOS ACORDES", reqs = {
    {"4 ACORDES", function()
      for i = 1, 4 do if nube.slots[i] == 0 then return false end end
      return true
    end, "En la Nube, un acorde en cada compás. Los cuatro."},
    {"EL ÚLTIMO, SOL", function() return nube.slots[4] == nube.SOL end, "Que acabe en SOL. El SOL pide volver al principio."},
    {"2 PASOS POR COMPÁS", function() return seq.count(nube.steps) >= 2 end, "Y que respire: dos pasos encendidos, abajo."},
    {"UNA MELODÍA: 3 NOTAS", function() return seq.count(nube.mel) >= 3 end, "Y ahora cántala tú: GRABAR en la Nube y toca tres notas sobre los acordes."},
  }},
  luna = {who = "LUNA", title = "A OSCURAS", reqs = {
    {"LO-FI GBA", function() return rack.fx.lofi end, "Suena demasiado limpio. El Lo-fi GBA, en el rack."},
    {"TEMPO 100 O MENOS", function() return seq.tempo <= 100 end, "Más lento. A cien o menos."},
    {"ECO RITMO 40%", function() return rack.send.ritmo_d >= 0.4 end, "Eco en el ritmo. Que se pierda."},
  }},
  apagon = {who = "BRILLO", title = "A MANO", auto = true, reqs = {
    {"16 GOLPES EN DIRECTO", function() return (H.flags.directo or 0) >= 16 end,
     "¡A mano! DIRECTO y a darle a los botones."},
  }},
}

H.ch, H.enc, H.flags = nil, nil, {}

function H.save()
  store("historia", {ch = H.ch, enc = H.enc, flags = H.flags, knot = dlg.on and dlg.knot or nil})
end

function H.load()
  local t = stored("historia")
  if type(t) ~= "table" or type(t.ch) ~= "number" then return false end
  H.ch, H.enc, H.flags, H.knot = t.ch, H.ENC[t.enc] and t.enc or nil, type(t.flags) == "table" and t.flags or {}, t.knot
  return true
end

function H.missing()
  local e = H.ENC[H.enc]
  if not e then return nil end
  for _, r in ipairs(e.reqs) do if not r[2]() then return r end end
end

-- The shell's hooks (main.lua): ctx, and how to start the dust, put the station back, go to a station.
local shell
function H.init(c)
  shell = c
  dlg.on_end = function() H.save() end            -- the knot is over: nothing to replay on CONTINUAR
end

local function go_room(room)
  sala.build(room)
  station = "sala"
end

-- C in the room: the work goes to the client
function H.deliver()
  if not H.enc then return end
  local miss = H.missing()
  if miss then
    falta = miss[3]
    dlg.go(H.enc .. "_no")
  else
    local id = H.enc
    H.enc = nil
    H.save()
    if H.ENC[id].song then                           -- the client hears the whole song, from the top
      song.mode = "cancion"
      song.start()
      if not seq.playing then seq.start() end
    end
    dlg.go(id .. "_si")
  end
end

local told = false
function H.update()
  if H.kb then return end
  if dlg.auto and H.enc and not dlg.on and not cine.busy() and state == "juego" then   -- the autopilot delivers
    local id = H.enc
    H.enc = nil
    dlg.go(id .. "_si")
    return
  end
  if not H.enc or ticks() % 30 ~= 0 or dlg.on then return end
  local ok = H.missing() == nil
  if ok and H.ENC[H.enc].auto then H.deliver() return end
  if ok and not told then shell.toast(station == "sala" and "¡LISTO! C: ENTREGAR" or "¡LISTO! MENU Y C: ENTREGAR", 200) end
  told = ok
end

-- The keyboard, for a name: the player's, a song's.
function H.ask(title, default, done)
  H.kb = keyboard.new({title = title, text = default, max = 14,
                       colours = {back = 0x120E16, key = 0x2A2030, lit = 0xE8742A, ink = 0xE9D8B0, lit_ink = 0x120E16}})
  H.kb_done, H.kb_default, H.kb_t = done, default, 0
end

function H.update_kb()
  H.kb_t = (H.kb_t or 0) + 1
  if H.kb_t < 30 and not dlg.auto then return end   -- the A that ended the last line does not type a letter
  local r = dlg.auto and "ok" or H.kb:update()
  if not r then return end
  local name = (r == "ok" and H.kb.text:gsub("^%s+", ""):gsub("%s+$", "") ~= "") and H.kb.text or H.kb_default
  local done = H.kb_done
  H.kb = nil
  done(name)
end

-- The card in the room: who asks, what, and each condition ticked as the machines meet it.
local CARD_T = {font = "hint", color = 0xFFE9B0}
local FACE = {IAIA = true, KIKO = true, MARTA = true, NEREA = true, BRILLO = true, FARO = true, VIDAL = true,
              LUNA = true, TONI = true}
local WHO = {TONI = "RÀDIO CIRERA", PONS = "ORQUESTRA XÀFEC"}
local CARD_L = {font = "lcd", color = 0xE9D8B0}
local CARD_OK = {font = "lcd", color = 0x9FE07A}
local CARD_GO = {font = "hint", color = 0x120E16}
function H.draw_card()
  local e = H.ENC[H.enc]
  if not e then return end
  local n = #e.reqs
  local w = math.max(236, textw(e.title, "hint") + 72)       -- as wide as its words: none leaves the card
  for _, r in ipairs(e.reqs) do w = math.max(w, textw(r[1], "lcd") + 40) end
  local x, y, h = 8, 30, 62 + n * 20
  rect(x, y, w, h, 0x120E16)
  box(x + 1, y + 1, w - 2, h - 2, 0x8A7A60)
  if FACE[e.who] then img("FACE_" .. e.who, x + 6, y + 6)
  else                                               -- someone with no portrait: their initials on a badge
    rect(x + 6, y + 6, 48, 48, 0x5A3A2A)
    box(x + 6, y + 6, 48, 48, 0xE9D8B0)
    text(e.who:sub(1, 2), x + 16, y + 18, CARD_T)
  end
  text(e.title, x + 60, y + 8, CARD_T)
  text(WHO[e.who] or e.who, x + 60, y + 30, CARD_L)
  local all = true
  for i, r in ipairs(e.reqs) do
    local ok = r[2]()
    all = all and ok
    local ry = y + 58 + (i - 1) * 20
    box(x + 10, ry + 5, 10, 10, ok and 0x9FE07A or 0x8A7A60)
    if ok then rect(x + 12, ry + 7, 6, 6, 0x9FE07A) end
    text(r[1], x + 28, ry - 2, ok and CARD_OK or CARD_L)
  end
  if all and not e.auto and ticks() % 40 < 30 then
    rect(x, y + h, w, 22, 0xE9B632)
    text("C: ENTREGAR", x + 10, y + h + 1, CARD_GO)
  end
end

-- ===== the game's moves, called from the story with [do ...]: queued, one after another (cine.lua) =====
local add = cine.add

function escena(name) add(function() cine.show(name) end) end
function pausa(n) cine.wait_for(n) end

function capitulo(n)
  add(function()
    H.ch, H.enc = n, nil
    H.save()
    store("sala_room", H.CAP[n].room)
    go_room(H.CAP[n].room)
    cine.chapter(n, H.CAP[n].title)
    cine.show("sala")
  end)
end

local function home() go_room(stored("sala_room", H.CAP[H.ch].room)) end   -- a scene may have shown another room

function volver() add(function() home(); cine.show("sala") end) end

function encargo(id)
  add(function()
    H.enc = id
    told = false
    if H.ENC[id].setup then H.ENC[id].setup() end
    H.save()
    if not H.ENC[id].auto then home() end
    shell.toast("ENCARGO: " .. H.ENC[id].title, 160)
  end)
end

function polvo()
  add(function()
    station = "ritmo"
    cine.off()
    shell.start_polvo()
    return function() return state ~= "polvo" end
  end)
end

function llamada(kind)
  add(function()
    if kind == "puente" and seq.playing then shell.toggle_play() end
    respuesta.start(kind, function(got)
      if kind == "puente" then H.flags.puente = got; H.save() end
    end)
    return function() return respuesta.on == nil end
  end)
end

function batalla_nave()                              -- (story/es.txt: [do batalla_nave()])
  add(function()
    if seq.playing then shell.toggle_play() end
    batalla.start(function() H.flags.batalla = true; H.save() end)
    return function() return batalla.on == nil end
  end)
end

function radio_cirera(id)
  add(function()
    if seq.playing then shell.toggle_play() end
    radio.start(id)
    return function() return not radio.on end
  end)
end

function accidente_nube()
  nube.queue_accident()
end

function espaiso_escuchas(id, count)
  espaiso.minimum_plays(id, count)
  if espaiso.dirty then espaiso.save() end
end

function espaiso_publicar()
  H.flags.espaiso_subido = true
  H.save()
end

function nombrar(var, default)
  add(function()
    H.ask(var == "tu_single" and "¿CÓMO SE LLAMA TU SINGLE?" or "¿CÓMO SE LLAMA TU TEMA?", default,
          function(name) dlg.vars()[var] = name end)
    return function() return H.kb == nil end
  end)
end

function tararear()
  add(function()
    cine.hum(cine.MOTIF, "triangle", 20)
    return function() return not cine.humming() end
  end)
end

function movil()                                     -- the flip phone rings: your ringtone, the LED in green
  add(function()
    cine.hum({76, 79, 83, 79, 76, 79, 83, 88, 76, 79, 83, 79, 76, 79, 83, 88}, "square", 7)
    cine.shake(100)
    return function()
      if cine.humming() then led(ticks() % 16 < 8 and 0x00FF00 or 0x000000) return false end
      led()
      return true
    end
  end)
end

function zumbido()                                   -- the chat's buzz at three in the morning
  add(function()
    cine.shake(40)
    tone(1, 110, {wave = "square", vol = 0.3, sustain = 1, len = 0.6})
  end)
  cine.wait_for(50)
end

function taza()                                      -- the cup falls, slowly: the picture breaks into blocks
  add(function()
    local t = 0
    return function()
      t = t + 1
      if t < 72 then mosaic(1 + t // 12, 1 + t // 12) return false end
      mosaic(1, 1)
      tone(1, 1400, {wave = "noise", vol = 0.4, decay = 0.25})
      cine.shake(14)
      return true
    end
  end)
end

function cinta_corta()                               -- the tape runs out in the middle of the bridge
  add(function()
    tone(2)
    tone(1, 220, {wave = "square", vol = 0.3, decay = 0.06})
    cine.flash(5)
  end)
  cine.wait_for(40)
end

-- The eight notes into Línea 3's pattern D: the single starts there.
function cinta_en_linea()
  local deg, acc, sl = {}, {}, {}
  for st = 1, 16 do deg[st], acc[st], sl[st] = 0, false, false end
  for k, d in ipairs({8, 10, 12, 11, 10, 9, 8, 5}) do deg[k * 2 - 1] = d end
  acc[1], sl[7] = true, true
  linea.pats[4] = {deg = deg, acc = acc, slide = sl}
  if linea.pat == 4 then linea.select(4) end
  linea.save()
end

function apagon()
  add(function()
    if seq.playing then shell.toggle_play() end    -- the power goes: the music stops with it
    tone(1, 400, {wave = "saw", vol = 0.3, sustain = 1, len = 0.5, slide = -700})  -- a tape winding down
    H.apagon, H.flags.directo = true, 0
    station = "ritmo"
    cine.off()
    shell.set_mode("directo")
    led(0xFF8000)
  end)
end

function luz()                                       -- the lights come back row by row, top to bottom
  add(function()
    H.apagon = false
    led()
    local t = 0
    return function()
      t = t + 1
      window(0, 0, 0, 240, 160, ALL)
      for y = 0, 159 do line_window(0, y, 0, y < t * 4 and 240 or 0) end
      window_out(OBJ)
      if t < 42 then return false end
      shell.set_mode("pasos")
      home()
      cine.show("sala")
      return true
    end
  end)
end

function escucha()                                   -- the iaia listens to the whole song, eyes closed
  add(function()
    song.mode = "cancion"
    song.start()
    if not seq.playing then seq.start() end
    cine.show("noche_desvan")
  end)
  cine.wait_for(480)
end

function parar() add(function() if seq.playing then shell.toggle_play() end end) end

function contestador()
  add(function()
    local t = 0
    return function()
      t = t + 1
      led(t % 30 < 15 and 0xFF0000 or 0x000000)
      if t < 120 then return false end
      led()
      return true
    end
  end)
end

function concierto()
  add(function()
    shell.start_concierto()
    return function() return not shell.concierto_on() end
  end)
end

function creditos()
  add(function()
    shell.start_creditos()
    return function() return not shell.creditos_on() end
  end)
end

function libre()
  add(function()
    H.ch, H.enc = 6, nil
    store("libre", true)
    H.save()
    go_room(H.CAP[6].room)
  end)
end

-- ===== starting =====

local KEYS = {"polvo", "patron", "bajo", "rack", "cancion", "historia", "story", "vio_linea", "vio_rack",
              "vio_pantalla", "sala_room", "guia_ritmo", "guia_pantalla", "guia_linea", "guia_rack", "guia_golpe",
              "golpe", "mesa", "guia_mesa", "nube", "guia_nube", "nogal", "guia_nogal", "espaiso"}
function H.wipe(all)                                 -- all: the free mode locked again too (a console as new)
  for _, k in ipairs(KEYS) do store(k, nil) end
  if all then store("libre", nil); store("volumen", nil) end
end

function H.nueva()
  H.wipe()
  seq.load(); linea.load(); rack.load(); song.load(); golpe.load(); mesa.load(); nube.load(); nogal.load(); espaiso.load()
  H.ch, H.enc, H.flags = 0, nil, {}
  dlg.init()
  sala.build("desvan")
  H.ask("¿CÓMO TE LLAMAS?", "ÀLEX", function(name)
    dlg.vars().nombre = name
    state = "juego"
    dlg.go("prologo")
  end)
end

local function enter_room(room)
  state = "juego"
  go_room(room)
  restore_station()
end

function H.continuar()
  if not H.load() then H.nueva() return end
  enter_room(stored("sala_room", H.CAP[H.ch].room))
  if H.knot and dlg.s.knots[H.knot] then dlg.go(H.knot) end
end

function H.modo_libre()
  H.load()
  H.ch, H.enc = 6, nil
  enter_room(H.CAP[6].room)
end

return H
