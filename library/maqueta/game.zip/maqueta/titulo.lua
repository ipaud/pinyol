-- The title: Cirera de Mar at sunset, MAQUETA over it, the eight notes of the tape hummed again and again.
-- CONTINUAR, NUEVA PARTIDA (asks first if there is one), MODO LIBRE (once the story is over), the volume.
local cine = require("cine")
local hands = require("hands")
local T = {}

local VOLS = {0.2, 0.4, 0.6, 0.8, 1}

local function items()
  local list = {}
  if stored("historia") then list[#list + 1] = "CONTINUAR" end
  list[#list + 1] = "NUEVA PARTIDA"
  if stored("libre") then list[#list + 1] = "MODO LIBRE" end
  list[#list + 1] = "VOLUMEN"
  return list
end

function T.enter()
  state = "titulo"
  cine.flush()
  canvas("CINE", "CINE_CIRERA")
  bg(2, {image = "CINE", prio = 2, mosaic = true, x = 0, y = 0})
  backdrop(0x000000)
  hands.hidden = true
  T.items, T.sel, T.ask, T.t = items(), 1, false, 0
end

local function leave(fn)
  tone(3)
  hands.hidden = false
  fn()
end

function T.update()
  T.t = T.t + 1
  mosaic(1 + math.max(0, 12 - T.t) // 2, 1 + math.max(0, 12 - T.t) // 2)
  if T.t % 240 == 30 then cine.hum(cine.MOTIF, "triangle", 22) end
  local n = #T.items
  if btnp("up") then T.sel = (T.sel - 2) % n + 1; T.ask = false; foley("press") end
  if btnp("down") then T.sel = T.sel % n + 1; T.ask = false; foley("press") end
  if btnp("b") then T.ask = false end
  if not (btnp("a") or btnp("start")) then return end
  foley("press")
  local it = T.items[T.sel]
  if it == "CONTINUAR" then leave(historia.continuar)
  elseif it == "NUEVA PARTIDA" then
    if stored("historia") and not T.ask then T.ask = true return end
    leave(historia.nueva)
  elseif it == "MODO LIBRE" then leave(historia.modo_libre)
  elseif it == "VOLUMEN" then
    local i = 1
    for k, v in ipairs(VOLS) do if math.abs(v - game_volume) < 0.01 then i = k end end
    set_volume(VOLS[i % #VOLS + 1])
    store("volumen", game_volume)
  end
end

local LOGO = {font = "brand", scale = 4, align = "center", color = 0xFFE9B0, gradient = 0xE8742A, outline = 0x2A1008,
              shadow = 0x000000, wave = 1}
local SUB = {font = "lcd", align = "center", color = 0xF2EBDD, shadow = 0x000000}
local ITEM = {font = "hint", align = "center", color = 0xC9B8A0, shadow = 0x000000}
local PICK = {font = "hint", align = "center", color = 0xFFE070, shadow = 0x000000}

function T.draw()
  text("MAQUETA", 240, 34, LOGO)
  text("CIRERA DE MAR · VERANO DE 2004", 240, 86, SUB)
  local y0 = 320 - #T.items * 26 - 14
  rect(120, y0 - 8, 240, #T.items * 26 + 12, 0x120E16)
  box(121, y0 - 7, 238, #T.items * 26 + 10, 0x8A7A60)
  for i, it in ipairs(T.items) do
    local label = it
    if it == "VOLUMEN" then label = "VOLUMEN " .. math.floor(game_volume * 100 + 0.5) .. "%" end
    if it == "NUEVA PARTIDA" and T.ask and T.sel == i then label = "¿BORRAR? A: SÍ  B: NO" end
    local on = i == T.sel
    if on then text(">", 136, y0 + (i - 1) * 26, PICK) end
    text(label, 240, y0 + (i - 1) * 26, on and PICK or ITEM)
  end
end

return T
