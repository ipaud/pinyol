-- Línea 3, the acid bass, drawn by code on its own 240x160 canvas: a silver box with black knobs as a TB-303's,
-- a strip that shows each step's note (how high, accented, sliding into the next) over 16 silver keys.
-- Same rules as panel.lua: icons, no small words, and only what changed is drawn again.
local P = {}

local C = {
  body = 0xB9BAB6, body_hi = 0xDCDDD8, body_lo = 0x6E6F6B, band = 0x8E8F8B, ink = 0x1a1a1c,
  knob = 0x1d1d1f, mark = 0xEDEDE8, icon = 0x3a3a3e, rule = 0x9A9B97, roll = 0x1b1f1c, roll_line = 0x2c332e,
  note = 0x9FE07A, note_hi = 0xD8FFB8, acc = 0xFF5A3A, slide = 0x6FB0FF, head = 0xFFF4E0,
  key = 0xD5D6D1, key_hi = 0xF4F4F0, key_lo = 0x8C8D89, led_off = 0x3a1010, led_on = 0xFF3A1E,
  lcd = 0x8FAE3E, lcd_ink = 0x1F3A10, lcd_edge = 0x34401a, yellow = 0xE9B632, cream = 0xF2EBDD, shadow = 0x0a080c,
}
P.C = C
P.PANEL = {x = 6, y = 14, w = 228, h = 124}
P.ROLL_Y, P.ROLL_H, P.KEY_Y = 67, 30, 103
local KNOB_Y = 52
local LCD = {x = 93, y = 17, w = 110, h = 12}
P.LCD = LCD                                          -- (tests/textos.script: every LCD text fits)

local ICON = {
  tono = {"..#...##.", ".###..#.#", "#.#.#.#..", "..#...#..", "..#.###..", "..#.###..", "........."},
  corte = {"#####....", ".....#...", "......#..", ".......#.", "........#", ".........", "........."},
  reso = {"....#....", "....#....", "...#.#...", "####.####", ".........", ".........", "........."},
  env = {"..#......", ".#.#.....", "#...#....", "#....##..", "#......##", "#########", "........."},
  caida = {"#........", "##.......", "#.#......", "#..#.....", "#...##...", "#.....###", "#########"},
  acento = {"##.......", "..##.....", "....##...", "......##.", "....##...", "..##.....", "##......."},
  saw = {"...#...#", "..##..##", ".#.#.#.#", "#..##..#"},
  square = {"###..###", "#.#..#.#", "#.#..#.#", "#.####.#"},
}

local function icon(rows, x, y, colour)
  for r, row in ipairs(rows) do
    for k = 1, #row do
      if row:sub(k, k) == "#" then pset(x + k - 1, y + r - 1, colour) end
    end
  end
end

P.SPOTS, P.ROWS = {}, {{}, {}}
local function spot(id, row, kind, x, y, w, h, tip, extra)
  local s = {id = id, row = row, kind = kind, x = x, y = y, w = w, h = h, tip = tip}
  for k, v in pairs(extra or {}) do s[k] = v end
  P.SPOTS[id] = s
  table.insert(P.ROWS[row], id)
end
local function knob(id, cx)
  spot(id, 1, "knob", cx - 9, KNOB_Y - 18, 19, 28, {cx, KNOB_Y - 3}, {cx = cx, cy = KNOB_Y, r = 8})
end
knob("ltono", 22)
knob("corte", 48)
knob("reso", 74)
knob("env", 100)
knob("lcaida", 126)
knob("acento", 152)
spot("onda", 1, "switch", 170, 47, 17, 10, {178, 51})
spot("lplay", 1, "button", 192, 36, 20, 24, {202, 46})
spot("lmodo", 1, "switch", 214, 53, 19, 8, {223, 56})
spot("lpat", 1, "button", 206, 16, 24, 13, {218, 22})
for s = 0, 15 do
  local x = 9 + s * 14
  spot("lstep" .. s, 2, "step", x, P.ROLL_Y, 12, P.KEY_Y + 20 - P.ROLL_Y, {x + 6, P.KEY_Y + 7}, {step = s})
end
P.ICON_OF = {ltono = "tono", corte = "corte", reso = "reso", env = "env", lcaida = "caida", acento = "acento"}

function P.at(x, y)
  for id, s in pairs(P.SPOTS) do
    if x >= s.x - 1 and x < s.x + s.w + 1 and y >= s.y - 1 and y < s.y + s.h + 1 then return id end
  end
end

function P.move(id, dx, dy)
  local s = P.SPOTS[id]
  if dx ~= 0 then
    local row = P.ROWS[s.row]
    for i, other in ipairs(row) do
      if other == id then return row[(i - 1 + dx) % #row + 1] end
    end
  end
  local r = (s.row - 1 + dy) % 2 + 1
  local best, bd = id, 1e9
  for _, other in ipairs(P.ROWS[r]) do
    local d = math.abs(P.SPOTS[other].tip[1] - s.tip[1])
    if d < bd then best, bd = other, d end
  end
  return best
end

local function body()
  local p = P.PANEL
  rect(p.x + 1, p.y, p.w - 2, p.h, C.body)
  rect(p.x, p.y + 1, p.w, p.h - 2, C.body)
  line(p.x + 1, p.y, p.x + p.w - 2, p.y, C.body_hi)
  line(p.x, p.y + 1, p.x, p.y + p.h - 2, C.body_hi)
  line(p.x + p.w - 1, p.y + 1, p.x + p.w - 1, p.y + p.h - 2, C.body_lo)
  line(p.x + 1, p.y + p.h - 1, p.x + p.w - 2, p.y + p.h - 1, C.body_lo)
  for y = p.y + 3, p.y + p.h - 3, 3 do line(p.x + 2, y, p.x + p.w - 3, y, 0xB2B3AF) end -- brushed aluminium
  rect(p.x + 3, p.y + 2, p.w - 6, 14, C.band)
  text("LINEA 3", 13, 19, {font = "brand", color = C.ink})   -- Press Start has no capital Í: its accent by hand
  line(25, 17, 27, 15, C.ink)
  line(p.x + 4, p.y + 17, p.x + p.w - 5, p.y + 17, C.ink)
  rect(LCD.x - 1, LCD.y - 1, LCD.w + 2, LCD.h + 2, C.lcd_edge)
  for _, id in ipairs(P.ROWS[1]) do
    local s = P.SPOTS[id]
    if s.kind == "knob" then
      for k = 0, 10 do
        local a = math.rad(-135 + 27 * k)
        pset(math.floor(s.cx + math.sin(a) * (s.r + 2) + 0.5), math.floor(s.cy - math.cos(a) * (s.r + 2) + 0.5), C.body_lo)
      end
      icon(ICON[P.ICON_OF[id]], s.cx - 4, 35, C.icon)
    end
  end
  icon(ICON.saw, 168, 39, C.icon)
  icon(ICON.square, 180, 39, C.icon)
  rect(7, P.ROLL_Y - 2, 226, P.ROLL_H + 4, C.body_lo)
end

local last = {}

function P.build()
  last = {}
  canvas("PANEL_L", "DESK")
  target("PANEL_L")
  body()
  target()
end

local function changed(key, sig)
  if last[key] == sig then return false end
  last[key] = sig
  return true
end

local function draw_knob(s, v)
  circ(s.cx, s.cy, s.r + 1, C.body)
  circ(s.cx + 1, s.cy + 1, s.r, C.body_lo)
  circ(s.cx, s.cy, s.r, C.knob)
  circ(s.cx, s.cy, s.r - 3, 0x2a2a2d)
  pset(s.cx - s.r // 2, s.cy - s.r // 2, 0x6a6a70)
  local a = math.rad(-135 + 270 * math.max(0, math.min(1, v)))
  line(s.cx, s.cy, math.floor(s.cx + math.sin(a) * (s.r - 1) + 0.5), math.floor(s.cy - math.cos(a) * (s.r - 1) + 0.5), C.mark)
end

-- The notes as a strip over the keys: each step's height, a red top for an accent, a blue line for a slide.
local DEG_H = 2
local function draw_roll(v)
  local y0, h = P.ROLL_Y, P.ROLL_H
  rect(8, y0 - 1, 224, h + 2, C.roll)
  for d = 1, 15, 7 do line(9, y0 + h - 1 - (d - 1) * DEG_H, 230, y0 + h - 1 - (d - 1) * DEG_H, C.roll_line) end
  for s = 0, 15 do
    local x = 9 + s * 14
    if v.playing and v.step == s then rect(x, y0, 12, h, 0x26302a) end
    local d = v.deg[s + 1]
    if d > 0 then
      local y = y0 + h - 2 - (d - 1) * DEG_H
      rect(x + 1, y, 10, 2, (v.playing and v.step == s) and C.note_hi or C.note)
      if v.acc[s + 1] then rect(x + 1, y - 1, 10, 1, C.acc) end
      local nd = v.deg[(s + 1) % 16 + 1]
      if v.slide[s + 1] and nd > 0 and s < 15 then
        line(x + 11, y, x + 15, y0 + h - 2 - (nd - 1) * DEG_H, C.slide)
      end
    end
  end
end

local function draw_key(s, on, head, pressed)
  local x, y = 9 + s * 14, P.KEY_Y
  rect(x - 1, y - 4, 14, 26, C.body)
  rect(x + 4, y - 3, 4, 2, head and C.head or (on and C.led_on or C.led_off))
  local dy = pressed and 1 or 0
  rect(x, y + dy, 12, 20 - dy, C.key)
  line(x, y + dy, x + 11, y + dy, C.key_hi)
  line(x, y + dy, x, y + 19, C.key_hi)
  if not pressed then rect(x + 1, y + 18, 11, 2, C.key_lo) end
  line(x + 1, y + 20, x + 12, y + 20, C.body_lo)
end

local function draw_play(on)
  local play = P.SPOTS.lplay
  rect(play.x, play.y, play.w, play.h, C.body)
  rect(play.x, play.y, play.w, play.h - 2, on and 0xFFD84A or C.yellow)
  line(play.x, play.y, play.x + play.w - 1, play.y, 0xFFE9A0)
  rect(play.x, play.y + play.h - 2, play.w, 2, 0x8A6A14)
  if on then rect(play.x + 7, play.y + 7, 6, 6, C.ink)
  else tri(play.x + 7, play.y + 6, play.x + 7, play.y + 14, play.x + 13, play.y + 10, C.ink) end
end

local function draw_switch(id, right)
  local sw = P.SPOTS[id]
  local h = id == "onda" and 6 or sw.h
  local y = id == "onda" and sw.y + 4 or sw.y
  rect(sw.x, y, sw.w, h, C.ink)
  rect(sw.x + (right and sw.w - 9 or 1), y + 1, 8, h - 2, C.cream)
end

local function draw_lcd(str)
  rect(LCD.x, LCD.y, LCD.w, LCD.h, C.lcd)
  text(str, LCD.x + 3, LCD.y - 4, {font = "lcd", color = C.lcd_ink})
end

local PAT_COL = {0xE0452C, 0xE8742A, 0xE9B632, 0xE9E1CF}  -- A B C D
local function draw_pat(s, p)                                -- the pattern in hand: its letter in its colour
  rect(s.x, s.y, s.w, s.h, 0x121014)
  rect(s.x + 1, s.y + 1, s.w - 2, s.h - 2, p > 0 and PAT_COL[p] or 0x3a3640)
  text(p > 0 and ({"A", "B", "C", "D"})[p] or "-", s.x + 8, s.y + 2, {font = "badge", color = 0x1a1418})
end

local KEY_ID = {}
for k = 0, 15 do KEY_ID[k] = "k" .. k end

-- v = {knobs = {id = 0..1}, deg = {...}, acc = {...}, slide = {...}, playing, step, pressed, wave, mode, lcd}
function P.draw(v)
  target("PANEL_L")
  for id, val in pairs(v.knobs) do
    if changed(id, val) then draw_knob(P.SPOTS[id], val) end
  end
  local sig = (v.playing and v.step or -1) * 1e6 + v.roll_sig
  if changed("roll", sig) then draw_roll(v) end
  for s = 0, 15 do
    local on = v.deg[s + 1] > 0
    local head = v.playing and v.step == s
    local press = v.pressed[s] ~= nil
    if changed(KEY_ID[s], (on and 4 or 0) + (head and 2 or 0) + (press and 1 or 0)) then draw_key(s, on, head, press) end
  end
  if changed("play", v.playing) then draw_play(v.playing) end
  if changed("onda", v.wave) then draw_switch("onda", v.wave == "square") end
  if changed("modo", v.mode) then draw_switch("lmodo", v.mode ~= "pasos") end
  if changed("lcd", v.lcd) then draw_lcd(v.lcd) end
  if changed("pat", v.pat) then draw_pat(P.SPOTS.lpat, v.pat) end
  target()
end

return P
