-- The conversations: pinyol's story library runs story/es.txt (who says what, the choices, the [do] that move the
-- game); this draws its box the game's way: a portrait twice its size standing on the box, Fire Emblem style, the
-- name on a tab in the speaker's colour, the words big enough to read on the console. START skips to the next
-- choice. While a [do] has the screen (a mini-game, a shot without words) the box waits, hidden.
local story = require("story")
local rich = require("rich")
local cine = require("cine")
local D = {}

local BOX = {x = 8, y = 222, w = 464, h = 92}
local FONT = "lcd"
local FACES = {Iaia = "FACE_IAIA", Kiko = "FACE_KIKO", Marta = "FACE_MARTA", Nerea = "FACE_NEREA", Brillo = "FACE_BRILLO",
               Faro = "FACE_FARO", Vidal = "FACE_VIDAL", Luna = "FACE_LUNA", Toni = "FACE_TONI", Remei = "FACE_REMEI83"}
local TAB = {Iaia = 0xB88AD0, Kiko = 0xE8742A, Marta = 0x7FC06A, Nerea = 0xE0452C, Brillo = 0xE9B632,
             Faro = 0x6AA8D8, Vidal = 0x9A9AB0, Luna = 0xF08AB8, Toni = 0xC9A46A, Remei = 0xB88AD0,
             ["Vidal joven"] = 0x9A9AB0, Pons = 0xD08A3A, Rober = 0x5AC8C0}
local NAME = {Toni = "Toni Ona", Faro = "Sr. Faro", Remei = "Remei, 1983", ["Vidal joven"] = "Vidal, 1983",
              Pons = "Sr. Pons", Rober = "Rober, Los Grillos"}

D.on = false
local s

function D.init()
  s = story.new(file("story/es.txt"), {name = "es.txt", vars = stored("story"),
    ui = {font = FONT, x = BOX.x, y = BOX.y, w = BOX.w, h = BOX.h, pad = 12, speed = 0.8, blip = "F_BLIP",
          blip_every = 3}})
  function s:_text_x() return BOX.x + 14, BOX.w - 28 end   -- the portrait stands above the box: all of it is words
  function s:_typeset()                                     -- said in cream, narrated in blue-grey
    self.rt = rich.new(self.line_.text, {font = FONT, color = self.line_.who and 0xF2EBDD or 0xB8C8D8,
                                         width = BOX.w - 28, speed = 0.8, blip = "F_BLIP", blip_every = 3})
    self.shown, self.total = 0, self.rt.total
  end
  D.s = s
end

function D.vars() return s.vars end
function D.save() store("story", s.vars) end

function D.go(knot)
  D.knot, D.on = knot, true
  require("hands").rest_all()                      -- the hands rest on the desk while people talk
  s:go(knot)
end

function D.blocked() return cine.busy() end      -- a [do] has the screen: a shot, a mini-game, a name

D.cool = 0
function D.finish()
  D.on, D.cool = false, 15                         -- the A that closed the box does not also press a machine
  D.save()
  cine.off()
  if D.on_end then D.on_end(D.knot) end
end

function D.update()
  if not D.on or D.blocked() then return end
  if not s:running() then D.finish() return end
  if D.auto or D.reader then                       -- the tests' autopilot (reader: only the words, the rest by hand)
    D.auto_t = (D.auto_t or 0) + 1
    if D.auto_t < (D.auto_every or 1) then s:update() return end
    D.auto_t = 0
    if s:line() then s:next() elseif s.choices_ then s:choose(1) end
    return
  end
  if btnp("start") then                            -- skip: on to the next choice, or the end
    while s:running() and s:line() and not D.blocked() do s:next() end
  end
  -- the story may end on a [do] still queued (an encargo, a room): the box closes once the queue has run it
  if s:update() == "done" and not D.blocked() then D.finish() end
end

local TAB_STYLE = {font = "hint", color = 0x120E16}
local CHOICE = {font = FONT, color = 0xA8B4C4}
local PICK = {font = FONT, color = 0xFFE9B0}

local function frame_box()
  local b = BOX
  rect(b.x + 2, b.y, b.w - 4, b.h, 0x120E16)
  rect(b.x, b.y + 2, b.w, b.h - 4, 0x120E16)
  box(b.x + 3, b.y + 3, b.w - 6, b.h - 6, 0x5A4A3A)
  line(b.x + 2, b.y, b.x + b.w - 3, b.y, 0xE9D8B0)
  line(b.x + 2, b.y + b.h - 1, b.x + b.w - 3, b.y + b.h - 1, 0x8A7A60)
  line(b.x, b.y + 2, b.x, b.y + b.h - 3, 0xE9D8B0)
  line(b.x + b.w - 1, b.y + 2, b.x + b.w - 1, b.y + b.h - 3, 0x8A7A60)
end

function D.draw()
  if not D.on or D.blocked() then return end
  local l = s:line()
  if l and l.who then
    local face = FACES[l.who]
    local tx = BOX.x + 10
    if face then                                   -- the portrait, twice its size, standing on the box
      rect(BOX.x + 6, BOX.y - 100, 100, 100, 0x120E16)
      img(face, BOX.x + 8, BOX.y - 98, {scale = 2})
      box(BOX.x + 6, BOX.y - 100, 100, 100, 0xE9D8B0)
      tx = BOX.x + 112
    end
    local name = NAME[l.who] or l.who
    local w = textw(name, "hint") + 16
    rect(tx, BOX.y - 20, w, 22, TAB[l.who] or 0xE9D8B0)
    text(name, tx + 8, BOX.y - 19, TAB_STYLE)
  end
  frame_box()
  if l then
    s.rt.shown = s.shown
    s.rt:draw(BOX.x + 14, BOX.y + 10)
    if s.shown >= s.total and ticks() % 40 < 26 then
      tri(BOX.x + BOX.w - 22, BOX.y + BOX.h - 16, BOX.x + BOX.w - 10, BOX.y + BOX.h - 16, BOX.x + BOX.w - 16,
          BOX.y + BOX.h - 9, 0xFFE9B0)
    end
  elseif s.choices_ then                           -- the rows story.lua taps on: top = y + pad, lh + 4 apart
    local _, lh = textw("Ag", FONT)
    for i, c in ipairs(s.choices_) do
      local y = BOX.y + 12 + (i - 1) * (lh + 4)
      local on = i == s.sel
      if on then tri(BOX.x + 14, y + 4, BOX.x + 14, y + lh - 4, BOX.x + 21, y + lh // 2, 0xFFE9B0) end
      text(c.text, BOX.x + 28, y, on and PICK or CHOICE)
    end
  end
end

return D
