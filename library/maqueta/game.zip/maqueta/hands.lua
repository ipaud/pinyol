-- The player's two hands: one goes to the control in use, the other rests on the desk keeping time.
-- One sheet (the right hand, five poses); the left is the same frames mirrored. They are sprites, drawn by the PPU.
-- They move like hands: on a spring that lifts them off the desk on the way and lets them settle, a press that
-- rises before it goes down, the free hand tapping the beat on the desk or breathing when the music is off, both
-- up for a moment when the work is done.
local D = require("hands_data")
local H = {}

local POSE = {rest = 0, point = 1, press = 2, pinch = 3, twist = 4}
local REST = {left = {46, 134}, right = {194, 134}}
local PULL, DAMP = 0.2, 0.56            -- the spring: how hard the target pulls, how much speed is kept a tick
local LIFT = 0.12                       -- lifted off the desk while travelling: this much of the distance left
local PRESS = 10                        -- a press's ticks: 2 up (anticipation), 5 down, 3 back

H.side = {}
for name, p in pairs(REST) do
  H.side[name] = {x = p[1], y = p[2], vx = 0, vy = 0, tx = p[1], ty = p[2], pose = "rest", press = 0,
                  press_pose = "press", twist = false, bob = 0, drum = 0, cheer = 0}
end

-- Send a hand to a point (where its pose touches lands there); the other goes back to rest.
function H.point(x, y, pose)
  local name = x < 112 and "left" or "right"
  for n, h in pairs(H.side) do
    if n == name then
      h.tx, h.ty, h.pose = x, y, pose
    else
      h.tx, h.ty, h.pose = REST[n][1], REST[n][2], "rest"
    end
  end
  H.active = name
end

function H.rest_all()
  for n, h in pairs(H.side) do h.tx, h.ty, h.pose = REST[n][1], REST[n][2], "rest" end
end

H.foley = function() end                 -- the sound of a finger on the control (main.lua's)

-- A press: the hand that holds the control (or the one named).
function H.press(name, pose)
  local h = H.side[name or H.active or "right"]
  if h then h.press, h.press_pose = PRESS, pose or "press" end
  H.foley("press")
end

function H.twist()
  local h = H.side[H.active or "right"]
  if h then h.twist = not h.twist end
  H.foley("twist")
end

-- On the beat: the hands that are free tap the desk.
function H.bob()
  for n, h in pairs(H.side) do
    if n ~= H.active or h.pose == "rest" then h.bob, h.drum = 2, 6 end
  end
end

-- The work is done: the free hand (or both) up for a moment.
function H.cheer(both)
  for n, h in pairs(H.side) do
    if both or n ~= H.active or h.pose == "rest" then h.cheer = 50 end
  end
end

function H.update()
  for _, h in pairs(H.side) do
    h.vx = h.vx * DAMP + (h.tx - h.x) * PULL
    h.vy = h.vy * DAMP + (h.ty - h.y) * PULL
    h.x, h.y = h.x + h.vx, h.y + h.vy
    if h.press > 0 then h.press = h.press - 1 end
    if h.bob > 0 then h.bob = h.bob - 0.25 end
    if h.drum > 0 then h.drum = h.drum - 1 end
    if h.cheer > 0 then h.cheer = h.cheer - 1 end
  end
end

local function frame(h)
  if h.pose == "pinch" then return h.twist and POSE.twist or POSE.pinch end
  if h.press > 0 and h.press <= PRESS - 2 then return POSE[h.press_pose] or POSE.press end
  return POSE[h.pose] or POSE.rest
end

-- How far up or down the hand is drawn from where it is: lifted travelling, a press's rise and fall, the beat,
-- breathing at rest, a cheer.
local function offset(h)
  local dy = -math.min(10, (math.abs(h.tx - h.x) + math.abs(h.ty - h.y)) * LIFT)
  if h.press > PRESS - 2 then dy = dy - 2                  -- up before it goes down
  elseif h.press > 3 then dy = dy + 2 end
  dy = dy + math.floor(h.bob) + (h.drum > 3 and 2 or 0)    -- the beat: a tap on the desk
  if h.pose == "rest" and h.drum == 0 and h.cheer == 0 then dy = dy + math.floor(math.sin(ticks() / 24 + h.tx) + 0.5) end
  if h.cheer > 0 then dy = dy - math.min(14, (50 - h.cheer) * 3) end
  return dy
end

local SPRITE = {right = 0, left = 1}   -- PPU sprites, over the panel: the hardware draws them twice as big for free
local sheet_id

function H.draw()
  if not sheet_id then sheet_id = sheet("HANDSPR"); palette("HANDSPR", true) end   -- indexed: the PPU's fast path
  if H.hidden then spr_off(SPRITE.right); spr_off(SPRITE.left) return end   -- a cutscene: no hands
  for name, h in pairs(H.side) do
    local f = frame(h)
    local tip = D.tips[f + 1]
    local tx = name == "left" and (D.w - 1 - tip[1]) or tip[1]
    local x = math.floor(h.x + 0.5) - tx
    local y = math.floor(h.y + 0.5) - tip[2] + math.floor(offset(h) + 0.5)
    spr(SPRITE[name], sheet_id, f, x, y, prio(0) | (name == "left" and FLIP_X or 0))
  end
end

return H
