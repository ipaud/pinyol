-- Mesa 8, the mixing desk (an SSL or a Neve brought down to eight channels), drawn by code on its own 240x160
-- canvas: per channel its name, MUTE and SOLO, a column of LEDs that jumps with what sounds, and a long fader.
-- Same rules as panel.lua: icons and short names, only what changed is drawn again.
local P = {}

local C = {
  body = 0x5A5E66, body_hi = 0x7C808A, body_lo = 0x2E3036, band = 0x3E4148, ink = 0x111214, cream = 0xF2EBDD,
  strip = 0x4A4E56, slot = 0x16171A, cap = 0xD8D4CA, cap_hi = 0xFFFFFF, cap_lo = 0x8A8780, cap_line = 0x222222,
  mute = 0xE8A23A, mute_off = 0x5A4A30, solo = 0x7FD05A, solo_off = 0x34502A, led_g = 0x6FE04A, led_y = 0xF0C030,
  led_r = 0xFF4A30, led_off = 0x24272C, lcd = 0x8FAE3E, lcd_ink = 0x1F3A10, lcd_edge = 0x34401a, sel = 0xE9B632,
}
P.C = C
P.PANEL = {x = 6, y = 14, w = 228, h = 124}
local LCD = {x = 100, y = 17, w = 126, h = 12}
P.LCD = LCD                                          -- (tests/textos.script: every LCD text fits)
P.N = 8
P.NAMES = {"BOM", "CAJ", "PAL", "CHA", "PER", "BAJ", "GOL", "TEC"}
local X0, W = 10, 27
P.FADER_Y, P.FADER_H = 70, 60                        -- the fader's travel: its top is 10, its bottom 0

P.SPOTS, P.ROWS = {}, {{}, {}, {}}
local function spot(id, row, kind, x, y, w, h, tip, extra)
  local s = {id = id, row = row, kind = kind, x = x, y = y, w = w, h = h, tip = tip}
  for k, v in pairs(extra or {}) do s[k] = v end
  P.SPOTS[id] = s
  table.insert(P.ROWS[row], id)
end
for c = 1, P.N do
  local x = X0 + (c - 1) * W
  spot("m" .. c, 1, "mute", x + 3, 44, 20, 10, {x + 13, 49}, {ch = c})
  spot("s" .. c, 2, "solo", x + 3, 57, 20, 10, {x + 13, 62}, {ch = c})
  spot("f" .. c, 3, "fader", x + 9, P.FADER_Y - 4, 16, P.FADER_H + 8, {x + 17, P.FADER_Y + 20}, {ch = c})
end

function P.x_of(c) return X0 + (c - 1) * W end
function P.cap_y(v) return P.FADER_Y + math.floor((1 - v / 10) * P.FADER_H + 0.5) end
function P.value_at(y) return math.max(0, math.min(10, math.floor((1 - (y - P.FADER_Y) / P.FADER_H) * 10 + 0.5))) end

function P.at(x, y)
  for id, s in pairs(P.SPOTS) do
    if x >= s.x - 1 and x < s.x + s.w + 1 and y >= s.y - 1 and y < s.y + s.h + 1 then return id end
  end
end

function P.move(id, dx, dy)
  local s = P.SPOTS[id]
  if dx ~= 0 then
    local row = P.ROWS[s.row]
    for i, other in ipairs(row) do
      if other == id then return row[(i - 1 + dx) % #row + 1] end
    end
  end
  local r = (s.row - 1 + dy) % 3 + 1
  local best, bd = id, 1e9
  for _, other in ipairs(P.ROWS[r]) do
    local d = math.abs(P.SPOTS[other].tip[1] - s.tip[1])
    if d < bd then best, bd = other, d end
  end
  return best
end

local NAME = {font = "badge", color = C.cream}
local function body()
  local p = P.PANEL
  rect(p.x + 1, p.y, p.w - 2, p.h, C.body)
  rect(p.x, p.y + 1, p.w, p.h - 2, C.body)
  line(p.x + 1, p.y, p.x + p.w - 2, p.y, C.body_hi)
  line(p.x + p.w - 1, p.y + 1, p.x + p.w - 1, p.y + p.h - 2, C.body_lo)
  line(p.x + 1, p.y + p.h - 1, p.x + p.w - 2, p.y + p.h - 1, C.body_lo)
  rect(p.x + 3, p.y + 2, p.w - 6, 14, C.band)
  text("MESA 8", 13, 19, {font = "brand", color = C.cream})
  rect(LCD.x - 1, LCD.y - 1, LCD.w + 2, LCD.h + 2, C.lcd_edge)
  for c = 1, P.N do
    local x = X0 + (c - 1) * W
    rect(x, 33, W - 2, 103, C.strip)
    line(x, 33, x, 135, C.body_hi)
    text(P.NAMES[c], x + 3, 33, NAME)
    rect(x + 16, P.FADER_Y - 2, 3, P.FADER_H + 4, C.slot)                      -- the fader's slot
    for k = 0, 10, 2 do line(x + 21, P.cap_y(k), x + 23, P.cap_y(k), C.body_hi) end -- its scale
  end
end

local last = {}
function P.build()
  last = {}
  canvas("PANEL_M", "DESK")
  target("PANEL_M")
  body()
  target()
end

local function changed(key, sig)
  if last[key] == sig then return false end
  last[key] = sig
  return true
end

local LETTER = {font = "badge", color = C.ink}
local function draw_button(s, on, kind)
  local col = kind == "mute" and (on and C.mute or C.mute_off) or (on and C.solo or C.solo_off)
  rect(s.x, s.y, s.w, s.h, C.ink)
  rect(s.x + 1, s.y + 1, s.w - 2, s.h - 2, col)
  text(kind == "mute" and "M" or "S", s.x + 7, s.y, LETTER)
end

local function draw_fader(c, v, sel)
  local x = X0 + (c - 1) * W
  rect(x + 9, P.FADER_Y - 5, 16, P.FADER_H + 10, C.strip)
  rect(x + 16, P.FADER_Y - 2, 3, P.FADER_H + 4, C.slot)
  for k = 0, 10, 2 do line(x + 21, P.cap_y(k), x + 23, P.cap_y(k), C.body_hi) end
  local y = P.cap_y(v)
  rect(x + 10, y - 4, 15, 9, sel and C.sel or C.cap_lo)
  rect(x + 10, y - 4, 15, 7, C.cap)
  line(x + 10, y - 4, x + 24, y - 4, C.cap_hi)
  line(x + 11, y, x + 23, y, C.cap_line)
end

local function draw_meter(c, n)                     -- n: 0..10 LEDs lit
  local x = X0 + (c - 1) * W + 3
  for k = 1, 10 do
    local y = P.FADER_Y + P.FADER_H - k * 6 + 2
    local on = k <= n
    rect(x, y, 4, 4, on and (k > 8 and C.led_r or k > 6 and C.led_y or C.led_g) or C.led_off)
  end
end

local function draw_lcd(str)
  rect(LCD.x, LCD.y, LCD.w, LCD.h, C.lcd)
  text(str, LCD.x + 3, LCD.y - 4, {font = "lcd", color = C.lcd_ink})
end

local ID_F, ID_M, ID_S, ID_L = {}, {}, {}, {}
for c = 1, 8 do ID_F[c], ID_M[c], ID_S[c], ID_L[c] = "f" .. c, "m" .. c, "s" .. c, "l" .. c end

-- v = {fader, mute, solo, meter (0..10 each), sel (channel in hand), lcd}
function P.draw(v)
  target("PANEL_M")
  for c = 1, P.N do
    if changed(ID_F[c], v.fader[c] + (v.sel == c and 100 or 0)) then draw_fader(c, v.fader[c], v.sel == c) end
    if changed(ID_M[c], v.mute[c]) then draw_button(P.SPOTS[ID_M[c]], v.mute[c], "mute") end
    if changed(ID_S[c], v.solo[c]) then draw_button(P.SPOTS[ID_S[c]], v.solo[c], "solo") end
    if changed(ID_L[c], v.meter[c]) then draw_meter(c, v.meter[c]) end
  end
  if changed("lcd", v.lcd) then draw_lcd(v.lcd) end
  target()
end

return P
