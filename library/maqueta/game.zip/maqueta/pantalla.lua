-- The computer: arranging the song. A on a block changes its pattern (A, B, C, D, none), on the bars how long the
-- section lasts, on the last column it adds one; C goes to that machine with that pattern to edit it.
local seq = require("seq")
local linea = require("linea")
local song = require("song")
local P = {}
P.panel = require("pantalla_panel")
P.focus = "c1_1"

local NAMES = {"RITMO", "LÍNEA"}

function P.aim(hands)
  local s = P.panel.SPOTS[P.focus]
  hands.point(s.tip[1], s.tip[2], "point")
end

local function cell(id)
  local s = P.panel.SPOTS[id]
  return s.kind == "cell" and s or nil
end

local function cycle(v, d, n) return (v + d) % (n + 1) end -- 0 (none) .. n

local function change(id, d, ctx)
  local s = cell(id)
  local n = #song.sections
  if s.c == n + 1 then                            -- the column after the last: a new section
    if s.r == 1 and song.add(n) then ctx.toast("SECCIÓN " .. (n + 1) .. " AÑADIDA") end
    ctx.touched()
    return
  end
  local sec = song.sections[s.c]
  if not sec then return end
  if s.r == 3 then
    local i = 1
    for k, b in ipairs(song.BARS) do if b == sec.bars then i = k end end
    sec.bars = song.BARS[(i - 1 + d) % #song.BARS + 1]
  elseif s.r == 1 then
    sec.d = cycle(sec.d, d, seq.NPAT)
  else
    sec.b = cycle(sec.b, d, 4)
  end
  ctx.touched()
end

function P.press(id, ctx)
  ctx.hands.press()
  if cell(id) then change(id, 1, ctx)
  elseif id == "smodo" then
    if seq.playing then ctx.toggle_play() end
    song.mode = song.mode == "cancion" and "patron" or "cancion"
    ctx.toast(song.mode == "cancion" and "CANCIÓN: PLAY LA TOCA ENTERA" or "PATRÓN: PLAY REPITE EL COMPÁS")
    ctx.touched()
  elseif id == "splay" then ctx.toggle_play()
  elseif id == "web" then espaiso.open()
  elseif id == "quitar" then
    local s = cell(P.last or "") or {c = #song.sections}
    if song.remove(s.c) then ctx.toast("SECCIÓN " .. s.c .. " QUITADA"); ctx.touched()
    else ctx.toast("UNA SECCIÓN COMO MÍNIMO") end
  end
end

-- C on a block: to that machine, that pattern in hand
function P.edit(id, ctx)
  local s = cell(id)
  local sec = s and song.sections[s.c]
  if not sec or s.r == 3 then return end
  local p = s.r == 1 and sec.d or sec.b
  if p == 0 then p = 1; if s.r == 1 then sec.d = 1 else sec.b = 1 end end
  if s.r == 1 then seq.select(p) else linea.select(p) end
  ctx.go(s.r == 1 and "ritmo" or "linea")
end

function P.input(ctx)
  local s = P.panel.SPOTS[P.focus]
  local dx = (btnp("right", 12, 4) and 1 or 0) - (btnp("left", 12, 4) and 1 or 0)
  local dy = (btnp("down", 12, 4) and 1 or 0) - (btnp("up", 12, 4) and 1 or 0)
  if dx ~= 0 or dy ~= 0 then
    P.focus = P.panel.move(P.focus, dx, dx == 0 and dy or 0, #song.sections + 1)
    if cell(P.focus) then P.last = P.focus end
    P.aim(ctx.hands)
  end
  if btnp("a") then P.press(P.focus, ctx) end
  if btnp("b") and s.kind == "cell" then change(P.focus, -1, ctx); ctx.hands.press() end
  if btnp("c") then P.edit(P.focus, ctx) end
end

function P.touch(tx, ty, first, ctx)
  if not first then return end
  local id = P.panel.at(tx, ty)
  if not id then return end
  local s = P.panel.SPOTS[id]
  if s.kind == "cell" and s.c > #song.sections + 1 then return end
  P.focus = id
  if cell(id) then P.last = id end
  P.aim(ctx.hands)
  P.press(id, ctx)
end

local LETTER = {"A", "B", "C", "D"}
function P.lcd()
  local s = cell(P.focus)
  if s then
    local n = #song.sections
    if s.c == n + 1 then return s.r == 1 and "A: AÑADIR SECCIÓN" or "" end
    local sec = song.sections[s.c]
    if s.r == 3 then return "SECCIÓN " .. s.c .. ": " .. sec.bars .. (sec.bars == 1 and " COMPÁS" or " COMPASES") end
    local p = s.r == 1 and sec.d or sec.b
    return "SECCIÓN " .. s.c .. ": " .. NAMES[s.r] .. " " .. (p > 0 and LETTER[p] or "CALLA")
  end
  if P.focus == "smodo" then return song.mode == "cancion" and "MODO CANCIÓN" or "MODO PATRÓN" end
  if P.focus == "web" then return "ESPAISO: TU MÚSICA" end
  if P.focus == "quitar" then return "QUITAR LA SECCIÓN " .. (cell(P.last or "") or {c = #song.sections}).c end
  local bars = song.length_bars()
  return string.format("%s  %d COMPASES, %d BPM", seq.playing and "STOP" or "PLAY", bars, seq.bpm())
end

local HINTS = {"A CAMBIA   B ATRÁS   C EDITA", "MENU: VUELVE A LA SALA"}
function P.hint()
  if cell(P.focus) then return HINTS[(ticks() // 180) % 2 + 1] end
  return "A PULSAR   MENU: VUELVE A LA SALA"
end

local view = {}
function P.view(lcd_text)
  view.sections, view.playing, view.song, view.cur = song.sections, seq.playing, song.mode == "cancion", song.cur
  local sec = song.sections[song.cur]
  view.progress = sec and ((song.bar - 1) + (seq.step + 1) / 16) / sec.bars or 0
  view.lcd = lcd_text
  return view
end

return P
