-- Nogal, the lead synth (a walnut Minimoog seen from the chair), drawn by code on its own 240x160 canvas: walnut cheeks,
-- an LCD, GLIDE / VIBRATO / VOLUMEN knobs, the wave button, the pitch and mod wheels beside two octaves of keys, REC,
-- PLAY and the sixteen steps. Same rules as nube_panel.lua: only what changed is drawn again.
local P = {}

local C = {
  body = 0x2B2C30, body_hi = 0x45474D, body_lo = 0x151618, band = 0x1E1F22, ink = 0x111214, cream = 0xF2EBDD,
  wood = 0x7A4A28, wood_hi = 0x9C6438, wood_lo = 0x4A2A14, red = 0xE0452C, orange = 0xE8742A, yellow = 0xE9B632,
  slot_off = 0x7A7C84, led_on = 0xFF3A1E, white = 0xEDE6D6, white_lo = 0xB8B0A0, black = 0x18181A,
  held = 0xFF6A38, held_black = 0xC83C14, knob = 0x18191C, mark = 0xEDEDE8, icon = 0x9A9EA8, key = 0x5A5D66,
  key_hi = 0x7A7E88, key_on = 0xE8742A, key_on_hi = 0xFFA060, head = 0xFFF4E0, lcd = 0x2A0806, lcd_ink = 0xFF6A4A,
  lcd_edge = 0x120302, wheel = 0xC9B28A, wheel_hi = 0xF0DCB0,
}
P.C = C
P.PANEL = {x = 6, y = 14, w = 228, h = 124}
local LCD = {x = 100, y = 17, w = 104, h = 12}
P.LCD = LCD
P.KEY_Y = 118
local KB = {x = 16, y = 62, n = 14, w = 9, h = 44}   -- two octaves from C3 (MIDI 48)
local BLACK_LEFT = {[1] = 0, [3] = 1, [6] = 3, [8] = 4, [10] = 5}
local WHITE_PC = {0, 2, 4, 5, 7, 9, 11}

P.SPOTS, P.ROWS = {}, {{}, {}, {}}
local function spot(id, row, kind, x, y, w, h, tip, extra)
  local s = {id = id, row = row, kind = kind, x = x, y = y, w = w, h = h, tip = tip}
  for k, v in pairs(extra or {}) do s[k] = v end
  P.SPOTS[id] = s
  table.insert(P.ROWS[row], id)
end
spot("nglide", 1, "knob", 25, 33, 19, 18, {34, 42}, {cx = 34, cy = 42, r = 8})
spot("nvib", 1, "knob", 69, 33, 19, 18, {78, 42}, {cx = 78, cy = 42, r = 8})
spot("nvol", 1, "knob", 113, 33, 19, 18, {122, 42}, {cx = 122, cy = 42, r = 8})
spot("nonda", 1, "button", 150, 38, 30, 14, {165, 45})
spot("nhum", 1, "button", 190, 38, 30, 14, {205, 45})
spot("nbend", 2, "wheel", 156, 60, 16, 48, {164, 84})
spot("nmod", 2, "wheel", 177, 60, 16, 48, {185, 84})
spot("nrec", 2, "button", 202, 62, 22, 16, {213, 70})
spot("nroll", 2, "button", 202, 106, 22, 9, {213, 110})
spot("nplay", 2, "button", 202, 84, 22, 20, {213, 94})
for s = 0, 15 do
  local x = 9 + s * 14
  spot("nstep" .. s, 3, "step", x, P.KEY_Y, 12, 16, {x + 6, P.KEY_Y + 7}, {step = s})
end

function P.key_at(x, y)
  if x < KB.x or x >= KB.x + KB.n * KB.w or y < KB.y or y >= KB.y + KB.h then return nil end
  if y < KB.y + 26 then
    for oct = 0, 1 do
      for pc, left in pairs(BLACK_LEFT) do
        local bx = KB.x + (oct * 7 + left + 1) * KB.w - 3
        if x >= bx and x < bx + 5 then return 48 + oct * 12 + pc end
      end
    end
  end
  local k = (x - KB.x) // KB.w
  return 48 + (k // 7) * 12 + WHITE_PC[k % 7 + 1]
end

-- The piano roll that takes the keyboard's place: sixteen columns of 8 px, fourteen rows of 3 (C major from C3, the notes
-- of A minor too). Returns the step (1..16) and the note under a finger, or nil.
local ROLL_X, ROLL_ROWS, ROLL_H = KB.x, 14, 3
local MAJOR = {0, 2, 4, 5, 7, 9, 11}
local function row_midi(r) return 48 + 12 * (r // 7) + MAJOR[r % 7 + 1] end
function P.roll_at(x, y)
  if x < ROLL_X or x >= ROLL_X + 16 * 8 or y < KB.y or y >= KB.y + KB.h then return nil end
  local r = math.min(ROLL_ROWS - 1, (KB.y + ROLL_ROWS * ROLL_H - 1 - y) // ROLL_H)
  if r < 0 then r = 0 end
  return (x - ROLL_X) // 8 + 1, row_midi(r)
end

function P.at(x, y)
  for id, s in pairs(P.SPOTS) do
    if x >= s.x - 1 and x < s.x + s.w + 1 and y >= s.y - 1 and y < s.y + s.h + 1 then return id end
  end
end

function P.move(id, dx, dy)
  local s = P.SPOTS[id]
  if dx ~= 0 then
    local row = P.ROWS[s.row]
    for i, other in ipairs(row) do
      if other == id then return row[(i - 1 + dx) % #row + 1] end
    end
  end
  local r = (s.row - 1 + dy) % 3 + 1
  local best, bd = id, 1e9
  for _, other in ipairs(P.ROWS[r]) do
    local d = math.abs(P.SPOTS[other].tip[1] - s.tip[1])
    if d < bd then best, bd = other, d end
  end
  return best
end

local function body()
  local p = P.PANEL
  rect(p.x + 1, p.y, p.w - 2, p.h, C.body)
  rect(p.x, p.y + 1, p.w, p.h - 2, C.body)
  line(p.x + 1, p.y, p.x + p.w - 2, p.y, C.body_hi)
  line(p.x + 1, p.y + p.h - 1, p.x + p.w - 2, p.y + p.h - 1, C.body_lo)
  for _, x in ipairs({p.x, p.x + p.w - 5}) do                    -- the walnut cheeks
    rect(x, p.y + 1, 5, p.h - 2, C.wood)
    line(x, p.y + 1, x, p.y + p.h - 2, C.wood_hi)
    line(x + 4, p.y + 1, x + 4, p.y + p.h - 2, C.wood_lo)
  end
  rect(p.x + 6, p.y + 2, p.w - 12, 14, C.band)
  text("NOGAL", 14, 19, {font = "brand", color = C.cream})
  for k, col in ipairs({C.orange, C.cream, C.orange}) do line(p.x + 6, p.y + 16 + k, p.x + p.w - 7, p.y + 16 + k, col) end
  rect(LCD.x - 1, LCD.y - 1, LCD.w + 2, LCD.h + 2, C.lcd_edge)
  for _, id in ipairs({"nglide", "nvib", "nvol"}) do                -- the knobs' ticks
    local s = P.SPOTS[id]
    for k = 0, 10 do
      local a = math.rad(-135 + 27 * k)
      pset(math.floor(s.cx + math.sin(a) * (s.r + 2) + 0.5), math.floor(s.cy - math.cos(a) * (s.r + 2) + 0.5), C.body_hi)
    end
  end
  rect(14, P.KEY_Y - 3, 212, 1, C.body_lo)
end

local last = {}
function P.build()
  last = {}
  canvas("PANEL_O", "DESK")
  target("PANEL_O")
  body()
  target()
end

local function changed(key, sig)
  if last[key] == sig then return false end
  last[key] = sig
  return true
end

local function draw_keyboard(lit)                    -- lit: MIDI note -> 2 (played)
  rect(KB.x - 1, KB.y - 1, KB.n * KB.w + 1, KB.h + 2, C.ink)
  for k = 0, KB.n - 1 do
    local oct, idx = k // 7, k % 7
    local x = KB.x + k * KB.w
    rect(x, KB.y, KB.w - 1, KB.h, lit[48 + oct * 12 + WHITE_PC[idx + 1]] and C.held or C.white)
    line(x, KB.y + KB.h - 3, x + KB.w - 2, KB.y + KB.h - 3, C.white_lo)
  end
  for oct = 0, 1 do
    for pc, left in pairs(BLACK_LEFT) do
      local x = KB.x + (oct * 7 + left + 1) * KB.w - 3
      rect(x, KB.y, 5, 26, lit[48 + oct * 12 + pc] and C.held_black or C.black)
    end
  end
end

local function draw_roll_column(c, note, head)     -- c: 0..15
  local x = ROLL_X + c * 8
  local top = KB.y + KB.h - ROLL_ROWS * ROLL_H
  rect(x, KB.y, 7, KB.h, head and 0x3A3C44 or C.body_lo)
  for r = 0, ROLL_ROWS - 1 do
    local y = top + (ROLL_ROWS - 1 - r) * ROLL_H + 1
    if row_midi(r) % 12 == 0 then line(x, y + 2, x + 6, y + 2, C.body_hi) end   -- the Cs
    if note > 0 and note >= row_midi(r) and (r == ROLL_ROWS - 1 or note < row_midi(r + 1)) then
      rect(x, y, 7, 2, head and C.head or C.held)
    end
  end
end

local function draw_knob(s, v)
  circ(s.cx, s.cy, s.r + 1, C.body)
  circ(s.cx + 1, s.cy + 1, s.r, C.body_lo)
  circ(s.cx, s.cy, s.r, C.knob)
  circ(s.cx, s.cy, s.r - 3, 0x2a2a2d)
  local a = math.rad(-135 + 270 * math.max(0, math.min(1, v)))
  line(s.cx, s.cy, math.floor(s.cx + math.sin(a) * (s.r - 1) + 0.5), math.floor(s.cy - math.cos(a) * (s.r - 1) + 0.5), C.mark)
end

local function draw_wheel(s, v, spring)              -- v: -1..1 (a spring wheel rests in the middle) or 0..1
  rect(s.x, s.y, s.w, s.h, C.body_lo)
  rect(s.x + 2, s.y + 2, s.w - 4, s.h - 4, C.wheel)
  local mid = s.y + s.h // 2
  local y = spring and mid - math.floor(v * (s.h // 2 - 5)) or s.y + s.h - 6 - math.floor(v * (s.h - 12))
  rect(s.x + 2, y - 2, s.w - 4, 5, C.wheel_hi)
  line(s.x + 2, y + 3, s.x + s.w - 3, y + 3, C.wood_lo)
  if spring then line(s.x, mid, s.x + 1, mid, C.orange); line(s.x + s.w - 2, mid, s.x + s.w - 1, mid, C.orange) end
end

local function draw_button(s, face, label)
  rect(s.x, s.y, s.w, s.h, C.body_lo)
  rect(s.x, s.y, s.w, s.h - 2, face)
  line(s.x, s.y, s.x + s.w - 1, s.y, C.key_hi)
  if label then text(label, s.x + s.w // 2, s.y - 1, {font = "lcd", color = C.cream, align = "center"}) end
end

local function draw_hum(state)                      -- state: 0 off, 1 waiting for the bar, 2 listening
  draw_button(P.SPOTS.nhum, state > 0 and C.body_hi or C.key, "MIC")
  if state > 0 then circ(P.SPOTS.nhum.x + 4, P.SPOTS.nhum.y + 4, 1, state == 2 and C.led_on or C.yellow) end
end

local function draw_roll_icon(roll)                  -- the button shows what it will swap to: keys, or the roll's notes
  local s = P.SPOTS.nroll
  draw_button(s, roll and C.body_hi or C.key, nil)
  for k = 0, 4 do
    if roll then rect(s.x + 3 + k * 4, s.y + 2, 3, 4, C.white)
    else rect(s.x + 2 + k * 4, s.y + 2 + (k % 3), 4, 1, C.orange) end
  end
end

local function draw_play(on)
  local s = P.SPOTS.nplay
  rect(s.x, s.y, s.w, s.h, C.body)
  rect(s.x, s.y, s.w, s.h - 2, on and 0xFFD84A or C.yellow)
  rect(s.x, s.y + s.h - 2, s.w, 2, 0x8A6A14)
  if on then rect(s.x + 8, s.y + 6, 6, 6, C.ink)
  else tri(s.x + 8, s.y + 5, s.x + 8, s.y + 13, s.x + 14, s.y + 9, C.ink) end
end

local function draw_rec(state)
  local s = P.SPOTS.nrec
  draw_button(s, state > 0 and C.body_hi or C.key)
  circ(s.x + s.w // 2, s.y + 6, 3, state == 2 and C.led_on or state == 1 and C.red or C.slot_off)
end

local function draw_key(st, on, head)
  local x, y = 9 + st * 14, P.KEY_Y
  rect(x - 1, y - 1, 14, 18, C.body)
  local c = on and C.key_on or C.key
  if head then c = on and C.head or C.key_hi end
  rect(x, y, 12, 14, c)
  line(x, y, x + 11, y, on and C.key_on_hi or C.key_hi)
  rect(x + 1, y + 14, 11, 2, C.body_lo)
end

local function draw_lcd(str)
  rect(LCD.x, LCD.y, LCD.w, LCD.h, C.lcd)
  text(str, LCD.x + 3, LCD.y - 4, {font = "lcd", color = C.lcd_ink})
end

local KEY_ID = {}
for k = 0, 15 do KEY_ID[k] = "k" .. k end

-- v = {glide, vib, vol (0..1), wave (3 letters), bend (-1..1), mod (0..1), rec (0, 1, 2), hum (0, 1, 2), roll (bool), steps (step -> MIDI or 0),
--      playing, step, lit (MIDI -> true), lit_sig, lcd}
function P.draw(v)
  target("PANEL_O")
  if changed("roll", v.roll) then
    if v.roll then rect(KB.x - 1, KB.y - 1, KB.n * KB.w + 1, KB.h + 2, C.ink) end
    last.kb = nil; for c = 0, 15 do last["rc" .. c] = nil end end
  if v.roll then
    for c = 0, 15 do
      local head = v.playing and v.step == c
      if changed("rc" .. c, v.steps[c + 1] * 4 + (head and 1 or 0)) then draw_roll_column(c, v.steps[c + 1], head) end
    end
  elseif changed("kb", v.lit_sig) then draw_keyboard(v.lit) end
  if changed("rollbtn", v.roll) then draw_roll_icon(v.roll) end
  if changed("glide", v.glide) then draw_knob(P.SPOTS.nglide, v.glide) end
  if changed("vib", v.vib) then draw_knob(P.SPOTS.nvib, v.vib) end
  if changed("vol", v.vol) then draw_knob(P.SPOTS.nvol, v.vol) end
  if changed("onda", v.wave) then draw_button(P.SPOTS.nonda, C.key, v.wave) end
  if changed("bend", v.bend) then draw_wheel(P.SPOTS.nbend, v.bend, true) end
  if changed("mod", v.mod) then draw_wheel(P.SPOTS.nmod, v.mod, false) end
  if changed("rec", v.rec) then draw_rec(v.rec) end
  if changed("hum", v.hum) then draw_hum(v.hum) end
  if changed("play", v.playing) then draw_play(v.playing) end
  for st = 0, 15 do
    local head = v.playing and v.step == st
    if changed(KEY_ID[st], (v.steps[st + 1] > 0 and 1 or 0) + (head and 2 or 0)) then
      draw_key(st, v.steps[st + 1] > 0, head)
    end
  end
  if changed("lcd", v.lcd) then draw_lcd(v.lcd) end
  target()
end

return P
