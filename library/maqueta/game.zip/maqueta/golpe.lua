-- Golpe 60, the sampler: four pads that hold any sound the microphone hears (or the ones it comes with), each with
-- its tone and level and sixteen steps, on the studio's tracks 10 to 13. REC arms the pad in hand and recording
-- starts by itself when a sound comes (no silence before it), stops after a moment of quiet or a second. DIRECTO:
-- A, B, C and up are the pads, and what is played while the music runs lands on its step.
-- ponytail: recordings live in memory (the engine cannot keep them): after a restart the pads have their own sounds
-- again; their steps, tone and level are kept.
local G = {}
G.panel = require("golpe_panel")
local P = G.panel

G.TRACK0 = 10
G.focus = "pad1"
G.sel = 1
local DEFAULT = {                                       -- what the pads hold before anything is recorded
  {wave = "sine", freq = 120, slide = -220, sustain = 0.05, decay = 0.25, volume = 0.75},              -- BUM
  {wave = "noise", freq = 4000, sustain = 0.02, decay = 0.12, highpass = 0.2, volume = 0.5},           -- CHAS
  {wave = "square", freq = 880, duty = 0.25, sustain = 0.03, decay = 0.3, volume = 0.35},              -- TIN
  {wave = "triangle", freq = 220, vibrato = 0.08, vibrato_speed = 6, attack = 0.02, sustain = 0.15,
   decay = 0.2, lowpass = 0.5, volume = 0.55},                                                         -- UH
}
G.NAME = {"BUM", "CHAS", "TIN", "UH"}
local PADS = {a = 1, b = 2, c = 3, up = 4}
local PAD_HAND = {a = "right", b = "right", c = "right", up = "left"}

local function blank() local t = {} for s = 1, 16 do t[s] = 0 end return t end

function G.reset()
  G.pads = {}
  for i = 1, 4 do G.pads[i] = {steps = blank(), tune = 0, level = 8, rec = false} end
  G.pads[1].steps[1], G.pads[1].steps[9] = 1, 1                -- no blank page: a pulse to play over
  G.sent, G.lit = {{}, {}, {}, {}}, {}
  G.rec = nil
  G.signature = nil
  G.pending_hear = nil
end

function G.make_sounds()
  for i = 1, 4 do sound("PAD" .. i, DEFAULT[i]) end
end

local function vel(steps)
  local v = {}
  for s = 1, 16 do v[s] = steps[s] > 0 and 0.85 or 0 end
  return v
end

-- The studio told only what changed (every tick: numbers, no new tables unless it changed).
function G.sync()
  if not seq.engine then return end
  for i = 1, 4 do
    local pd, s = G.pads[i], G.sent[i]
    local gain = seq.mute and 0 or pd.level / 10 * 0.9 * seq.volume * (mesa and mesa.gain(7) or 1)
    local pitch = 2 ^ (pd.tune / 12)
    if s.gain ~= gain or s.pitch ~= pitch or s.fresh ~= pd.rec then
      studio.track(G.TRACK0 + i - 1, {sound = "PAD" .. i, gain = gain, pitch = pitch})
      s.gain, s.pitch, s.fresh = gain, pitch, pd.rec
    end
    local sig = 0
    for k = 1, 16 do sig = sig * 2 + (pd.steps[k] > 0 and 1 or 0) end
    if s.sig ~= sig then studio.steps(G.TRACK0 + i - 1, vel(pd.steps)); s.sig = sig end
  end
end

function G.hit(i, hand)
  local pd = G.pads[i]
  if seq.engine then studio.hit(G.TRACK0 + i - 1, 0.9)
  else sfx("PAD" .. i, pd.level / 10 * 0.9 * seq.volume, {pitch = 2 ^ (pd.tune / 12)}) end
  G.lit[i] = 8
  G.played = (G.played or 0) + 1
  if hand then hands.press(hand) end
end

-- A recorded pad can be the player's producer tag. Mic samples live only in RAM, so the tag does too.
function G.signature_start()
  local i = G.signature
  if not i or not G.pads[i].rec or G.rec then return false end
  G.sync()
  G.hit(i)
  return true
end

-- ===== recording =====

function G.arm(i, ctx)
  if G.rec then return end
  if not mic() then ctx.toast("SIN MICRO: NO SE PUEDE GRABAR") return end
  G.rec = {pad = i, state = "armed", t = 0, quiet = 0}
  ctx.toast("¡HAZ EL SONIDO AL MICRO!", 150)
end

function G.update_rec(ctx)
  local r = G.rec
  if not r then return end
  r.t = r.t + 1
  local level, pitch, hit, recording, kind = mic()
  if not level then G.rec = nil return end
  if r.state == "armed" then
    led(ticks() % 20 < 10 and 0xFF0000 or 0x000000)
    if level >= 0.2 or hit then                       -- the sound starts: so does the recording
      mic_record("PAD" .. r.pad, 1.0)
      r.state, r.t = "rec", 0
      led(0xFF0000)
    elseif r.t > 360 then
      G.rec = nil
      led()
      mic(false)
      ctx.toast("NO HE OÍDO NADA", 120)
    end
    return
  end
  if pitch and pitch > 0 and level > 0.15 and (kind == "voice" or kind == "whistle") then   -- the note it was sung at
    r.pitches = r.pitches or {}
    r.pitches[#r.pitches + 1] = pitch
  end
  r.quiet = level < 0.12 and r.quiet + 1 or 0
  if (r.t > 12 and r.quiet > 15) or (r.t > 3 and not recording) then
    if recording then mic_record() end
    G.pads[r.pad].rec = true
    G.pads[r.pad].root = nil
    if r.pitches and #r.pitches >= 3 then                -- a sung or whistled sound has a note: the keyboard plays it from there
      table.sort(r.pitches)
      G.pads[r.pad].root = math.floor(69 + 12 * math.log(r.pitches[(#r.pitches + 1) // 2] / 440, 2) + 0.5)
    end
    G.recorded = (G.recorded or 0) + 1
    G.rec = nil
    led()
    mic(false)
    ctx.toast("PAD " .. P.PAD_KEY[r.pad] .. " GRABADO", 120)
    G.pending_hear = {pad = r.pad, ticks = 6}          -- a moment for the sound to be in place, then hear it
  end
end

-- ===== playing it =====

G.KNOBS = {
  gtono = {get = function() return (G.pads[G.sel].tune + 12) / 24 end,
           turn = function(d) local pd = G.pads[G.sel]; pd.tune = math.max(-12, math.min(12, pd.tune + d)) end},
  gnivel = {get = function() return G.pads[G.sel].level / 10 end,
            turn = function(d) local pd = G.pads[G.sel]; pd.level = math.max(0, math.min(10, pd.level + d)) end},
}

function G.aim(h)
  local s = P.SPOTS[G.focus]
  h.point(s.tip[1], s.tip[2], s.kind == "knob" and "pinch" or "point")
end

local function turn(id, d, ctx)
  local k = G.KNOBS[id]
  local before = k.get()
  k.turn(d)
  if k.get() ~= before then
    hands.twist()
    ctx.touched()
    if not seq.playing then G.hit(G.sel) end
  end
end
G.turn = turn

function G.press(id, ctx)
  local s = P.SPOTS[id]
  if s.kind == "pad" then
    G.sel = s.pad
    G.hit(s.pad)
    hands.press()
  elseif s.kind == "step" then
    local steps = G.pads[G.sel].steps
    steps[s.step + 1] = steps[s.step + 1] > 0 and 0 or 1
    hands.press()
    ctx.touched()
  elseif id == "rec" then hands.press(); G.arm(G.sel, ctx)
  elseif id == "gplay" then hands.press(); ctx.toggle_play()
  elseif id == "gmodo" then hands.press(); ctx.set_mode(ctx.mode() == "pasos" and "directo" or "pasos") end
end

function G.input_pasos(ctx)
  if btnp("b") then
    if G.pads[G.sel].rec then
      G.signature = G.signature == G.sel and nil or G.sel
      ctx.toast(G.signature and "FIRMA: PAD " .. P.PAD_KEY[G.sel] or "FIRMA QUITADA", 120)
    else
      ctx.toast("GRABA UN PAD PARA TU FIRMA", 120)
    end
  end
  local s = P.SPOTS[G.focus]
  if s.kind == "knob" and btn("a") then
    if btnp("left", 10, 3) or btnp("down", 10, 3) then turn(G.focus, -1, ctx) end
    if btnp("right", 10, 3) or btnp("up", 10, 3) then turn(G.focus, 1, ctx) end
  else
    local dx = (btnp("right", 12, 4) and 1 or 0) - (btnp("left", 12, 4) and 1 or 0)
    local dy = (btnp("down", 12, 4) and 1 or 0) - (btnp("up", 12, 4) and 1 or 0)
    if dx ~= 0 or dy ~= 0 then
      G.focus = P.move(G.focus, dx, dx == 0 and dy or 0)
      G.aim(hands)
    end
  end
  if btnp("a") and s.kind ~= "knob" then G.press(G.focus, ctx) end
end

function G.input_directo(ctx)
  for b, i in pairs(PADS) do
    if btnp(b) then
      G.sel = i
      G.hit(i, PAD_HAND[b])
      if seq.playing then                              -- played over the music: it stays, on its step
        G.pads[i].steps[seq.nearest() + 1] = 1
        ctx.touched()
      end
    end
  end
end

-- A finger: a pad plays, a key toggles (and a drag along the keys paints them), a knob turns up and down.
local drag
function G.touch(tx, ty, first, ctx)
  if first then
    local id = P.at(tx, ty)
    drag = {id = id, y = ty}
    if not id then return end
    G.focus = id
    G.aim(hands)
    local s = P.SPOTS[id]
    if s.kind ~= "knob" then G.press(id, ctx) end
    if s.kind == "step" then drag.paint, drag.done = G.pads[G.sel].steps[s.step + 1], {[id] = true} end
    return
  end
  if not drag or not drag.id then return end
  if drag.paint then
    local id = P.at(tx, ty)
    local s = id and P.SPOTS[id]
    if s and s.kind == "step" and not drag.done[id] then
      drag.done[id] = true
      G.pads[G.sel].steps[s.step + 1] = drag.paint
      hands.point(s.tip[1], s.tip[2], "point")
      hands.press()
      ctx.touched()
    end
  elseif G.KNOBS[drag.id] then
    local acc = drag.y - ty
    if math.abs(acc) >= 4 then
      turn(drag.id, acc > 0 and 1 or -1, ctx)
      drag.y = ty
    end
  end
end

function G.update()
  for i, n in pairs(G.lit) do G.lit[i] = n > 1 and n - 1 or nil end
  if G.pending_hear then
    local pending = G.pending_hear
    pending.ticks = pending.ticks - 1
    if pending.ticks <= 0 then
      G.pending_hear = nil
      G.sent[pending.pad].fresh = nil
      G.sync()
      G.hit(pending.pad)
    end
  end
end

function G.lcd(ctx)
  local r = G.rec
  if r then return r.state == "armed" and "¡HAZ EL SONIDO!" or "GRABANDO..." end
  if ctx.mode() == "directo" then return "DIRECTO" end
  local s = P.SPOTS[G.focus]
  local key = P.PAD_KEY[G.sel]
  local pd = G.pads[G.sel]
  if s.kind == "pad" then
    if G.signature == s.pad then return "PAD " .. P.PAD_KEY[s.pad] .. ": FIRMA" end
    return "PAD " .. P.PAD_KEY[s.pad] .. ": " .. (G.pads[s.pad].rec and "TUYO" or G.NAME[s.pad])
  end
  if s.kind == "step" then return fit_lcd("PAD " .. key .. "  PASO " .. (s.step + 1), "PAD " .. key .. " P" .. (s.step + 1)) end
  if G.focus == "gtono" then return "TONO " .. (pd.tune > 0 and "+" or "") .. pd.tune end
  if G.focus == "gnivel" then return "NIVEL " .. pd.level end
  if G.focus == "rec" then return "REC: PAD " .. key end
  if G.focus == "gplay" then return seq.playing and "STOP" or string.format("PLAY  %d BPM", seq.bpm()) end
  return ctx.mode() == "pasos" and "MODO PASOS" or "MODO DIRECTO"
end

local HINTS = {pad = "A TOCA   B FIRMA   MENU: SALA", step = "A PASO DEL PAD   MENU: SALA",
               knob = "MANTÉN A Y MUEVE LA CRUCETA", button = "A PULSAR   MENU: SALA", switch = "A CAMBIAR A DIRECTO"}
function G.hint(ctx)
  if G.rec then return G.rec.state == "armed" and "SOPLA, HABLA, DA UNA PALMADA..." or "¡GRABANDO!" end
  if ctx.mode() == "directo" then return "A B C Y ARRIBA: PADS   MENU: PASOS" end
  return HINTS[P.SPOTS[G.focus].kind]
end

local view = {}
function G.view(ctx, lcd_text)
  view.pads, view.sel, view.lit, view.playing, view.step = G.pads, G.sel, G.lit, seq.playing, seq.step
  view.rec_state, view.directo, view.lcd = G.rec and G.rec.state, ctx.mode() == "directo", lcd_text
  return view
end

-- ===== kept =====

local function to_text(steps) local t = {} for s = 1, 16 do t[s] = steps[s] > 0 and "x" or "." end return table.concat(t) end
function G.save()
  local t = {sel = G.sel, pads = {}}
  for i, pd in ipairs(G.pads) do t.pads[i] = {steps = to_text(pd.steps), tune = pd.tune, level = pd.level} end
  store("golpe", t)
end

function G.load()
  G.reset()
  local t = stored("golpe")
  if type(t) ~= "table" or type(t.pads) ~= "table" then return end
  for i = 1, 4 do
    local s = t.pads[i]
    if type(s) == "table" then
      local pd = G.pads[i]
      if type(s.steps) == "string" and #s.steps == 16 then
        for k = 1, 16 do pd.steps[k] = s.steps:sub(k, k) == "x" and 1 or 0 end
      end
      if type(s.tune) == "number" then pd.tune = math.max(-12, math.min(12, math.floor(s.tune))) end
      if type(s.level) == "number" then pd.level = math.max(0, math.min(10, math.floor(s.level))) end
    end
  end
  if type(t.sel) == "number" and t.sel >= 1 and t.sel <= 4 then G.sel = math.floor(t.sel) end
end

G.reset()
return G
