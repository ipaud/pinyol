-- Línea 3, the acid bass: its pattern (a note per step in A minor, accents, slides), its sound on the studio's
-- synth track, and what the hands do on it. main.lua passes its helpers in `ctx`.
local seq = require("seq")
local L = {}
L.panel = require("linea_panel")

local TRACK = 9                               -- the studio track after Ritmo 88's eight
-- A natural minor over two octaves, A1 to A3: the notes the bass can play, low to high (scale degrees 1..15)
L.SCALE = {33, 35, 36, 38, 40, 41, 43, 45, 47, 48, 50, 52, 53, 55, 57}
local NAMES = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"}
local function name(midi) return NAMES[midi % 12 + 1] .. (midi // 12 - 1) end
-- the line it has when it is first switched on: no blank canvas (s = slide, ! = accent, 0 = rest)
local SEED = {{1}, {0}, {8, "!"}, {0}, {1, "s"}, {3}, {0}, {5}, {1}, {0}, {7}, {0}, {1, "!s"}, {8}, {0}, {3}}
-- DIRECTO: the console's buttons are notes: root, third, fifth on the triangle, the rest on the d-pad
local PADS = {a = 1, b = 3, c = 5, left = 2, right = 4, down = 7, up = 8}
local PAD_HAND = {a = "right", b = "right", c = "right", up = "left", down = "left", left = "left", right = "left"}

L.focus = "lstep0"
L.pressed = {}

local function blank()
  local d, a, sl = {}, {}, {}
  for s = 1, 16 do d[s], a[s], sl[s] = 0, false, false end
  return {deg = d, acc = a, slide = sl}
end

local function copy(pt)
  local c = blank()
  for s = 1, 16 do c.deg[s], c.acc[s], c.slide[s] = pt.deg[s], pt.acc[s], pt.slide[s] end
  return c
end

function L.reset()
  L.deg, L.acc, L.slide = {}, {}, {}
  for s = 1, 16 do
    local e = SEED[s]
    L.deg[s], L.acc[s], L.slide[s] = e[1], (e[2] or ""):find("!") ~= nil, (e[2] or ""):find("s") ~= nil
  end
  L.pats, L.pat, L.queued = {{deg = L.deg, acc = L.acc, slide = L.slide}}, 1, false
  L.patch = {wave = "saw", cutoff = 0.3, res = 0.75, env = 0.6, decay = 0.25, accent = 0.6, tune = 0}
  L.last_deg, L.sent = 1, {}
end

local function notes_of(pt)
  local notes = {}
  for s = 1, 16 do
    local d = pt.deg[s]
    notes[s] = d > 0 and {L.SCALE[d], accent = pt.acc[s], slide = pt.slide[s]} or 0
  end
  return notes
end

-- The studio's synth track, told only what changed (every tick: numbers, no new tables unless it changed).
function L.sync()
  if not seq.engine then return end
  local p, sent = L.patch, L.sent
  local vol = seq.mute and 0 or 0.8 * seq.volume * (mesa and mesa.gain(6) or 1)
  if sent.wave ~= p.wave or sent.cutoff ~= p.cutoff or sent.res ~= p.res or sent.env ~= p.env or
     sent.decay ~= p.decay or sent.accent ~= p.accent or sent.tune ~= p.tune or sent.vol ~= vol then
    studio.synth(TRACK, {wave = p.wave, cutoff = p.cutoff, res = p.res, env = p.env, decay = p.decay,
                         accent = p.accent, tune = p.tune, volume = vol, drive = 0.35})
    sent.wave, sent.cutoff, sent.res, sent.env, sent.decay, sent.accent, sent.tune, sent.vol =
      p.wave, p.cutoff, p.res, p.env, p.decay, p.accent, p.tune, vol
  end
  local sig = 0
  for s = 1, 16 do sig = sig * 4 + (L.acc[s] and 1 or 0) + (L.slide[s] and 2 or 0) + L.deg[s] * 0.0625 end
  if sent.sig ~= sig and not L.queued then          -- a pattern queued for the bar line waits for it
    studio.notes(TRACK, notes_of({deg = L.deg, acc = L.acc, slide = L.slide}))
    sent.sig = sig
  end
end

-- Edit and play pattern p (1-4); one never used starts as a copy of the one in hand; 0 is silence.
function L.select(p)
  if p > 0 and not L.pats[p] then L.pats[p] = copy({deg = L.deg, acc = L.acc, slide = L.slide}) end
  local pt = p > 0 and L.pats[p] or blank()
  L.deg, L.acc, L.slide, L.pat, L.queued = pt.deg, pt.acc, pt.slide, p, false
end

-- A song's next section: on the studio at the next bar line; select(p) follows when it is heard.
function L.queue(p)
  if not seq.engine then return end
  studio.notes(TRACK, notes_of(p > 0 and L.pats[p] or blank()), true)
  L.queued = true
end

function L.used(p) return p > 0 and L.pats[p] ~= nil end

-- A note now: on the synth track, or on a tone() voice where the firmware has no studio.
function L.play(d, accent)
  if d <= 0 then return end
  local midi = L.SCALE[d] + L.patch.tune
  if seq.engine then L.sync(); studio.note(TRACK, midi, accent) return end
  local hz = 440 * 2 ^ ((midi - 69) / 12)
  tone(0, hz, {wave = L.patch.wave == "saw" and "saw" or "square", vol = (accent and 0.45 or 0.3) * mesa.gain(6),
            decay = L.patch.decay})
end

-- The tick clock's steps (no studio): the bass plays here.
function L.fire(s)
  if seq.mute then return end
  local d = L.deg[s + 1]
  if d > 0 then L.play(d, L.acc[s + 1]) end
end

local function clamp(v, lo, hi) return math.max(lo, math.min(hi, v)) end
local function pct(v) return math.floor(v * 100 + 0.5) end

L.KNOBS = {
  ltono = {get = function() return (L.patch.tune + 12) / 24 end,
           turn = function(d) L.patch.tune = clamp(L.patch.tune + d, -12, 12) end,
           lcd = function() local t = L.patch.tune; return "TONO " .. (t > 0 and "+" or "") .. t end},
  corte = {get = function() return L.patch.cutoff end,
           turn = function(d) L.patch.cutoff = clamp(L.patch.cutoff + d * 0.04, 0, 1) end,
           lcd = function() return "CORTE " .. pct(L.patch.cutoff) end},
  reso = {get = function() return L.patch.res end,
          turn = function(d) L.patch.res = clamp(L.patch.res + d * 0.05, 0, 1) end,
          lcd = function() return "RESONANCIA " .. pct(L.patch.res) end},
  env = {get = function() return L.patch.env end,
         turn = function(d) L.patch.env = clamp(L.patch.env + d * 0.05, 0, 1) end,
         lcd = function() return "ENVOLVENTE " .. pct(L.patch.env) end},
  lcaida = {get = function() return (L.patch.decay - 0.05) / 0.95 end,
            turn = function(d) L.patch.decay = clamp(L.patch.decay + d * 0.05, 0.05, 1) end,
            lcd = function() return string.format("CAÍDA %.2f S", L.patch.decay) end},
  acento = {get = function() return L.patch.accent end,
            turn = function(d) L.patch.accent = clamp(L.patch.accent + d * 0.1, 0, 1) end,
            lcd = function() return "ACENTO " .. pct(L.patch.accent) end},
}

function L.aim(hands)
  local s = L.panel.SPOTS[L.focus]
  hands.point(s.tip[1], s.tip[2], s.kind == "knob" and "pinch" or "point")
end

local function step_of(id) return L.panel.SPOTS[id].step end

-- A on a control: a step comes on with the last note used, or (held down, not moved) goes off on release.
function L.press(id, ctx)
  local s = L.panel.SPOTS[id]
  ctx.hands.press()
  if s.kind == "step" then
    local k = s.step + 1
    L.pressed[s.step] = 6
    if L.deg[k] == 0 then
      L.deg[k] = L.last_deg
      if not seq.playing then L.play(L.deg[k], L.acc[k]) end
      L.pending_off = nil
    else
      L.pending_off = s.step
    end
    ctx.touched()
  elseif id == "lplay" then
    ctx.toggle_play()
  elseif id == "onda" then
    L.patch.wave = L.patch.wave == "saw" and "square" or "saw"
    if not seq.playing then L.play(L.last_deg, false) end
    ctx.touched()
  elseif id == "lmodo" then
    ctx.set_mode(ctx.mode() == "pasos" and "directo" or "pasos")
  elseif id == "lpat" then
    local new = not L.used(L.pat % 4 + 1)
    L.select(L.pat % 4 + 1)
    ctx.toast("PATRÓN " .. ({"A", "B", "C", "D"})[L.pat] .. (new and ": COPIA DEL ANTERIOR" or ""))
    ctx.touched()
  end
end

local function nudge(d, ctx)                      -- A held on a step, up or down: the note climbs the scale
  local k = step_of(L.focus) + 1
  if L.deg[k] == 0 then return end
  L.deg[k] = clamp(L.deg[k] + d, 1, #L.SCALE)
  L.last_deg, L.pending_off = L.deg[k], nil
  if not seq.playing then L.play(L.deg[k], L.acc[k]) end
  ctx.hands.press()
  ctx.touched()
end

local function toggle(field, ctx)
  local k = step_of(L.focus) + 1
  if L.deg[k] == 0 then return end
  L[field][k] = not L[field][k]
  L.pressed[k - 1] = 6
  ctx.hands.press()
  ctx.touched()
end

function L.input_pasos(ctx)
  local s = L.panel.SPOTS[L.focus]
  local held = btn("a")
  if held and s.kind == "knob" then
    local k = L.KNOBS[L.focus]
    local d = ((btnp("right", 10, 3) or btnp("up", 10, 3)) and 1 or 0) - ((btnp("left", 10, 3) or btnp("down", 10, 3)) and 1 or 0)
    if d ~= 0 then
      local before = k.get()
      k.turn(d)
      if k.get() ~= before then ctx.hands.twist(); ctx.touched() end
    end
  elseif held and s.kind == "step" then
    if btnp("up", 10, 4) then nudge(1, ctx) end
    if btnp("down", 10, 4) then nudge(-1, ctx) end
  else
    local dx = (btnp("right", 12, 4) and 1 or 0) - (btnp("left", 12, 4) and 1 or 0)
    local dy = (btnp("down", 12, 4) and 1 or 0) - (btnp("up", 12, 4) and 1 or 0)
    if dx ~= 0 or dy ~= 0 then
      L.focus = L.panel.move(L.focus, dx, dx == 0 and dy or 0)
      L.aim(ctx.hands)
    end
  end
  if btnp("a") then L.press(L.focus, ctx) end
  if btnr("a") and L.pending_off and s.kind == "step" and L.pending_off == s.step then
    L.deg[s.step + 1], L.acc[s.step + 1], L.slide[s.step + 1] = 0, false, false
    ctx.touched()
  end
  if btnr("a") then L.pending_off = nil end
  if s.kind == "step" then
    if btnp("b") then toggle("acc", ctx) end
    if btnp("c") then toggle("slide", ctx) end
  end
end

function L.input_directo(ctx)
  for b, d in pairs(PADS) do
    if btnp(b) then
      L.play(d, false)
      if seq.playing then
        local s = seq.nearest()
        L.deg[s + 1], L.last_deg = d, d
        ctx.touched()
      end
      ctx.hands.press(PAD_HAND[b])
      L.flash = {d = d, t = 20}
    end
  end
end

-- A finger: on a key, A; up or down the strip above it, the note at that height.
function L.touch(tx, ty, first, ctx)
  local id = L.panel.at(tx, ty)
  if not id then return end
  local s = L.panel.SPOTS[id]
  if s.kind == "step" and ty < L.panel.KEY_Y - 4 then
    local d = clamp(math.floor((L.panel.ROLL_Y + L.panel.ROLL_H - 1 - ty) / 2) + 1, 1, #L.SCALE)
    local k = s.step + 1
    if L.deg[k] ~= d then
      L.deg[k], L.last_deg = d, d
      if not seq.playing then L.play(d, L.acc[k]) end
      ctx.touched()
    end
    L.focus = id
    L.aim(ctx.hands)
  elseif first then
    L.focus = id
    L.aim(ctx.hands)
    if s.kind == "step" then                        -- a tap on a key: on with the last note, or off
      local k = s.step + 1
      if L.deg[k] > 0 then L.deg[k], L.acc[k], L.slide[k] = 0, false, false
      else L.deg[k] = L.last_deg; if not seq.playing then L.play(L.deg[k], L.acc[k]) end end
      L.pressed[s.step] = 6
      ctx.hands.press()
      ctx.touched()
    elseif s.kind ~= "knob" then
      L.press(id, ctx)
    end
  end
end

function L.lcd(ctx)
  if ctx.mode() == "directo" then
    return L.flash and L.flash.t > 0 and ("NOTA " .. name(L.SCALE[L.flash.d] + L.patch.tune)) or "DIRECTO"
  end
  local k = L.KNOBS[L.focus]
  if k then return k.lcd() end
  if L.focus == "onda" then return L.patch.wave == "saw" and "ONDA SIERRA" or "ONDA CUADRADA" end
  if L.focus == "lplay" then return seq.playing and "STOP" or string.format("PLAY  %d BPM", seq.bpm()) end
  if L.focus == "lmodo" then return ctx.mode() == "pasos" and "MODO PASOS" or "MODO DIRECTO" end
  if L.focus == "lpat" then return L.pat > 0 and ("PATRÓN " .. ({"A", "B", "C", "D"})[L.pat]) or "PATRÓN: CALLA" end
  local s = step_of(L.focus) + 1
  if L.deg[s] == 0 then return fit_lcd("PASO " .. s .. ": SILENCIO", "P" .. s .. ": SILENCIO") end
  local tags = (L.acc[s] and " AC" or "") .. (L.slide[s] and " SL" or "")
  local long = "PASO " .. s .. ": " .. name(L.SCALE[L.deg[s]] + L.patch.tune) .. tags
  return fit_lcd(long, "P" .. s .. ": " .. name(L.SCALE[L.deg[s]] + L.patch.tune) .. tags)
end

local STEP_HINTS = {"A NOTA   B ACENTO   C SLIDE", "MANTÉN A Y SUBE O BAJA LA NOTA", "MENU: VUELVE A LA SALA"}
function L.hint(ctx)
  if ctx.mode() == "directo" then return "A B C Y CRUCETA: NOTAS   MENU: PASOS" end
  local kind = L.panel.SPOTS[L.focus].kind
  if kind == "step" then return STEP_HINTS[(ticks() // 150) % 3 + 1] end
  if kind == "knob" then return "MANTÉN A Y MUEVE LA CRUCETA" end
  if L.focus == "onda" then return "A CAMBIA LA ONDA" end
  if L.focus == "lpat" then return "A OTRO PATRÓN (A-D)" end
  if L.focus == "lmodo" then return "A CAMBIAR A DIRECTO" end
  return "A PULSAR"
end

local view = {knobs = {}}
function L.view(ctx, lcd_text)
  local v = view
  for id, k in pairs(L.KNOBS) do v.knobs[id] = k.get() end
  v.deg, v.acc, v.slide, v.pressed = L.deg, L.acc, L.slide, L.pressed
  v.playing, v.step, v.wave, v.mode, v.lcd = seq.playing, seq.step, L.patch.wave, ctx.mode(), lcd_text
  v.pat = L.pat
  local sig = 0
  for s = 1, 16 do sig = sig * 2 + (L.deg[s] * 4 + (L.acc[s] and 1 or 0) + (L.slide[s] and 2 or 0)) % 997 end
  v.roll_sig = sig
  return v
end

function L.update_anim()
  for s, n in pairs(L.pressed) do L.pressed[s] = n > 1 and n - 1 or nil end
  if L.flash then L.flash.t = L.flash.t - 1 end
end

local function pack(pt)
  local steps = {}
  for s = 1, 16 do steps[s] = {pt.deg[s], pt.acc[s] and 1 or 0, pt.slide[s] and 1 or 0} end
  return steps
end

function L.save()
  local pats = {}
  for p = 1, 4 do pats[p] = L.pats[p] and pack(L.pats[p]) or false end
  local p = L.patch
  store("bajo", {pats = pats, pat = L.pat, wave = p.wave, cutoff = p.cutoff, res = p.res, env = p.env,
                 decay = p.decay, accent = p.accent, tune = p.tune})
end

local function num(v, lo, hi, d)
  if type(v) ~= "number" or v ~= v then return d end
  return math.max(lo, math.min(hi, v))
end

local function unpack_steps(steps)
  local pt = blank()
  for s = 1, 16 do
    local e = steps[s]
    if type(e) == "table" then
      pt.deg[s] = math.floor(num(e[1], 0, #L.SCALE, 0))
      pt.acc[s], pt.slide[s] = e[2] == 1, e[3] == 1
    end
  end
  return pt
end

function L.load()
  L.reset()
  local t = stored("bajo")
  if type(t) ~= "table" then return end
  if type(t.pats) == "table" then
    for p = 1, 4 do L.pats[p] = type(t.pats[p]) == "table" and unpack_steps(t.pats[p]) or nil end
    L.pats[1] = L.pats[1] or blank()
    L.select(math.floor(num(t.pat, 1, 4, 1)))
  elseif type(t.steps) == "table" then           -- a save from before the four patterns
    L.pats[1] = unpack_steps(t.steps)
    L.select(1)
  end
  local p = L.patch
  p.wave = (t.wave == "square") and "square" or "saw"
  p.cutoff, p.res, p.env = num(t.cutoff, 0, 1, p.cutoff), num(t.res, 0, 1, p.res), num(t.env, 0, 1, p.env)
  p.decay, p.accent, p.tune = num(t.decay, 0.05, 1, p.decay), num(t.accent, 0, 1, p.accent), math.floor(num(t.tune, -12, 12, 0))
end

L.reset()
return L
