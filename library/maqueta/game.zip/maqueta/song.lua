-- The song: sections in order, each a pattern of Ritmo 88 (or none), one of Línea 3 (or none), and how many bars.
-- In CANCIÓN mode PLAY goes through them and round again. A section's patterns are queued on the studio a bar
-- ahead (its 5th step) so they change exactly on the bar line; on the tick clock they change on it, in Lua.
local seq = require("seq")
local linea = require("linea")
local S = {}

S.MAX = 8
S.BARS = {1, 2, 4, 8}

function S.reset()
  -- no blank page: the drums alone for two bars, then the bass comes in
  S.sections = {{d = 1, b = 0, bars = 2}, {d = 1, b = 1, bars = 4}}
  S.mode = "patron"
  S.cur, S.bar, S.started = 1, 1, false
end

local function apply(sec)
  seq.select(sec.d)
  linea.select(sec.b)
end

function S.start()                            -- before the transport starts, in CANCIÓN mode
  S.cur, S.bar, S.started = 1, 1, false
  apply(S.sections[1])
  -- The producer's recorded tag belongs to the start of a song, never to pattern playback.
  S.tag_armed = not seq.playing
  if seq.playing and golpe then golpe.signature_start() end
end

local function after(cur, bar)
  bar = bar + 1
  if bar > S.sections[cur].bars then return cur % #S.sections + 1, 1 end
  return cur, bar
end

-- seq.on_heard: every step, as the player hears it
function S.heard(s)
  if S.mode ~= "cancion" or not seq.playing then return end
  if s == 0 then
    if S.tag_armed then
      S.tag_armed = false
      if golpe then golpe.signature_start() end
    end
    if not S.started then S.started = true return end
    local cur, bar = after(S.cur, S.bar)
    local new = cur ~= S.cur
    S.cur, S.bar = cur, bar
    if new then apply(S.sections[cur]) end    -- (on the studio it already changed, a moment before it was heard)
  elseif s == 4 then
    local cur = after(S.cur, S.bar)
    if cur ~= S.cur then
      seq.queue(S.sections[cur].d)
      linea.queue(S.sections[cur].b)
    end
  end
end

function S.add(at)                             -- a new section after `at`, a copy of it
  if #S.sections >= S.MAX then return false end
  local src = S.sections[at] or S.sections[#S.sections]
  table.insert(S.sections, (at or #S.sections) + 1, {d = src.d, b = src.b, bars = src.bars})
  return true
end

function S.remove(at)
  if #S.sections <= 1 or not S.sections[at] then return false end
  table.remove(S.sections, at)
  if S.cur > #S.sections then S.cur, S.bar = 1, 1 end
  return true
end

function S.length_bars()
  local n = 0
  for _, sec in ipairs(S.sections) do n = n + sec.bars end
  return n
end

function S.save()
  store("cancion", {sections = S.sections, mode = S.mode})
end

function S.load()
  S.reset()
  local t = stored("cancion")
  if type(t) ~= "table" or type(t.sections) ~= "table" or #t.sections == 0 then return end
  local secs = {}
  for k = 1, math.min(#t.sections, S.MAX) do
    local e = t.sections[k]
    if type(e) == "table" then
      local function pat(v) return type(v) == "number" and v == v and math.max(0, math.min(4, math.floor(v))) or 0 end
      local bars = 1
      for _, b in ipairs(S.BARS) do if e.bars == b then bars = b end end
      secs[#secs + 1] = {d = pat(e.d), b = pat(e.b), bars = bars}
    end
  end
  if #secs > 0 then S.sections = secs end
  S.mode = t.mode == "cancion" and "cancion" or "patron"
end

S.reset()
return S
