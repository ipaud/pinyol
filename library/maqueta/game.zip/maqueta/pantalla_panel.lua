-- The computer's screen, FRUITERA 4 (the guión's FruityLoops of 2004), drawn by code: a beige CRT whose screen is the
-- song, sections in columns, Ritmo 88, Línea 3 and the bars in rows, a pattern a coloured block with its letter.
local P = {}

local C = {
  bezel = 0xD9D2C0, bezel_hi = 0xEFEADC, bezel_lo = 0x9C9584, screen = 0x0E1424, grid = 0x1E2840, ink = 0x1a1a1c,
  title = 0x9FE07A, dim = 0x46506A, cream = 0xF2EBDD, head = 0xFFF4E0, yellow = 0xE9B632, led_on = 0xFF3A1E,
}
P.C = C
P.PAT_COL = {0xE0452C, 0xE8742A, 0xE9B632, 0xE9E1CF}  -- A B C D, the colours of Ritmo 88's keys
P.LETTER = {"A", "B", "C", "D"}
P.PANEL = {x = 6, y = 14, w = 228, h = 124}
P.COLS, P.COL_X, P.COL_W = 8, 44, 22
P.ROW_Y = {40, 60, 80}
local ROW_H = {16, 16, 12}
local LCD = {x = 18, y = 100, w = 204, h = 14}
P.LCD = LCD                                          -- (tests/textos.script: every LCD text fits)

local ICON = {
  ritmo = {"...#####...", "..#ccccc#..", ".#chhhhhc#.", "#chhhhhhhc#", "#chhhcchhc#", "#chhccc#hc#",
           "#chhhcchhc#", "#chhhhhhhc#", ".#chhhhhc#.", "..#ccccc#..", ".#.#####.#."},
  linea = {"....#####..", "....#...#..", "....#...#..", "....#...#..", "....#...#..", ".###..###..",
           "####.####..", ".##...##...", "...........", "...........", "..........."},
  bars = {"#..#..#..#.", "#..#..#..#.", "#..#..#..#.", "#..#..#..#.", "#..#..#..#.", "..........."},
}

local function icon(rows, x, y, col)
  local map = {["#"] = C.cream, c = col, h = 0x2a3044}
  for r, row in ipairs(rows) do
    for k = 1, #row do
      local ch = row:sub(k, k)
      if ch ~= "." then pset(x + k - 1, y + r - 1, map[ch]) end
    end
  end
end

P.SPOTS, P.ROWS = {}, {{}, {}, {}, {}}
local function spot(id, row, kind, x, y, w, h, tip, extra)
  local s = {id = id, row = row, kind = kind, x = x, y = y, w = w, h = h, tip = tip}
  for k, v in pairs(extra or {}) do s[k] = v end
  P.SPOTS[id] = s
  table.insert(P.ROWS[row], id)
end
for r = 1, 3 do
  for c = 1, P.COLS do
    local x = P.COL_X + (c - 1) * P.COL_W
    spot("c" .. r .. "_" .. c, r, "cell", x, P.ROW_Y[r], P.COL_W - 2, ROW_H[r], {x + 10, P.ROW_Y[r] + 6}, {r = r, c = c})
  end
end
spot("smodo", 4, "switch", 40, 124, 22, 8, {51, 128})
spot("splay", 4, "button", 100, 121, 20, 15, {110, 128})
spot("quitar", 4, "button", 160, 122, 16, 12, {168, 128})
spot("web", 4, "button", 184, 121, 28, 14, {198, 128})          -- EspaiSo (espaiso.lua)

function P.at(x, y)
  for id, s in pairs(P.SPOTS) do
    if x >= s.x - 1 and x < s.x + s.w + 1 and y >= s.y - 1 and y < s.y + s.h + 1 then return id end
  end
end

-- The d-pad over the columns there are (the sections and one more, to add one).
function P.move(id, dx, dy, ncols)
  local s = P.SPOTS[id]
  local function usable(o) local t = P.SPOTS[o]; return t.kind ~= "cell" or t.c <= ncols end
  if dx ~= 0 then
    local row, i0 = P.ROWS[s.row], 1
    for i, other in ipairs(row) do if other == id then i0 = i end end
    for k = 1, #row do
      local cand = row[(i0 - 1 + dx * k) % #row + 1]
      if usable(cand) then return cand end
    end
    return id
  end
  local r = (s.row - 1 + dy) % 4 + 1
  local best, bd = id, 1e9
  for _, other in ipairs(P.ROWS[r]) do
    local d = math.abs(P.SPOTS[other].tip[1] - s.tip[1])
    if usable(other) and d < bd then best, bd = other, d end
  end
  return best
end

local function body()
  local p = P.PANEL
  rect(p.x + 1, p.y, p.w - 2, p.h, C.bezel)
  rect(p.x, p.y + 1, p.w, p.h - 2, C.bezel)
  line(p.x + 1, p.y, p.x + p.w - 2, p.y, C.bezel_hi)
  line(p.x + p.w - 1, p.y + 1, p.x + p.w - 1, p.y + p.h - 2, C.bezel_lo)
  line(p.x + 1, p.y + p.h - 1, p.x + p.w - 2, p.y + p.h - 1, C.bezel_lo)
  rect(13, 19, 214, 100, C.bezel_lo)                         -- the screen's recess
  rect(14, 20, 212, 98, C.screen)
  text("FRUITERA 4", 18, 18, {font = "lcd", color = C.title})
  icon(ICON.ritmo, 24, P.ROW_Y[1] + 2, 0xE0452C)
  icon(ICON.linea, 24, P.ROW_Y[2] + 3, 0x9FE07A)
  icon(ICON.bars, 24, P.ROW_Y[3] + 3, C.cream)
  rect(LCD.x - 1, LCD.y - 1, LCD.w + 2, LCD.h + 2, C.grid)
  circ(222, 128, 2, C.bezel_lo)                              -- the monitor's power light
  local w = P.SPOTS.web                                      -- the web: a blue key with a globe
  rect(w.x, w.y, w.w, w.h, 0x1D3F8F)
  line(w.x, w.y, w.x + w.w - 1, w.y, 0x4A74D0)
  circ(w.x + 7, w.y + 7, 4, 0xC8D6F4)
  line(w.x + 3, w.y + 7, w.x + 11, w.y + 7, 0x1D3F8F)
  line(w.x + 7, w.y + 3, w.x + 7, w.y + 11, 0x1D3F8F)
  text("WEB", w.x + 13, w.y - 1, {font = "badge", color = 0xF2EBDD})
  for y = 21, 117, 2 do line(14, y, 225, y, 0x0B101E) end    -- scanlines
end

local last = {}
local CELL_ID = {}                                          -- made once: no new strings each frame
for r = 1, 3 do CELL_ID[r] = {} for c = 1, P.COLS do CELL_ID[r][c] = "c" .. r .. "_" .. c end end

function P.build()
  last = {}
  canvas("PANEL_P", "DESK")
  target("PANEL_P")
  body()
  target()
end

local function changed(key, sig)
  if last[key] == sig then return false end
  last[key] = sig
  return true
end

local BARS = {font = "lcd", color = 0xF2EBDD, align = "center"}
local function draw_cell(r, c, sec, n, here, progress)
  local x, y, w, h = P.COL_X + (c - 1) * P.COL_W, P.ROW_Y[r], P.COL_W - 2, ROW_H[r]
  rect(x - 1, y - 1, w + 2, h + 2, C.screen)
  if c > n + 1 then return end
  if c == n + 1 then                                          -- one more column: add a section
    if r == 1 then box(x, y, w, h, C.dim); text("+", x + 7, y + 3, {font = "badge", color = C.dim}) end
    return
  end
  if r == 3 then
    text(tostring(sec.bars), x + w // 2, y - 4, BARS)
    if here then rect(x, y + h - 1, math.floor(w * progress + 0.5), 1, C.head) end
    return
  end
  local p = r == 1 and sec.d or sec.b
  if p == 0 then
    rect(x, y, w, h, C.grid)
    text("-", x + 8, y + 3, {font = "badge", color = C.dim})
  else
    rect(x, y, w, h, P.PAT_COL[p])
    line(x, y, x + w - 1, y, 0xFFFFFF)
    text(P.LETTER[p], x + 7, y + 3, {font = "badge", color = C.ink})
  end
  if here then box(x - 1, y - 1, w + 2, h + 2, C.head) end
end

local function draw_switch(song)
  local sw = P.SPOTS.smodo
  rect(sw.x, sw.y, sw.w, sw.h, C.ink)
  rect(sw.x + (song and sw.w - 11 or 1), sw.y + 1, 10, sw.h - 2, C.cream)
end

local function draw_play(on)
  local play = P.SPOTS.splay
  rect(play.x, play.y, play.w, play.h, C.bezel)
  rect(play.x, play.y, play.w, play.h - 2, on and 0xFFD84A or C.yellow)
  rect(play.x, play.y + play.h - 2, play.w, 2, 0x8A6A14)
  if on then rect(play.x + 7, play.y + 4, 6, 6, C.ink)
  else tri(play.x + 7, play.y + 3, play.x + 7, play.y + 11, play.x + 13, play.y + 7, C.ink) end
end

local function draw_quitar()
  local q = P.SPOTS.quitar
  rect(q.x, q.y, q.w, q.h, 0x8A2416)
  line(q.x + 4, q.y + 3, q.x + 11, q.y + 8, C.cream)
  line(q.x + 11, q.y + 3, q.x + 4, q.y + 8, C.cream)
end

local function draw_lcd(str)
  rect(LCD.x, LCD.y, LCD.w, LCD.h, C.screen)
  text(str, LCD.x + 3, LCD.y - 3, {font = "lcd", color = C.title})
end

-- v = {sections, playing, song (mode), cur, progress, lcd}
function P.draw(v)
  target("PANEL_P")
  local n = #v.sections
  for c = 1, P.COLS do
    local sec = v.sections[c]
    local here = v.song and v.playing and v.cur == c
    for r = 1, 3 do
      local sig = sec and (sec.d * 64 + sec.b * 16 + sec.bars + (here and 1000 or 0) + (r == 3 and here and math.floor(v.progress * 8) * 10000 or 0)) or -1
      if changed(CELL_ID[r][c], sig * 10 + (c == n + 1 and 7 or 0)) then draw_cell(r, c, sec, n, here, v.progress) end
    end
  end
  if changed("modo", v.song) then draw_switch(v.song) end
  if changed("play", v.playing) then draw_play(v.playing) end
  if changed("quitar", true) then draw_quitar() end
  if changed("lcd", v.lcd) then draw_lcd(v.lcd) end
  target()
end

return P
