-- EspaiSo, the songs network of 2004 (a MySpace), on FRUITERA 4's computer: your profile with your songs and how
-- many times they have been heard (the counts go up while you play), "the top 8" with the faces of the people you
-- have met, and what they write to you as the story goes on. You can upload what is playing, with a name.
local E = {}

E.on = false
E.dirty = false
E.rev = 0                                               -- plays changed: the page is drawn again from them
local SONGS_MAX = 8
local PLAYS_EVERY = 300                                   -- ticks between two rounds of listeners

-- The friends, in the order they are met: who, their face, from which chapter (or a flag of the story).
local FRIENDS = {
  {"IAIA", "FACE_IAIA", 0}, {"KIKO", "FACE_KIKO", 1}, {"TONI", "FACE_TONI", 2}, {"MARTA", "FACE_MARTA", 2},
  {"NEREA", "FACE_NEREA", 3}, {"FARO", "FACE_FARO", 3}, {"BRILLO", "FACE_BRILLO", "batalla"}, {"LUNA", "FACE_LUNA", 5},
}
-- What they write, newest last; each from a chapter (or a story flag).
local COMMENTS = {
  {1, "IAIA", "MOLT BE NEN. PERO BAIXA EL VOLUM QUE ELS VEINS JA HAN TRUCAT"},
  {1, "KIKO", "TETEEE la base a 90 es un temazo. PD: soy el de la gorra"},
  {2, "TONI", "Gracias por la sintonía. Los oyentes preguntan quién eres."},
  {2, "PONS", "El pasodoble arrasó en las fiestas. La orquesta te debe una."},
  {3, "NEREA", "OLÉÉÉ. ¿Cuándo grabamos otra? Traigo las palmas."},
  {3, "MARTA", "Buen bajo. Ciérrale más el filtro."},
  {3, "ROBER", "¡Ahora se nos oye el bajo! Pásate por el EspaiSo de Los Grillos."},
  {4, "FARO", "Menos es más. Este comentario también."},
  {"batalla", "BRILLO", "Revancha cuando quieras. Mi sampler sigue sonando mejor."},
  {5, "LUNA", "lo escucho a oscuras. gracias."},
  {6, "VIDAL", "Tu abuela y yo... Gracias. De verdad."},
}

local function open_to(when)
  if type(when) == "string" then return historia.flags[when] == true or (historia.ch or 6) >= 6 end  -- (free: all of it)
  return (historia.ch or 6) >= when
end

-- The songs: the story's, as they are named, then what you uploaded.
local function story_songs()
  local v = dlg.vars() or {}
  local list = {}
  if open_to(2) or historia.flags.espaiso_subido then
    list[#list + 1] = {id = "story:1", name = v.tema_1 or "LA PLAZA", rate = 3}
  end
  if open_to(3) then list[#list + 1] = {id = "story:2", name = "PALMAS", rate = 4} end
  if open_to(4) then list[#list + 1] = {id = "story:3", name = v.tu_single or "CIRERA", rate = 7} end
  if open_to(6) then list[#list + 1] = {id = "story:4", name = "MAQUETA", rate = 9} end
  return list
end

-- The same list until something it is made of changes (asked every frame: no new tables for nothing).
local cached, c_ch, c_n, c_last, c_t1, c_ts, c_sub
function E.songs()
  local v = dlg.vars() or {}
  local last = E.mine[#E.mine]
  if cached and c_ch == historia.ch and c_n == #E.mine and c_last == last and c_t1 == v.tema_1 and
     c_ts == v.tu_single and c_sub == historia.flags.espaiso_subido then
    return cached
  end
  local list = story_songs()
  for _, s in ipairs(E.mine) do list[#list + 1] = {id = s.id, name = s.name, rate = 2, mine = true} end
  cached, c_ch, c_n, c_last, c_t1, c_ts, c_sub = list, historia.ch, #E.mine, last, v.tema_1, v.tu_single,
    historia.flags.espaiso_subido
  return list
end

local function plays(s) return E.plays[s.id] or E.plays[s.name] or 0 end -- old saves used song names

function E.minimum_plays(id, count)
  if type(id) ~= "string" or type(count) ~= "number" or count ~= count or count < 0 then return end
  local current = E.plays[id] or 0
  if current < count then E.plays[id], E.dirty, E.rev = math.floor(count), true, E.rev + 1 end
end

function E.comments()
  local out = {}
  for _, c in ipairs(COMMENTS) do if open_to(c[1]) then out[#out + 1] = c end end
  return out
end

-- ===== kept =====

local told, next_id = -1, 0
function E.load()
  local t = stored("espaiso")
  E.plays, E.mine, E.seen = {}, {}, 0
  E.dirty = false
  told, next_id = -1, 0
  if type(t) ~= "table" then return end
  if type(t.plays) == "table" then
    for k, n in pairs(t.plays) do if type(k) == "string" and type(n) == "number" then E.plays[k] = math.floor(n) end end
  end
  if type(t.mine) == "table" then
    for _, s in ipairs(t.mine) do
      if #E.mine >= SONGS_MAX then break end
      if type(s) == "table" and type(s.name) == "string" and type(s.id) == "number" and s.id > 0 then
        local id = math.floor(s.id)
        E.mine[#E.mine + 1] = {name = s.name, id = "mine:" .. id}
        next_id = math.max(next_id, id)
      elseif type(s) == "string" then
        next_id = next_id + 1
        E.mine[#E.mine + 1] = {name = s, id = "mine:" .. next_id}
      end
    end
  end
  if type(t.seen) == "number" then E.seen = math.floor(t.seen) end
end

function E.save()
  local mine = {}
  for _, s in ipairs(E.mine) do
    mine[#mine + 1] = {name = s.name, id = tonumber(s.id:match("^mine:(%d+)$"))}
  end
  store("espaiso", {plays = E.plays, mine = mine, seen = E.seen})
  E.dirty = false
end

-- ===== while you play =====

-- Every few seconds some listeners come; news of comments not yet read show in the room once.
function E.tick(toast)
  if ticks() % PLAYS_EVERY ~= 0 then return end
  for _, s in ipairs(E.songs()) do
    local increment = math.random(0, s.rate)
    if increment > 0 then E.plays[s.id] = plays(s) + increment; E.dirty, E.rev = true, E.rev + 1 end
  end
  local fresh = #E.comments() - E.seen
  if fresh > 0 and fresh ~= told and station == "sala" and not dlg.on and not cine.s then
    toast(fresh == 1 and "ESPAISO: UN COMENTARIO NUEVO" or ("ESPAISO: " .. fresh .. " COMENTARIOS NUEVOS"), 180)
    told = fresh
  end
end

-- ===== the page =====

local sel, t, comment_skip = 1, 0, 0
function E.open()
  E.on, sel, t, comment_skip = true, 1, 0, 0
  foley("press")
end

function E.song_window()
  return math.max(1, math.min(sel - 7, #E.songs() - 7))
end

function E.comment_offset() return comment_skip end

local function close()
  E.on = false
  E.seen = #E.comments()
  E.save()
end

local function upload()
  historia.ask("¿CÓMO SE LLAMA LO QUE SUBES?", "MAQUETA " .. (#E.mine + 1), function(name)
    if #E.mine >= SONGS_MAX then table.remove(E.mine, 1) end
    next_id = next_id + 1
    E.mine[#E.mine + 1] = {name = name, id = "mine:" .. next_id}
    E.plays["mine:" .. next_id] = 0
    E.dirty = true
    E.save()
  end)
end

function E.update()
  t = t + 1
  if t % 20 == 0 then                                     -- the counters are alive while you look
    local list = E.songs()
    local s = list[math.random(math.max(1, #list))]
    if s and math.random() < 0.6 then E.plays[s.id] = plays(s) + 1; E.dirty, E.rev = true, E.rev + 1 end
  end
  if t < 6 then return end
  local n = #E.songs() + 1                                -- the songs, then the upload button
  if btnp("up", 12, 4) then sel = (sel - 2) % n + 1; foley("blip") end
  if btnp("down", 12, 4) then sel = sel % n + 1; foley("blip") end
  if btnp("left", 12, 4) then comment_skip = math.min(comment_skip + 1, math.max(0, #E.comments() - 1)); foley("blip") end
  if btnp("right", 12, 4) then comment_skip = math.max(0, comment_skip - 1); foley("blip") end
  local tx, ty, _, tapped = touch()
  if tapped and tx and tx * 2 >= 14 and tx * 2 < 232 and ty * 2 >= 278 and ty * 2 < 302 then sel = n; upload() return end
  if btnp("a") and sel == n then upload() return end
  if btnp("b") or btnp("menu") then close() end
end

-- ===== drawing =====

local C = {back = 0xE6EAF2, head = 0x1D3F8F, head2 = 0x2F5BB8, box = 0xFFFFFF, line = 0xB8C4DC, ink = 0x1A1A2A,
           dim = 0x5A6478, orange = 0xF26A1B, sel = 0xFFE8A8}
local LOGO = {font = "hint", color = 0xFFFFFF, scale = 2}
local TAG = {font = "lcd", color = 0xC8D6F4}
local H2 = {font = "lcd", color = C.orange}
local INK = {font = "lcd", color = C.ink}
local DIM = {font = "lcd", color = C.dim}
local DIM_R = {font = "lcd", color = C.dim, align = "right"}
local NAME = {font = "hint", color = C.ink}
local FRIEND = {font = "lcd", color = C.head, align = "center"}
local BTN = {font = "lcd", color = 0xFFFFFF, align = "center"}
local WHO = {font = "lcd", color = C.head}
local CLOSE = {font = "lcd", color = 0xC8D6F4, align = "right"}

local function wrap(str, w)                               -- words into lines of the lcd font no wider than w
  local lines, cur = {}, ""
  for word in str:gmatch("%S+") do
    local try = cur == "" and word or (cur .. " " .. word)
    if textw(try, "lcd") > w and cur ~= "" then lines[#lines + 1] = cur; cur = word else cur = try end
  end
  if cur ~= "" then lines[#lines + 1] = cur end
  return lines
end

local function thousands(n)
  local s = tostring(n)
  return s:reverse():gsub("(%d%d%d)", "%1."):reverse():gsub("^%.", "")
end

-- The page's words and numbers, worked out only when something on it changed (the frame just draws them).
local wrapped = {}                                       -- a comment's lines, once
local view, view_sig
local function build_view()
  local v = {rows = {}, friends = {}, blocks = {}}
  local vars = dlg.vars() or {}
  v.name = vars.nombre or "ÀLEX"
  local list = E.songs()
  v.n = #list
  local first = E.song_window()
  v.range = #list > 8 and (first .. "-" .. math.min(first + 7, #list) .. "/" .. #list) or nil
  for i = first, math.min(first + 7, #list) do
    local s = list[i]
    v.rows[#v.rows + 1] = {sel = sel == i, label = (s.mine and "+ " or "> ") .. s.name, count = thousands(plays(s))}
  end
  v.upload_sel = sel == #list + 1
  for k, f in ipairs(FRIENDS) do v.friends[k] = open_to(f[3]) end
  local all = E.comments()
  v.ncom = #all
  v.cpos = #all > 0 and ((#all - comment_skip) .. "/" .. #all) or nil
  local y = 214
  for i = #all - comment_skip, 1, -1 do                    -- the newest, as many as fit whole
    local c = all[i]
    wrapped[c[3]] = wrapped[c[3]] or wrap(c[3], 210)
    local lines = wrapped[c[3]]
    if y + 14 + #lines * 14 > 308 then break end
    v.blocks[#v.blocks + 1] = {y = y, who = c[2] .. ":", lines = lines}
    y = y + 16 + #lines * 14
  end
  v.tag_x = 22 + textw("EspaiSo", "hint") * 2
  return v
end

function E.draw()
  if not E.on then return end
  local sig = sel * 1000003 + comment_skip * 1009 + E.rev
  if sig ~= view_sig or not view then view, view_sig = build_view(), sig end
  local v = view
  rect(0, 0, 480, 320, C.back)
  rect(0, 0, 480, 34, C.head)
  text("EspaiSo", 10, 2, LOGO)
  text("un lugar para tu música", v.tag_x, 10, TAG)
  -- the profile and the songs
  rect(8, 40, 228, 272, C.box)
  box(8, 40, 228, 272, C.line)
  text(v.name, 16, 44, NAME)
  text("Productor · Cirera de Mar", 16, 66, DIM)
  text("Mis canciones", 16, 88, H2)
  if v.range then text(v.range, 228, 88, DIM_R) end
  for i, r in ipairs(v.rows) do
    local y = 106 + (i - 1) * 21
    if r.sel then rect(12, y - 2, 220, 20, C.sel) end
    text(r.label, 16, y, INK)
    text(r.count, 228, y, DIM_R)
  end
  if v.n == 0 then text("Aún no has subido nada.", 16, 106, DIM) end
  rect(14, 278, 218, 24, v.upload_sel and C.orange or C.head2)
  text("SUBIR LO QUE SUENA", 123, 280, BTN)
  -- the top 8 and what they write
  rect(244, 40, 228, 272, C.box)
  box(244, 40, 228, 272, C.line)
  text("Los 8 de arriba", 252, 44, H2)
  for k, f in ipairs(FRIENDS) do
    local x, y = 254 + ((k - 1) % 4) * 54, 64 + ((k - 1) // 4) * 66
    if v.friends[k] then
      img(f[2], x, y)
      text(f[1], x + 24, y + 48, FRIEND)
    else
      rect(x, y, 48, 48, C.back)
      text("?", x + 24, y + 14, FRIEND)
    end
  end
  text("Comentarios  < >", 252, 196, H2)
  if v.cpos then text(v.cpos, 464, 196, DIM_R) end
  for _, b in ipairs(v.blocks) do
    text(b.who, 252, b.y, WHO)
    for k, l in ipairs(b.lines) do text(l, 252, b.y + k * 14, INK) end
  end
  if v.ncom == 0 then text("Nadie te ha escrito todavía.", 252, 214, DIM) end
  text("B: CERRAR", 470, 18, CLOSE)
end

E.plays, E.mine, E.seen = {}, {}, 0                     -- (E.load() in _init)
return E
