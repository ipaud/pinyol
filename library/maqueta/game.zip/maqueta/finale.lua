-- The last night: the concert in the square and the credits. In the concert your song plays whole, from its first
-- section, and you produce it live: A sends up fireworks, B and C are claps and the cowbell for the square, up and
-- down sweep Línea 3's filter, the microphone hears the people clap; the crowd jumps on every beat and the LED
-- marks the bar. When the song is over the band plays the eight notes and the bridge, hers and yours.
-- Then the credits: Polaroids of the journey and your songs by their names.
local cine = require("cine")
local hands = require("hands")
local F = {}

F.on, F.creditos = false, false
local fx
local bars, last_step, energy, phase, t, bounce = 0, -1, 0, "song", 0, 0
local total

function F.init(particles) fx = particles end
function finale_energy() return energy end            -- (tests)

local SPARKS_MAX = 180                              -- each spark is Lua and a circle: a cap keeps the tick light
local function burst(x, y, big)
  local cols = ({{0xFFE070, 0xFFFFFF}, {0xFF5040, 0xFFB0A0}, {0x60FF80, 0xD0FFD0}, {0x80B0FF, 0xFFFFFF}})[math.random(4)]
  if fx:count() < SPARKS_MAX then
    fx:burst(x, y, big and 40 or 26, {colours = cols, speed = big and 5 or 4, life = 52, size = 3, gravity = 0.05})
    fx:burst(x, y, 8, {colours = {0xFFFFFF, 0xFFF4C0}, speed = 1.5, life = 24, size = 4})   -- the bright heart of it
  end
  cine.flash(2)                                     -- the square lights up for a moment
  tone(1, 80, {wave = "noise", vol = 0.16 * seq.volume, decay = 0.4})
end

function F.start()
  F.on, phase, t, bars, last_step, energy, bounce = true, "song", 0, 0, -1, 0.5, 0
  cine.show("concierto")
  hands.hidden = true
  song.mode = "cancion"
  song.start()
  if not seq.playing then seq.start() end
  total = math.max(8, math.min(32, song.length_bars()))
end

local function the_bridge()                         -- the band: the eight notes, her half, your half
  local notes = {}
  for _, m in ipairs(cine.MOTIF) do notes[#notes + 1] = m end
  local SCALE = linea.SCALE
  for _, d in ipairs(respuesta.BRIDGE) do notes[#notes + 1] = SCALE[d] + 24 end
  for _, d in ipairs(historia.flags.puente or respuesta.BRIDGE) do notes[#notes + 1] = SCALE[math.min(#SCALE, d)] + 24 end
  cine.hum(notes, "square", 16)
end

function F.update()
  t = t + 1
  if phase == "song" then
    local s = seq.step
    if s ~= last_step then
      if s == 0 and last_step ~= -1 then bars = bars + 1 end
      if s % 4 == 0 then bounce = 5 end
      last_step = s
    end
    if btnp("a") then burst(math.random(60, 420), math.random(30, 130)); energy = math.min(1, energy + 0.08) end
    if btnp("b") then seq.hit(3, true); energy = math.min(1, energy + 0.04) end
    if btnp("c") then seq.hit(8, true); energy = math.min(1, energy + 0.04) end
    if btn("up") then linea.patch.cutoff = math.min(0.95, linea.patch.cutoff + 0.01) end
    if btn("down") then linea.patch.cutoff = math.max(0.05, linea.patch.cutoff - 0.01) end
    local tx, ty, down = touch()
    if down and t % 6 == 0 then burst(tx * 2, ty * 2); energy = math.min(1, energy + 0.03) end
    local level, _, hit, _, kind = mic()
    if hit then burst(math.random(60, 420), math.random(40, 140)); energy = math.min(1, energy + 0.06); led(0xFFFF00) end
    if kind == "voice" and level > 0.55 then           -- the square shouts with you: it lights up and jumps
      energy = math.min(1, energy + 0.012)
      bounce = 5
      if t % 10 == 0 then burst(math.random(60, 420), math.random(30, 120)) end
    elseif kind == "whistle" and t % 14 == 0 then      -- a whistle sends a rocket up the middle
      burst(math.random(200, 280), math.random(20, 60), true)
    end
    energy = math.max(0.08, energy - 0.0008)          -- the square cools down slowly, never quite out
    if t % math.max(8, math.floor(60 - energy * 50)) == 0 then burst(math.random(40, 440), math.random(20, 120)) end
    if bars >= total or (dlg.auto and t > 240) then
      phase, t = "bridge", 0
      seq.stop()
      the_bridge()
    end
  elseif phase == "bridge" then
    if t % 10 == 0 then burst(math.random(40, 440), math.random(20, 140), true) end
    if t % 16 == 0 then bounce = 5 end
    if not cine.humming() and t > 30 then phase, t = "end", 0 end
  elseif t > 90 then
    led()
    F.on = false
    song.mode = "patron"
  end
  if bounce > 0 then bounce = bounce - 1 end
  for y = 112, 159 do line_scroll(2, y, 0, (bounce > 2 and 2 or 0) * ((y // 8) % 2 == 0 and 1 or 0)) end
end

local TOP = {font = "hint", color = 0xFFE9B0, align = "center", shadow = 0x000000}
local HELP = {font = "lcd", color = 0xE9D8B0, align = "center", shadow = 0x000000}
local ENERGY = {font = "lcd", color = 0xF2EBDD, shadow = 0x000000}

function F.draw()
  if phase == "song" then
    local sec = song.cur or 1
    text(string.format("EN DIRECTO · SECCIÓN %d/%d", sec, #song.sections), 240, 4, TOP)
    rect(96, 30, 288, 16, 0x120E16)                  -- the square's energy
    box(96, 30, 288, 16, 0x8A7A60)
    rect(98, 32, math.floor(284 * energy), 12, energy > 0.7 and 0xFF5040 or 0xE9B632)
    text("LA PLAZA", 102, 28, ENERGY)
    text(t // 240 % 2 == 0 and "A FUEGOS   B C PALMAS   CRUCETA FILTRO" or "¡GRITA, SILBA Y DA PALMAS AL MICRO!",
         240, 292, HELP)
  elseif phase == "bridge" then
    text("EL PUENTE", 240, 4, TOP)
  end
end

-- ===== the credits =====

local PHOTOS = {"CINE_CIRERA", "CINE_PLAZA", "CINE_1983", "CINE_COCINA", "CINE_AZOTEA", "CINE_PLAZA"}
local lines, ct

local function credits_text()
  local v = dlg.vars()
  local n = v.nombre or "Àlex"
  return {
    {"MAQUETA", "title"}, {""}, {"Un juego de Pau Avila"}, {"hecho con pinyol para la Cirera"}, {""}, {""},
    {"LAS CANCIONES DE " .. n:upper(), "head"}, {""},
    {"«" .. (v.tema_1 or "La plaza") .. "»"}, {"sintonía de Ràdio Cirera", "dim"}, {""},
    {"«Palmas»"}, {"con Nerea", "dim"}, {""},
    {"«" .. (v.tu_single or "Cirera") .. "»"}, {"Discos Tinta", "dim"}, {""},
    {"«Maqueta»"}, {"Les Cireres y " .. n, "dim"}, {""},
    {"Puente (2.ª mitad): " .. n, "head"}, {""}, {""},
    {"REPARTO", "head"}, {""},
    {"Iaia Remei"}, {"Kiko «K-Fuet»"}, {"Marta Tinta"}, {"Nerea"}, {"Brillo"}, {"Sr. Faro"}, {"Vidal"}, {"Luna"},
    {"Toni Ona, Ràdio Cirera"}, {""}, {""},
    {"Gracias por escuchar.", "head"},
  }
end

function F.start_creditos()
  F.creditos, ct = true, 0
  lines = credits_text()
  cine.show("negro")
  hands.hidden = true
  song.mode = "cancion"
  song.start()
  if not seq.playing then seq.start() end
end

function F.update_creditos()
  ct = ct + 1
  local done = ct > #lines * 26 + 420 or (ct > 120 and btnp("start")) or (dlg.auto and ct > 60)
  if done then
    F.creditos = false
    if seq.playing then seq.stop() end
    song.mode = "patron"
  end
end

local STYLE = {
  title = {font = "brand", scale = 3, color = 0xFFE9B0, gradient = 0xE8742A, align = "center", shadow = 0x000000},
  head = {font = "lcd", color = 0xE9B632, align = "center", shadow = 0x5A3A10},
  dim = {font = "lcd", color = 0x8A8AA0, align = "center"},
  normal = {font = "lcd", color = 0xF2EBDD, align = "center"},
}

function F.draw_creditos()
  local k = ct // 240 % #PHOTOS + 1                  -- a Polaroid of the journey, slowly turning
  local bob = math.floor(math.sin(ct / 50) * 3)
  rect(22, 66 + bob, 200, 170, 0xF2EBDD)
  img(PHOTOS[k], 30, 74 + bob, {scale = 0.766})
  local y0 = 320 - ct * 0.6
  for i, l in ipairs(lines) do
    local y = y0 + (i - 1) * 26
    if y > -40 and y < 330 then text(l[1], 352, math.floor(y), STYLE[l[2] or "normal"]) end
  end
end

return F
