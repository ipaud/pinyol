-- The rack: the studio's echo and reverb, how much of Ritmo 88 and of Línea 3 goes to each, and Lo-fi GBA.
-- The drums send as one group, each instrument by its own weight, as a mix usually has it: the kick dry, the snare
-- and the claps wet. Needs the firmware's studio; without it the rack is there but silent.
local seq = require("seq")
local linea = require("linea")
local R = {}
R.panel = require("rack_panel")

local DELAY_STEPS = {1, 1.5, 2, 3, 4, 6, 8}
local DELAY_NAME = {"1/16", "1/16.", "1/8", "1/8.", "1/4", "1/4.", "1/2"}
-- how much each Ritmo 88 instrument takes of the group's sends (BOMBO, CAJA, PALMAS, CHARLES, ABIERTO, TOM, ARO, CENCERRO)
local WEIGHT = {0, 1, 1, 0.5, 0.7, 0.8, 1, 0.6}
local BASS = 9

R.focus = "tiempo"

function R.reset()
  R.fx = {delay_i = 4, feedback = 0.4, tone = 0.4, gba = false, gate = false, size = 0.55, bright = 0.6, lofi = false}
  R.send = {ritmo_d = 0.15, ritmo_r = 0.3, bajo_d = 0.3, bajo_r = 0.1}
  R.sent = {}
end

local function clamp(v, lo, hi) return math.max(lo, math.min(hi, v)) end
local function pct(v) return math.floor(v * 100 + 0.5) end

-- The studio told only what changed: numbers compared every tick, calls only on a change.
function R.sync()
  if not seq.engine then return end
  local f, s, sent = R.fx, R.send, R.sent
  if sent.delay_i ~= f.delay_i or sent.feedback ~= f.feedback or sent.tone ~= f.tone or sent.gba ~= f.gba or
     sent.gate ~= f.gate or
     sent.size ~= f.size or sent.bright ~= f.bright or sent.lofi ~= f.lofi then
    studio.fx({delay = DELAY_STEPS[f.delay_i], feedback = f.feedback, tone = f.tone, reverb = f.gba and "gba" or "plate",
               gate = f.gate, size = f.size, damp = 1 - f.bright, lofi = f.lofi})
    sent.delay_i, sent.feedback, sent.tone, sent.gba, sent.gate, sent.size, sent.bright, sent.lofi =
      f.delay_i, f.feedback, f.tone, f.gba, f.gate, f.size, f.bright, f.lofi
  end
  if sent.ritmo_d ~= s.ritmo_d or sent.ritmo_r ~= s.ritmo_r then
    for i = 1, 8 do studio.track(i, {delay = s.ritmo_d * WEIGHT[i], reverb = s.ritmo_r * WEIGHT[i]}) end
    sent.ritmo_d, sent.ritmo_r = s.ritmo_d, s.ritmo_r
  end
  if sent.bajo_d ~= s.bajo_d or sent.bajo_r ~= s.bajo_r then
    linea.sync()                                   -- its track is a synth track before it gets sends
    studio.synth(BASS, {delay = s.bajo_d, reverb = s.bajo_r})
    sent.bajo_d, sent.bajo_r = s.bajo_d, s.bajo_r
  end
end

local function send_knob(key, label)
  return {get = function() return R.send[key] end,
          turn = function(d) R.send[key] = clamp(R.send[key] + d * 0.05, 0, 1) end,
          lcd = function() return label .. " " .. pct(R.send[key]) end}
end

R.KNOBS = {
  tiempo = {get = function() return (R.fx.delay_i - 1) / (#DELAY_STEPS - 1) end,
            turn = function(d) R.fx.delay_i = clamp(R.fx.delay_i + d, 1, #DELAY_STEPS) end,
            lcd = function() return "ECO " .. DELAY_NAME[R.fx.delay_i] end},
  repet = {get = function() return R.fx.feedback / 0.9 end,
           turn = function(d) R.fx.feedback = clamp(R.fx.feedback + d * 0.05, 0, 0.9) end,
           lcd = function() return "REPETICIONES " .. pct(R.fx.feedback / 0.9) end},
  etono = {get = function() return R.fx.tone end,
           turn = function(d) R.fx.tone = clamp(R.fx.tone + d * 0.05, 0, 1) end,
           lcd = function() return "TONO DEL ECO " .. pct(R.fx.tone) end},
  tamano = {get = function() return R.fx.size end,
            turn = function(d) R.fx.size = clamp(R.fx.size + d * 0.05, 0, 1) end,
            lcd = function() return "TAMAÑO " .. pct(R.fx.size) end},
  brillo = {get = function() return R.fx.bright end,
            turn = function(d) R.fx.bright = clamp(R.fx.bright + d * 0.05, 0, 1) end,
            lcd = function() return "BRILLO " .. pct(R.fx.bright) end},
  eco_ritmo = send_knob("ritmo_d", "ECO RITMO"),
  eco_bajo = send_knob("bajo_d", "ECO BAJO"),
  rev_ritmo = send_knob("ritmo_r", "REVERB RITMO"),
  rev_bajo = send_knob("bajo_r", "REVERB BAJO"),
}

function R.aim(hands)
  local s = R.panel.SPOTS[R.focus]
  hands.point(s.tip[1], s.tip[2], s.kind == "knob" and "pinch" or "point")
end

function R.press(id, ctx)
  ctx.hands.press()
  if id == "modo_rev" then
    R.fx.gba = not R.fx.gba
    if R.fx.gba then R.fx.gate = false end
    ctx.touched()
  elseif id == "talkback" then
    R.fx.gate = not R.fx.gate
    if R.fx.gate then R.fx.gba = false end
    ctx.toast(R.fx.gate and "TALKBACK INVERSO: PLACA GATED" or "TALKBACK APAGADO")
    ctx.touched()
  elseif id == "lofi" then
    R.fx.lofi = not R.fx.lofi
    ctx.toast(R.fx.lofi and "LO-FI GBA: 13 KHZ, 8 BITS" or "LO-FI APAGADO")
    ctx.touched()
  elseif id == "rplay" then ctx.toggle_play() end
end

function R.turn(k, d, ctx)
  local before = k.get()
  k.turn(d)
  if k.get() ~= before then ctx.hands.twist(); ctx.touched() end
end

function R.input(ctx)
  local s = R.panel.SPOTS[R.focus]
  if btn("a") and s.kind == "knob" then
    local d = ((btnp("right", 10, 3) or btnp("up", 10, 3)) and 1 or 0) - ((btnp("left", 10, 3) or btnp("down", 10, 3)) and 1 or 0)
    if d ~= 0 then R.turn(R.KNOBS[R.focus], d, ctx) end
  else
    local dx = (btnp("right", 12, 4) and 1 or 0) - (btnp("left", 12, 4) and 1 or 0)
    local dy = (btnp("down", 12, 4) and 1 or 0) - (btnp("up", 12, 4) and 1 or 0)
    if dx ~= 0 or dy ~= 0 then
      R.focus = R.panel.move(R.focus, dx, dx == 0 and dy or 0)
      R.aim(ctx.hands)
    end
  end
  if btnp("a") and s.kind ~= "knob" then R.press(R.focus, ctx) end
end

function R.lcd()
  if not seq.engine then return "NECESITA FIRMWARE" end
  local k = R.KNOBS[R.focus]
  if k then return k.lcd() end
  if R.focus == "modo_rev" then return R.fx.gba and "REVERB GBA" or "REVERB PLACA" end
  if R.focus == "talkback" then return R.fx.gate and "PLACA GATED" or "TALKBACK: NO" end
  if R.focus == "lofi" then return R.fx.lofi and "LO-FI GBA: SÍ" or "LO-FI GBA: NO" end
  return seq.playing and "STOP" or string.format("PLAY  %d BPM", seq.bpm())
end

function R.hint()
  local kind = R.panel.SPOTS[R.focus].kind
  if kind == "knob" then return (ticks() // 180) % 2 == 0 and "MANTÉN A Y MUEVE LA CRUCETA" or "MENU: VUELVE A LA SALA" end
  return "A PULSAR   MENU: VUELVE A LA SALA"
end

local view = {knobs = {}}
function R.view(lcd_text)
  for id, k in pairs(R.KNOBS) do view.knobs[id] = k.get() end
  view.gba, view.gate, view.lofi, view.playing, view.lcd = R.fx.gba, R.fx.gate, R.fx.lofi, seq.playing, lcd_text
  return view
end

function R.save()
  local f, s = R.fx, R.send
  store("rack", {delay_i = f.delay_i, feedback = f.feedback, tone = f.tone, gba = f.gba, gate = f.gate, size = f.size,
                 bright = f.bright, lofi = f.lofi, ritmo_d = s.ritmo_d, ritmo_r = s.ritmo_r, bajo_d = s.bajo_d,
                 bajo_r = s.bajo_r})
end

local function num(v, lo, hi, d)
  if type(v) ~= "number" or v ~= v then return d end
  return clamp(v, lo, hi)
end

function R.load()
  R.reset()
  local t = stored("rack")
  if type(t) ~= "table" then return end
  local f, s = R.fx, R.send
  f.delay_i = math.floor(num(t.delay_i, 1, #DELAY_STEPS, f.delay_i))
  f.feedback, f.tone = num(t.feedback, 0, 0.9, f.feedback), num(t.tone, 0, 1, f.tone)
  f.gba, f.gate, f.lofi = t.gba == true, t.gate == true, t.lofi == true
  if f.gba then f.gate = false end
  f.size, f.bright = num(t.size, 0, 1, f.size), num(t.bright, 0, 1, f.bright)
  for _, k in ipairs({"ritmo_d", "ritmo_r", "bajo_d", "bajo_r"}) do s[k] = num(t[k], 0, 1, s[k]) end
end

R.reset()
return R
