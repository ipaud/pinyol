-- Ritmo 88 drawn by code, pixel by pixel, on a 240x160 canvas shown as a background layer: the desk
-- (art/desk.png), the panel, its keys, knobs, lights and icons, and its LCD, which names what the hand holds.
-- Nothing is written small: icons instead of labels, and the LCD in a big pixel font, as a GBA game would.
local seq = require("seq")
local P = {}

local C = {
  panel = 0x26232a, face = 0x1f1c23, hi = 0x4a4652, side = 0x34303a, lo = 0x121014,
  rule = 0x3e3a46, cream = 0xF2EBDD, orange = 0xE8742A, red = 0xE0452C, yellow = 0xE9B632, bone = 0xE9E1CF,
  led_off = 0x3a1010, led_on = 0xFF3A1E, led_acc = 0xFFC040, led_head = 0xFFF4E0, led_dim = 0x6a5a54,
  skirt = 0x0e0c10, shadow = 0x0a080c, ink = 0x1a1418, lcd = 0x8FAE3E, lcd_ink = 0x1F3A10, lcd_edge = 0x34401a,
  sel = 0x2e2a35, icon = 0xC9C0B0,
}
P.C = C
local GROUP = {C.red, C.orange, C.yellow, C.bone}            -- step keys in fours, as on an 808
local GROUP_HI = {0xF27A5E, 0xF6A060, 0xF5D27A, 0xFFF8EC}
local GROUP_LO = {0x8A2416, 0x93431A, 0x93701A, 0x9A9282}

P.PANEL = {x = 6, y = 14, w = 228, h = 124}
P.TILE_Y, P.KEY_Y = 67, 99
local KNOB_Y = 52
local LCD = {x = 93, y = 17, w = 110, h = 12}
P.LCD = LCD                                          -- (tests/textos.script: every LCD text fits)

-- Icons as pictures written in characters: # outline, c the thing's colour, h a drum's head, w white,
-- i its inside, s motion lines; dots are see-through. 11x11 for the instruments, 9x7 for the knobs.
local ICON = {
  BOMBO = {"...#####...", "..#ccccc#..", ".#chhhhhc#.", "#chhhhhhhc#", "#chhhcchhc#", "#chhccc#hc#",
           "#chhhcchhc#", "#chhhhhhhc#", ".#chhhhhc#.", "..#ccccc#..", ".#.#####.#."},
  CAJA = {"w.........w", ".w.......w.", "..w.....w..", "...w...w...", "..#######..", ".#hhhhhhh#.",
          "#ccccccccc#", "#c#c#c#c#c#", "#c#c#c#c#c#", "#ccccccccc#", ".#########."},
  PALMAS = {"s..#...#..s", ".s#c#.#c#s.", "..#c#.#c#..", ".#cc#.#cc#.", ".#ccc#ccc#.", ".#ccc#ccc#.",
            ".#ccc#ccc#.", "..#cc#cc#..", "..#cc#cc#..", "...#c#c#...", "....#.#...."},
  CHARLES = {"...........", ".....#.....", "..#######..", ".#ccccccc#.", "#ccccccccc#", ".#ccccccc#.",
             "..#######..", ".....#.....", ".....#.....", "....#.#....", "...#...#..."},
  ABIERTO = {"s....#....s", "..#######..", ".#ccccccc#.", "..#######..", "s....#....s", ".....#.....",
             "..#######..", ".#ccccccc#.", "..#######..", ".....#.....", "....#.#...."},
  TOM = {"...........", "..#######..", ".#hhhhhhh#.", "#hhhhhhhhh#", "#ccccccccc#", "#c#ccccc#c#",
         "#ccccccccc#", "#c#ccccc#c#", "#ccccccccc#", ".#########.", "..#.....#.."},
  ARO = {".........ww", "........ww.", "..######w..", ".#hhhhhwh#.", "#hhhhhwhhh#", "#hhhhwhhhh#",
         "#ccccwcccc#", ".#cwccccc#.", "..w######..", ".w.........", "w.........."},
  CENCERRO = {"....###....", "....#.#....", "...#ccc#...", "...#cwc#...", "..#ccwcc#..", "..#ccwcc#..",
              ".#ccccccc#.", ".#ccccccc#.", "#ccccccccc#", "#iiiiiiiii#", ".#########."},
  tempo = {"....#....", "...#.#...", "...#.##..", "..#..#.#.", "..#.#..#.", ".#..#...#", "#########"},
  swing = {"..#....#.", "..##...##", "..#.#..#.", "..#....#.", "###..###.", "###..###.", "........."},
  tono = {"..#...##.", ".###..#.#", "#.#.#.#..", "..#...#..", "..#.###..", "..#.###..", "........."},
  nivel = {"........#", "......#.#", "......#.#", "....#.#.#", "..#.#.#.#", "#.#.#.#.#", "#.#.#.#.#"},
  caida = {"#........", "##.......", "#.#......", "#..#.....", "#...##...", "#.....###", "#########"},
  dens = {"#..#..#..", "#..#..#..", ".........", "#.#.#.#.#", "#.#.#.#.#", ".........", "........."},
  rotar = {"..####...", ".#....#..", "#......#.", "#.....###", "#......#.", ".#.......", "..####..."},
}

local function icon(rows, x, y, colour, head)
  local map = {["#"] = C.ink, c = colour, h = head or C.cream, w = 0xFFFFFF, i = 0x3a2a1a, s = C.icon}
  for r, row in ipairs(rows) do
    for k = 1, #row do
      local ch = row:sub(k, k)
      if ch ~= "." then pset(x + k - 1, y + r - 1, map[ch]) end
    end
  end
end

local function knob_icon(rows, x, y)                         -- knob icons in one colour, light on the panel
  for r, row in ipairs(rows) do
    for k = 1, #row do
      if row:sub(k, k) == "#" then pset(x + k - 1, y + r - 1, C.icon) end
    end
  end
end

-- Every control: a box to touch, the point the hand goes to, its row for the d-pad.
P.SPOTS, P.ROWS = {}, {{}, {}, {}}
local function spot(id, row, kind, x, y, w, h, tip, extra)
  local s = {id = id, row = row, kind = kind, x = x, y = y, w = w, h = h, tip = tip}
  for k, v in pairs(extra or {}) do s[k] = v end
  P.SPOTS[id] = s
  table.insert(P.ROWS[row], id)
end
local function knob(id, name, cx, r, cap)
  spot(id, 1, "knob", cx - r - 1, KNOB_Y - r - 10, 2 * r + 3, 2 * r + 12, {cx, KNOB_Y - 3},
       {cx = cx, cy = KNOB_Y, r = r, cap = cap, name = name})
end
knob("tempo", "TEMPO", 25, 10, 0x3a3640)
knob("swing", "SWING", 54, 8, 0xD8D0C0)
knob("tono", "TONO", 82, 8, 0xD8D0C0)
knob("nivel", "NIVEL", 105, 8, C.orange)
knob("caida", "CAÍDA", 128, 8, 0xD8D0C0)
knob("dens", "DENSIDAD", 154, 8, C.yellow)
knob("rotar", "ROTAR", 177, 8, C.yellow)
spot("play", 1, "button", 192, 36, 20, 24, {202, 46}, {name = "PLAY"})
spot("mic", 1, "button", 217, 34, 14, 13, {224, 40}, {name = "MIC"})
spot("modo", 1, "switch", 214, 53, 19, 8, {223, 56}, {name = "MODO"})
spot("pat", 1, "button", 206, 16, 24, 13, {218, 22}, {name = "PATRÓN"})
for i = 1, 8 do
  local x = 9 + (i - 1) * 28
  spot("inst" .. i, 2, "inst", x, P.TILE_Y, 26, 24, {x + 13, P.TILE_Y + 12}, {inst = i})
end
for s = 0, 15 do
  local x = 9 + s * 14
  spot("step" .. s, 3, "step", x, P.KEY_Y, 12, 20, {x + 6, P.KEY_Y + 7}, {step = s})
end

function P.at(x, y)
  for id, s in pairs(P.SPOTS) do
    if x >= s.x - 1 and x < s.x + s.w + 1 and y >= s.y - 1 and y < s.y + s.h + 1 then return id end
  end
end

-- The d-pad: along a row, or to the nearest control in the row above or below.
function P.move(id, dx, dy)
  local s = P.SPOTS[id]
  if dx ~= 0 then
    local row = P.ROWS[s.row]
    for i, other in ipairs(row) do
      if other == id then return row[(i - 1 + dx) % #row + 1] end
    end
  end
  local r = (s.row - 1 + dy) % 3 + 1
  local best, bd = id, 1e9
  for _, other in ipairs(P.ROWS[r]) do
    local d = math.abs(P.SPOTS[other].tip[1] - s.tip[1])
    if d < bd then best, bd = other, d end
  end
  return best
end

local function clamp(v, lo, hi) return math.max(lo, math.min(hi, v)) end

local function body()
  local p = P.PANEL
  rect(p.x + 1, p.y, p.w - 2, p.h, C.panel)
  rect(p.x, p.y + 1, p.w, p.h - 2, C.panel)
  line(p.x + 1, p.y, p.x + p.w - 2, p.y, C.hi)
  line(p.x, p.y + 1, p.x, p.y + p.h - 2, C.side)
  line(p.x + p.w - 1, p.y + 1, p.x + p.w - 1, p.y + p.h - 2, C.lo)
  line(p.x + 1, p.y + p.h - 1, p.x + p.w - 2, p.y + p.h - 1, C.lo)
  rect(p.x + 3, p.y + 2, p.w - 6, 14, C.face)                  -- the header
  text("RITMO 88", 13, 19, {font = "brand", color = C.cream})
  line(p.x + 4, p.y + 17, p.x + p.w - 5, p.y + 17, C.orange)
  box(66, 33, 123, 31, C.rule)                                 -- the selected instrument's knobs
  rect(7, P.TILE_Y - 2, 226, 28, C.face)
  for g = 0, 3 do rect(9 + g * 56, P.KEY_Y + 23, 54, 2, GROUP[g + 1]) end
  rect(LCD.x - 1, LCD.y - 1, LCD.w + 2, LCD.h + 2, C.lcd_edge)
  for _, id in ipairs(P.ROWS[1]) do
    local s = P.SPOTS[id]
    if s.kind == "knob" then
      for k = 0, 10 do                                         -- the scale printed round each knob
        local a = math.rad(-135 + 27 * k)
        pset(math.floor(s.cx + math.sin(a) * (s.r + 2) + 0.5), math.floor(s.cy - math.cos(a) * (s.r + 2) + 0.5), C.rule)
      end
      knob_icon(ICON[id], s.cx - 4, 35)
    end
  end
end

-- What each control looked like when last drawn: a frame redraws only what changed (writing the canvas
-- costs about 1 ms per 10,000 pixels on the console; most frames only a step's light moves).
local last = {}

function P.build()
  last = {}
  canvas("PANEL", "DESK")
  target("PANEL")
  body()
  target()
end

local function changed(key, sig)
  if last[key] == sig then return false end
  last[key] = sig
  return true
end

local function draw_knob(s, v)
  circ(s.cx, s.cy, s.r + 1, C.panel)
  circ(s.cx + 1, s.cy + 1, s.r, C.shadow)
  circ(s.cx, s.cy, s.r, C.skirt)
  circ(s.cx, s.cy, s.r - 2, s.cap)
  pset(s.cx - s.r // 2, s.cy - s.r // 2, 0xFFFFFF)            -- a glint from the lamp
  local a = math.rad(-135 + 270 * clamp(v, 0, 1))
  local ink = s.cap == 0x3a3640 and C.cream or C.ink
  line(s.cx, s.cy, math.floor(s.cx + math.sin(a) * (s.r - 1) + 0.5), math.floor(s.cy - math.cos(a) * (s.r - 1) + 0.5), ink)
end

local function draw_key(s, val, head, pressed)
  local x, y = 9 + s * 14, P.KEY_Y
  local g = s // 4 + 1
  rect(x - 1, y - 4, 14, 26, C.panel)
  local led = val == 2 and C.led_acc or (val == 1 and C.led_on or C.led_off)
  if head then led = val > 0 and C.led_head or C.led_dim end
  rect(x + 4, y - 3, 4, 2, led)
  local dy = pressed and 1 or 0
  rect(x, y + dy, 12, 20 - dy, GROUP[g])
  line(x, y + dy, x + 11, y + dy, GROUP_HI[g])
  line(x, y + dy, x, y + 19, GROUP_HI[g])
  if not pressed then rect(x + 1, y + 18, 11, 2, GROUP_LO[g]) end
  line(x + 1, y + 20, x + 12, y + 20, C.shadow)
end

local function draw_tile_led(i, lit)
  local s = P.SPOTS["inst" .. i]
  rect(s.x + 21, s.y + 2, 3, 2, lit and C.led_on or C.led_off)
end

local function draw_tile(i, selected, lit, pad)
  local s = P.SPOTS["inst" .. i]
  local inst = seq.INSTS[i]
  rect(s.x, s.y, s.w, s.h, selected and C.sel or C.face)
  box(s.x, s.y, s.w, s.h, selected and C.cream or C.side)
  rect(s.x + 2, s.y + 2, 16, 2, inst.col)
  rect(s.x + 21, s.y + 2, 3, 2, lit and C.led_on or C.led_off)
  icon(ICON[inst.id], s.x + (pad and 13 or 8), s.y + 6, inst.col)
  local steps = seq.tracks[i].steps
  for k = 0, 15 do pset(s.x + 5 + k, s.y + 20, steps[k + 1] > 0 and inst.col or C.rule) end
  if pad then                                                  -- DIRECTO: the button that plays it, beside its icon
    rect(s.x + 2, s.y + 6, 8, 10, C.yellow)
    text(pad, s.x + 3, s.y + 6, {font = "badge", color = C.ink})
  end
end

local function draw_play(on)
  local play = P.SPOTS.play                                    -- the start/stop key
  rect(play.x, play.y, play.w, play.h, C.panel)
  rect(play.x, play.y, play.w, play.h - 2, on and 0xFFD84A or C.yellow)
  line(play.x, play.y, play.x + play.w - 1, play.y, 0xFFE9A0)
  rect(play.x, play.y + play.h - 2, play.w, 2, 0x8A6A14)
  if on then rect(play.x + 7, play.y + 7, 6, 6, C.ink)
  else tri(play.x + 7, play.y + 6, play.x + 7, play.y + 14, play.x + 13, play.y + 10, C.ink) end
end

local function draw_mic(lit)
  local mic = P.SPOTS.mic
  local cx, cy = mic.x + 7, mic.y + 6
  circ(cx, cy, 6, C.skirt)
  circ(cx, cy, 5, lit and C.led_on or 0x7a1a12)
  rect(cx - 1, cy - 3, 3, 4, 0xFFFFFF)                         -- a little microphone on the button
  pset(cx - 2, cy, 0xFFFFFF)
  pset(cx + 2, cy, 0xFFFFFF)
  line(cx - 1, cy + 2, cx + 1, cy + 2, 0xFFFFFF)
  pset(cx, cy + 3, 0xFFFFFF)
end

local function draw_switch(mode)
  local sw = P.SPOTS.modo
  rect(sw.x, sw.y, sw.w, sw.h, C.lo)
  rect(sw.x + (mode == "pasos" and 1 or 10), sw.y + 1, 8, sw.h - 2, C.cream)
end

local function draw_lcd(str)
  rect(LCD.x, LCD.y, LCD.w, LCD.h, C.lcd)
  text(str, LCD.x + 3, LCD.y - 4, {font = "lcd", color = C.lcd_ink})
end

local KEY_ID, TILE_ID, LED_ID = {}, {}, {}                            -- made once: no new strings each frame
for k = 0, 15 do KEY_ID[k] = "k" .. k end
for i = 1, 8 do TILE_ID[i], LED_ID[i] = "t" .. i, "l" .. i end

local PAT_COL = {0xE0452C, 0xE8742A, 0xE9B632, 0xE9E1CF}  -- A B C D
local function draw_pat(s, p)                                -- the pattern in hand: its letter in its colour
  rect(s.x, s.y, s.w, s.h, 0x121014)
  rect(s.x + 1, s.y + 1, s.w - 2, s.h - 2, p > 0 and PAT_COL[p] or 0x3a3640)
  text(p > 0 and ({"A", "B", "C", "D"})[p] or "-", s.x + 8, s.y + 2, {font = "badge", color = 0x1a1418})
end

local function mask(steps)
  local m = 0
  for k = 1, 16 do if steps[k] > 0 then m = m + (1 << (k - 1)) end end
  return m
end

-- Everything that moves, drawn on the canvas when it changes: v = {knobs = {id = 0..1}, sel, pressed, ...}
function P.draw(v)
  target("PANEL")
  for id, val in pairs(v.knobs) do
    if changed(id, val) then draw_knob(P.SPOTS[id], val) end
  end
  local steps = seq.tracks[v.sel].steps
  for s = 0, 15 do
    local head = seq.playing and seq.step == s
    local press = v.pressed[s] ~= nil
    if changed(KEY_ID[s], steps[s + 1] * 4 + (head and 2 or 0) + (press and 1 or 0)) then
      draw_key(s, steps[s + 1], head, press)
    end
  end
  for i = 1, 8 do
    local lit = seq.flash[i] ~= nil
    local pad = v.pads and v.pads[i]
    local sig = mask(seq.tracks[i].steps) + (i == v.sel and 65536 or 0) + (pad and 262144 or 0)
    if changed(TILE_ID[i], sig) then draw_tile(i, i == v.sel, lit, pad); last[LED_ID[i]] = lit
    elseif changed(LED_ID[i], lit) then draw_tile_led(i, lit) end   -- a hit lights only its LED: no whole tile again
  end
  if changed("play", seq.playing) then draw_play(seq.playing) end
  if changed("mic", v.mic_lit) then draw_mic(v.mic_lit) end
  if changed("modo", v.mode) then draw_switch(v.mode) end
  if changed("lcd", v.lcd) then draw_lcd(v.lcd) end
  if changed("pat", v.pat) then draw_pat(P.SPOTS.pat, v.pat) end
  target()
end

return P
