-- Ràdio Cirera: short broadcasts between chapters. Compose is pure so a cue can be tested separately.
local R = {on = nil}

local function title(value, fallback)
  if type(value) ~= "string" then return fallback end
  local clean = value:gsub("^%s+", ""):gsub("%s+$", "")
  return clean ~= "" and clean or fallback
end

function R.compose(id, s)
  s = s or {}
  if id == "desvan" then
    return {
      tema = (s.palmas or 0) >= 4 and "Suena un ritmo nuevo, con palmas de Cirera." or
        "Suena un ritmo nuevo, grabado en Cirera.",
      noticia = "Desde un desván llegan cuatro golpes y unas palmas.",
    }
  elseif id == "ciudad" then
    return {
      tema = "Volvemos a poner «" .. title(s.tema, "La plaza") .. "».",
      noticia = (s.tempo or 0) >= 110 and "La verbena pide otra vuelta, y más rápida." or
        "La verbena sigue bailando. Hasta los del estanco.",
    }
  elseif id == "faro" then
    return {
      tema = "En antena, «Palmas», desde el Soterrani.",
      noticia = s.sample and "Hay una voz metida en el sampler. Es del pueblo." or
        (s.mute and "Ahora se oye el bajo de Los Grillos. Ya era hora." or
         "Los Grillos han encontrado sitio para su bajo."),
    }
  elseif id == "granvia" then
    local sections = tonumber(s.sections) or 0
    return {
      tema = "Esta noche, «" .. title(s.single, "Cirera") .. "».",
      noticia = sections >= 5 and "Cinco partes, y las ocho notas que nadie olvidó." or
        "Las ocho notas de una vieja cinta cruzan la ciudad.",
    }
  elseif id == "casa" then
    return {
      tema = "La versión del apagón suena en Ràdio Cirera.",
      noticia = (s.directo or 0) >= 16 and
        "Dieciséis golpes a mano. Hasta la luz quiso escuchar." or
        (s.batalla and "De La Nave al estudio: la música no se apaga." or
         "Sin luz y sin ordenador, el ritmo siguió vivo."),
    }
  end
  return {}
end

function R.capture()
  local h = historia
  local vars = dlg and dlg.vars and dlg.vars() or {}
  local sample = false
  if golpe and golpe.pads then
    for _, pad in ipairs(golpe.pads) do if pad.rec then sample = true; break end end
  end
  local mute = false
  if mesa and mesa.mute then
    for _, value in ipairs(mesa.mute) do if value then mute = true; break end end
  end
  return {
    palmas = seq and seq.tracks and seq.count(seq.tracks[3].steps) or 0,
    tempo = seq and seq.tempo or 0,
    tema = vars.tema_1,
    single = vars.tu_single,
    sections = song and song.sections and #song.sections or 0,
    sample = sample,
    mute = mute,
    directo = h and h.flags and h.flags.directo or 0,
    batalla = h and h.flags and h.flags.batalla or false,
  }
end

function R.start(id, signals)
  local cue = R.compose(id, signals or R.capture())
  if not cue.tema then error("radio: unknown cue " .. tostring(id)) end
  R.on = {id = id, tema = cue.tema, noticia = cue.noticia, t = 0,
          duration = dlg and dlg.auto and 8 or 260}
end

function R.finish()
  if R.on then tone(1) end
  R.on = nil
end

function R.update()
  local cue = R.on
  if not cue then return end
  cue.t = cue.t + 1
  if cue.t == 1 then tone(1, 523, {wave = "triangle", vol = 0.15, decay = 0.2}) end
  if cue.t == 11 then tone(1, 659, {wave = "triangle", vol = 0.15, decay = 0.2}) end
  if cue.t == 21 then tone(1, 784, {wave = "triangle", vol = 0.15, decay = 0.4}) end
  if cue.t >= cue.duration or (cue.t > 30 and (btnp("a") or btnp("start"))) then R.finish() end
end

local GOLD = {font = "hint", color = 0xF3CB70, align = "center"}
local WHITE = {font = "lcd", color = 0xF5EAD8, align = "center"}
local DIM = {font = "hint", color = 0xBDADA5, align = "center"}

function R.draw()
  local cue = R.on
  if not cue then return end
  rect(0, 0, 480, 320, 0x170F1D)
  rect(24, 31, 432, 258, 0x5A3743)
  box(24, 31, 432, 258, 0xF3CB70)
  rect(40, 46, 400, 226, 0x2B2231)
  rect(53, 58, 374, 57, 0x130D16)
  box(53, 58, 374, 57, 0xB78556)
  text("RÀDIO CIRERA", 240, 65, GOLD)
  text("102.4 FM  ·  EN DIRECTO", 240, 90, DIM)
  for i = 0, 15 do
    local h = 8 + ((i * 7 + cue.t // 4 * 3) % 24)
    rect(95 + i * 18, 153 - h, 9, h, i % 3 == 0 and 0xF3CB70 or 0xCF765F)
  end
  text(cue.tema, 240, 172, WHITE)
  text(cue.noticia, 240, 211, WHITE)
  if cue.t > 35 and cue.t % 40 < 28 then text("A / START: CONTINUAR", 240, 254, DIM) end
end

return R
