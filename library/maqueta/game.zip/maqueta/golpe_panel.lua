-- Golpe 60, the sampler (an MPC3000 or an SP-1200 seen from above), drawn by code on its own 240x160 canvas: a
-- graphite box, a blue LCD, four rubber pads that light up when they sound, two knobs for the pad in hand, REC in red,
-- and the pad's sixteen steps. Same rules as panel.lua: icons, no small words, only what changed is drawn again.
local P = {}

local C = {
  body = 0x34373E, body_hi = 0x50545C, body_lo = 0x1C1E22, band = 0x26282D, ink = 0x111214, cream = 0xF2EBDD,
  knob = 0x18191C, mark = 0xEDEDE8, icon = 0x9A9EA8, pad = 0x8E8C88, pad_hi = 0xB2B0AA, pad_lo = 0x5C5A57,
  pad_lit = 0xFFF2C0, sel = 0xE9B632, rec = 0xD83A2A, rec_lo = 0x7A1A12, led_off = 0x3a1010, led_on = 0xFF3A1E,
  lcd = 0x2F5F96, lcd_ink = 0xE6F0FF, lcd_edge = 0x183052, yellow = 0xE9B632, key = 0x5A5D66, key_hi = 0x7A7E88,
  key_on = 0xE8742A, key_on_hi = 0xFFA060, head = 0xFFF4E0, shadow = 0x0a080c,
}
P.C = C
P.PANEL = {x = 6, y = 14, w = 228, h = 124}
local LCD = {x = 100, y = 17, w = 104, h = 12}
P.LCD = LCD                                          -- (tests/textos.script: every LCD text fits)
P.KEY_Y = 118
P.PAD = {{x = 128, y = 34}, {x = 178, y = 34}, {x = 128, y = 75}, {x = 178, y = 75}}
local PAD_W, PAD_H = 44, 36
P.PAD_KEY = {"A", "B", "C", "^"}

P.SPOTS, P.ROWS = {}, {{}, {}, {}}
local function spot(id, row, kind, x, y, w, h, tip, extra)
  local s = {id = id, row = row, kind = kind, x = x, y = y, w = w, h = h, tip = tip}
  for k, v in pairs(extra or {}) do s[k] = v end
  P.SPOTS[id] = s
  table.insert(P.ROWS[row], id)
end
spot("gtono", 1, "knob", 17, 34, 19, 28, {26, 49}, {cx = 26, cy = 52, r = 8})
spot("gnivel", 1, "knob", 49, 34, 19, 28, {58, 49}, {cx = 58, cy = 52, r = 8})
spot("gplay", 1, "button", 84, 40, 24, 20, {96, 50})
spot("pad1", 1, "pad", 128, 34, PAD_W, PAD_H, {150, 52}, {pad = 1})
spot("pad2", 1, "pad", 178, 34, PAD_W, PAD_H, {200, 52}, {pad = 2})
spot("rec", 2, "button", 14, 78, 30, 20, {29, 88})
spot("gmodo", 2, "switch", 56, 84, 22, 9, {67, 88})
spot("pad3", 2, "pad", 128, 75, PAD_W, PAD_H, {150, 93}, {pad = 3})
spot("pad4", 2, "pad", 178, 75, PAD_W, PAD_H, {200, 93}, {pad = 4})
for s = 0, 15 do
  local x = 9 + s * 14
  spot("gstep" .. s, 3, "step", x, P.KEY_Y, 12, 16, {x + 6, P.KEY_Y + 7}, {step = s})
end

function P.at(x, y)
  for id, s in pairs(P.SPOTS) do
    if x >= s.x - 1 and x < s.x + s.w + 1 and y >= s.y - 1 and y < s.y + s.h + 1 then return id end
  end
end

function P.move(id, dx, dy)
  local s = P.SPOTS[id]
  if dx ~= 0 then
    local row = P.ROWS[s.row]
    for i, other in ipairs(row) do
      if other == id then return row[(i - 1 + dx) % #row + 1] end
    end
  end
  local r = (s.row - 1 + dy) % 3 + 1
  local best, bd = id, 1e9
  for _, other in ipairs(P.ROWS[r]) do
    local d = math.abs(P.SPOTS[other].tip[1] - s.tip[1])
    if d < bd then best, bd = other, d end
  end
  return best
end

local ICON = {
  tono = {"..#...##.", ".###..#.#", "#.#.#.#..", "..#...#..", "..#.###..", "..#.###..", "........."},
  nivel = {"........#", "......#.#", "....#.#.#", "..#.#.#.#", "#.#.#.#.#", "#.#.#.#.#", "........."},
}
local function icon(rows, x, y, colour)
  for r, row in ipairs(rows) do
    for k = 1, #row do
      if row:sub(k, k) == "#" then pset(x + k - 1, y + r - 1, colour) end
    end
  end
end

local function body()
  local p = P.PANEL
  rect(p.x + 1, p.y, p.w - 2, p.h, C.body)
  rect(p.x, p.y + 1, p.w, p.h - 2, C.body)
  line(p.x + 1, p.y, p.x + p.w - 2, p.y, C.body_hi)
  line(p.x, p.y + 1, p.x, p.y + p.h - 2, C.body_hi)
  line(p.x + p.w - 1, p.y + 1, p.x + p.w - 1, p.y + p.h - 2, C.body_lo)
  line(p.x + 1, p.y + p.h - 1, p.x + p.w - 2, p.y + p.h - 1, C.body_lo)
  rect(p.x + 3, p.y + 2, p.w - 6, 14, C.band)
  text("GOLPE 60", 13, 19, {font = "brand", color = C.cream})
  rect(LCD.x - 1, LCD.y - 1, LCD.w + 2, LCD.h + 2, C.lcd_edge)
  rect(122, 31, 104, 83, C.body_lo)                          -- the pads' well
  for _, id in ipairs({"gtono", "gnivel"}) do
    local s = P.SPOTS[id]
    for k = 0, 10 do
      local a = math.rad(-135 + 27 * k)
      pset(math.floor(s.cx + math.sin(a) * (s.r + 2) + 0.5), math.floor(s.cy - math.cos(a) * (s.r + 2) + 0.5), C.body_hi)
    end
  end
  icon(ICON.tono, 22, 35, C.icon)
  icon(ICON.nivel, 54, 35, C.icon)
  rect(8, P.KEY_Y - 3, 224, 1, C.body_lo)
end

local last = {}

function P.build()
  last = {}
  canvas("PANEL_G", "DESK")
  target("PANEL_G")
  body()
  target()
end

local function changed(key, sig)
  if last[key] == sig then return false end
  last[key] = sig
  return true
end

local function draw_knob(s, v)
  circ(s.cx, s.cy, s.r + 1, C.body)
  circ(s.cx + 1, s.cy + 1, s.r, C.body_lo)
  circ(s.cx, s.cy, s.r, C.knob)
  circ(s.cx, s.cy, s.r - 3, 0x2a2a2d)
  local a = math.rad(-135 + 270 * math.max(0, math.min(1, v)))
  line(s.cx, s.cy, math.floor(s.cx + math.sin(a) * (s.r - 1) + 0.5), math.floor(s.cy - math.cos(a) * (s.r - 1) + 0.5), C.mark)
end

local BADGE = {font = "badge", color = C.ink}
local function draw_pad(i, lit, selected, recorded)
  local p = P.PAD[i]
  local x, y = p.x, p.y
  rect(x - 1, y - 1, PAD_W + 2, PAD_H + 2, selected and C.sel or C.body_lo)
  rect(x, y, PAD_W, PAD_H, lit and C.pad_lit or C.pad)
  line(x, y, x + PAD_W - 1, y, lit and 0xFFFFFF or C.pad_hi)
  line(x, y, x, y + PAD_H - 1, lit and 0xFFFFFF or C.pad_hi)
  rect(x + 1, y + PAD_H - 3, PAD_W - 1, 3, C.pad_lo)
  for k = 0, 2 do line(x + 8, y + 12 + k * 6, x + PAD_W - 9, y + 12 + k * 6, lit and 0xE8D8A0 or 0x86847F) end  -- the rubber's grip
  text(P.PAD_KEY[i], x + 3, y + 1, BADGE)
  rect(x + PAD_W - 7, y + 3, 4, 3, recorded and C.led_on or C.led_off)
end

local function draw_rec(state)
  local s = P.SPOTS.rec
  rect(s.x, s.y, s.w, s.h, C.body_lo)
  local on = state == "rec" or (state == "armed" and ticks() % 20 < 10)
  rect(s.x + 1, s.y + 1, s.w - 2, s.h - 3, on and 0xFF5A40 or C.rec)
  rect(s.x + 1, s.y + s.h - 2, s.w - 2, 2, C.rec_lo)
  circ(s.x + s.w // 2, s.y + 8, 4, on and 0xFFF0E0 or 0x6A1A12)
end

local function draw_play(on)
  local s = P.SPOTS.gplay
  rect(s.x, s.y, s.w, s.h, C.body)
  rect(s.x, s.y, s.w, s.h - 2, on and 0xFFD84A or C.yellow)
  rect(s.x, s.y + s.h - 2, s.w, 2, 0x8A6A14)
  if on then rect(s.x + 9, s.y + 6, 6, 6, C.ink)
  else tri(s.x + 9, s.y + 5, s.x + 9, s.y + 13, s.x + 15, s.y + 9, C.ink) end
end

local function draw_switch(directo)
  local s = P.SPOTS.gmodo
  rect(s.x, s.y, s.w, s.h, C.ink)
  rect(s.x + (directo and s.w - 11 or 1), s.y + 1, 10, s.h - 2, C.cream)
end

local function draw_key(st, on, head)
  local x, y = 9 + st * 14, P.KEY_Y
  rect(x - 1, y - 1, 14, 18, C.body)
  local c = on and C.key_on or C.key
  if head then c = on and C.head or C.key_hi end
  rect(x, y, 12, 14, c)
  line(x, y, x + 11, y, on and C.key_on_hi or C.key_hi)
  rect(x + 1, y + 14, 11, 2, C.body_lo)
end

local function draw_lcd(str)
  rect(LCD.x, LCD.y, LCD.w, LCD.h, C.lcd)
  text(str, LCD.x + 3, LCD.y - 4, {font = "lcd", color = C.lcd_ink})
end

local KEY_ID, PAD_ID = {}, {}
for k = 0, 15 do KEY_ID[k] = "k" .. k end
for i = 1, 4 do PAD_ID[i] = "p" .. i end

-- v = {pads (steps, level, tune, rec), sel, lit (pad -> ticks), playing, step, rec_state, directo, lcd}
function P.draw(v)
  target("PANEL_G")
  local pd = v.pads[v.sel]
  if changed("tono", pd.tune) then draw_knob(P.SPOTS.gtono, (pd.tune + 12) / 24) end
  if changed("nivel", pd.level) then draw_knob(P.SPOTS.gnivel, pd.level / 10) end
  for i = 1, 4 do
    local lit = (v.lit[i] or 0) > 0
    if changed(PAD_ID[i], (lit and 1 or 0) + (i == v.sel and 2 or 0) + (v.pads[i].rec and 4 or 0)) then
      draw_pad(i, lit, i == v.sel, v.pads[i].rec)
    end
  end
  local steps = pd.steps
  for st = 0, 15 do
    local head = v.playing and v.step == st
    if changed(KEY_ID[st], (steps[st + 1] > 0 and 1 or 0) + (head and 2 or 0) + v.sel * 4) then
      draw_key(st, steps[st + 1] > 0, head)
    end
  end
  local rs = v.rec_state or "-"
  if changed("rec", rs == "armed" and (rs .. (ticks() // 10 % 2)) or rs) then draw_rec(v.rec_state) end
  if changed("play", v.playing) then draw_play(v.playing) end
  if changed("modo", v.directo) then draw_switch(v.directo) end
  if changed("lcd", v.lcd) then draw_lcd(v.lcd) end
  target()
end

return P
