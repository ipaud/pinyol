-- Learning each machine: the first time you sit at one, its mentor shows its controls one by one (the control framed,
-- a line at the foot of the screen, and the step done when you have really used it); and a manual for any control,
-- opened by touching the ? at the top right: what it does and how to play it, and the lesson again.
local G = {}

local function count(i) return seq.count(seq.tracks[i].steps) end
local function sig(t, f) local n = 0 for s = 1, 16 do n = n * 3 + f(t, s) end return n end
local function deg_sig() return sig(linea.deg, function(t, s) return t[s] % 3 end) + #table.concat(linea.deg, ",") end
local function flags(field) return sig(linea[field], function(t, s) return (t[s] and linea.deg[s] > 0) and 1 or 0 end) end
local function song_sig()
  local n = #song.sections * 1000
  for _, s in ipairs(song.sections) do n = n + s.d * 7 + s.b * 3 + s.bars end
  return n
end

-- Each step: the control it points at, what the mentor says, a snapshot when it starts, and when it is done.
G.LESSONS = {
  ritmo = {who = "Iaia", steps = {
    {spot = "step2", say = "Estos son los pasos: dieciséis, un compás. Pulsa A en uno para encenderlo.",
     snap = function() return count(sel) end, done = function(n) return count(sel) ~= n end},
    {spot = "play", say = "Ahora dale al PLAY: con START, o tocando el botón amarillo.",
     done = function() return seq.playing end},
    {spot = "inst3", say = "Arriba están los instrumentos. Ve a las PALMAS y pulsa A.",
     done = function() return sel == 3 end},
    {spot = "step4", say = "Pon palmas en un par de pasos. Suenan con el bombo.",
     snap = function() return count(3) end, done = function(n) return count(3) >= n + 2 end},
    {spot = "tempo", say = "El TEMPO es la velocidad. Mantén A sobre el mando y mueve la cruceta.",
     snap = function() return seq.tempo end, done = function(t) return seq.tempo ~= t end},
    {spot = "step0", say = "C hace una variante: el mismo ritmo, un poco cambiado. Pruébalo.",
     done = function() return seq.tracks[sel].vars ~= nil end},
    {say = "Ya sabes lo básico. MENU para levantarte. El ? de arriba es el manual de cada mando.", last = true},
  }},
  pantalla = {who = "Kiko", steps = {
    {spot = "c1_1", say = "Tete, cada columna es una parte de la canción. A cambia su ritmo: A, B, C, D o nada.",
     snap = song_sig, done = function(n) return song_sig() ~= n end},
    {spot = function() return "c1_" .. math.min(8, #song.sections + 1) end,
     say = "La columna del + añade una parte nueva. Pulsa A en ella.",
     snap = function() return #song.sections end, done = function(n) return #song.sections > n end},
    {spot = "c3_1", say = "Abajo, los compases que dura cada parte. A los cambia.",
     snap = song_sig, done = function(n) return song_sig() ~= n end},
    {spot = "smodo", say = "Este interruptor: en CANCIÓN suenan todas las partes seguidas.",
     done = function() return song.mode == "cancion" end},
    {spot = "splay", say = "Dale al PLAY y escucha tu canción entera.", done = function() return seq.playing end},
    {say = "C en un bloque te lleva a su aparato con ese patrón. El ? de arriba, el manual.", last = true},
  }},
  linea = {who = "Marta", steps = {
    {spot = "lstep1", say = "La Línea 3: un bajo. A en un paso pone o quita una nota.",
     snap = deg_sig, done = function(n) return deg_sig() ~= n end},
    {spot = "lstep2", say = "Mantén A en una nota y sube o baja con la cruceta: cambia de nota.",
     snap = function() return table.concat(linea.deg, ",") end,
     done = function(t) return table.concat(linea.deg, ",") ~= t end},
    {spot = "lstep4", say = "B pone acento: esa nota más fuerte, más chillona.",
     snap = function() return flags("acc") end, done = function(n) return flags("acc") ~= n end},
    {spot = "lstep5", say = "C es el slide: la nota resbala hasta la siguiente. El ácido es eso.",
     snap = function() return flags("slide") end, done = function(n) return flags("slide") ~= n end},
    {spot = "corte", say = "El CORTE abre o cierra el filtro. Mantén A y mueve la cruceta.",
     snap = function() return linea.patch.cutoff end, done = function(c) return linea.patch.cutoff ~= c end},
    {spot = "lplay", say = "PLAY. Y mientras suena, muévele el CORTE: así se toca un bajo así.",
     done = function() return seq.playing end},
    {say = "Ya está. El ? de arriba te explica cada mando.", last = true},
  }},
  rack = {who = "Faro", steps = {
    {spot = "tiempo", say = "El ECO repite lo que le llega. TIEMPO: cada cuánto vuelve.",
     snap = function() return rack.fx.delay_i end, done = function(d) return rack.fx.delay_i ~= d end},
    {spot = "eco_ritmo", say = "Este, cuánto eco lleva el ritmo. Poco suele ser mucho.",
     snap = function() return rack.send.ritmo_d end, done = function(v) return rack.send.ritmo_d ~= v end},
    {spot = "rev_ritmo", say = "La PLACA es una sala. Cuánta sala lleva el ritmo.",
     snap = function() return rack.send.ritmo_r end, done = function(v) return rack.send.ritmo_r ~= v end},
    {spot = "modo_rev", say = "Este interruptor cambia la placa por el eco corto de la GBA.",
     snap = function() return rack.fx.gba end, done = function(g) return rack.fx.gba ~= g end},
    {spot = "talkback", say = "El TALKBACK inverso corta la cola de la placa tras cada golpe. Púlsalo.",
     snap = function() return rack.fx.gate end, done = function(g) return rack.fx.gate ~= g end},
    {spot = "lofi", say = "Y el Lo-fi: todo como sonaba en la consola de los críos.",
     snap = function() return rack.fx.lofi end, done = function(l) return rack.fx.lofi ~= l end},
    {spot = "rplay", say = "PLAY, y escucha cómo cambia. Cierra los ojos si quieres.",
     done = function() return seq.playing end},
    {say = "Menos es más. El ? de arriba, si te pierdes.", last = true},
  }},
}
G.LESSONS.golpe = {who = "Marta", steps = {
  {spot = "pad1", say = "El Golpe 60. Cada pad guarda un sonido. Tócalo: A, o con el dedo.",
   snap = function() return golpe.played or 0 end, done = function(n) return (golpe.played or 0) > n end},
  {spot = "rec", say = "REC graba en el pad elegido. Púlsalo y haz un sonido al micro: tu voz, una palmada...",
   snap = function() return golpe.recorded or 0 end,
   done = function(n) return (golpe.recorded or 0) > n or not mic() end},
  {spot = "gstep4", say = "Ahora pon ese pad en un par de pasos, abajo.",
   snap = function() return seq.count(golpe.pads[golpe.sel].steps) end,
   done = function(n) return seq.count(golpe.pads[golpe.sel].steps) >= n + 2 end},
  {spot = "gtono", say = "TONO: más agudo, voz de ardilla; más grave, de gigante. Mantén A y mueve.",
   snap = function() return golpe.pads[golpe.sel].tune end, done = function(t) return golpe.pads[golpe.sel].tune ~= t end},
  {spot = "gplay", say = "PLAY, y escucha tu sonido en el ritmo.", done = function() return seq.playing end},
  {say = "Así hacía música media generación: con dos discos y un sampler. El ? es el manual.", last = true},
}}
G.LESSONS.mesa = {who = "Marta", steps = {
  {spot = "f1", say = "La Mesa 8: cada columna, un canal. Mantén A en el fader y sube o baja: su volumen.",
   snap = function() return mesa.fader[1] end, done = function(v) return mesa.fader[1] ~= v end},
  {spot = "m2", say = "La M es MUTE: calla el canal. Pulsa A en la de la caja. Otra vez A, y vuelve.",
   snap = function() return mesa.mute[2] end, done = function(m) return mesa.mute[2] ~= m end},
  {spot = "s1", say = "La S es SOLO: suena ese canal y nada más. Prueba con el bombo.",
   done = function() return mesa.solo[1] end},
  {spot = "s1", say = "Otra vez A, y vuelve todo. El solo es para escuchar una cosa sola.",
   done = function() return not mesa.soloing() end},
  {say = "Mezclar es que todo se oiga. Con START suena: mezcla mientras. El ? es el manual.", last = true},
}}
local function slots_sig() return table.concat(nube.slots, ",") end
G.LESSONS.nube = {who = "Iaia", steps = {
  {spot = "n1", say = "La meva Nube. Arriba, un acorde por compás. A en la casilla cambia el acorde.",
   snap = slots_sig, done = function(t) return slots_sig() ~= t end},
  {spot = "nstep4", say = "Abajo, los pasos: en cada uno encendido, el acorde vuelve a sonar. Enciende uno.",
   snap = function() return seq.count(nube.steps) end, done = function(n) return seq.count(nube.steps) ~= n end},
  {spot = "nbrillo", say = "El BRILLO: más oscuro, más claro. Mantén A y mueve la cruceta.",
   snap = function() return nube.patch.bright end, done = function(b) return nube.patch.bright ~= b end},
  {spot = "nplay", say = "Dale al PLAY. Cada compás, el acorde siguiente; después de cuatro, vuelta a empezar.",
   done = function() return seq.playing end},
  {spot = "nvoz", say = "Y el teclado es tuyo: toca con el dedo, o con C y los botones. Aquí eliges la voz.",
   snap = function() return nube.patch.voice end, done = function(v) return nube.patch.voice ~= v end},
  {spot = "nrec", say = "Dale a GRABAR y toca encima de los acordes: lo que toques se queda, paso a paso.",
   done = function() return nube.rec end},
  {say = "Los acordes son el suelo. Lo demás baila encima. El ? es el manual.", last = true},
}}
G.LESSONS.nogal = {who = "Iaia", steps = {
  {spot = "nglide", say = "El Nogal canta solo, una nota a la vez. El GLIDE es lo que tarda en deslizarse de una nota a otra.",
   snap = function() return nogal.patch.glide end, done = function(b) return nogal.patch.glide ~= b end},
  {spot = "nonda", say = "La ONDA: sierra, cuadrada o triángulo. A la cambia y la oyes.",
   snap = function() return nogal.patch.wave end, done = function(v) return nogal.patch.wave ~= v end},
  {spot = "nrec", say = "Dale a GRABAR y toca en las teclas. Si tocas una nota con otra aún apretada, se desliza.",
   done = function() return nogal.rec end},
  {say = "La rueda de tono y la de mod se arrastran con el dedo. El ? es el manual.", last = true},
}}
G.FACE = {Iaia = "FACE_IAIA", Kiko = "FACE_KIKO", Marta = "FACE_MARTA", Faro = "FACE_FARO"}
G.STATIONS = {"ritmo", "pantalla", "linea", "rack", "golpe", "mesa", "nube", "nogal"}

G.on = nil                                      -- the lesson in course: {station, i, snap, ok, t}
G.off = false                                   -- the bench and the tests: no lesson starts by itself

local function step_of(l) return G.LESSONS[l.station].steps[l.i] end

local rich = require("rich")

local function begin(l)
  local s = step_of(l)
  l.snap, l.ok, l.t = s.snap and s.snap() or nil, 0, 0
  l.words = rich.new(s.say, {font = "lcd", color = 0xF2EBDD, width = 360, speed = 1})   -- typed, as people talk
end

function G.start(station)
  if not G.LESSONS[station] then return end
  G.on = {station = station, i = 1}
  begin(G.on)
end

-- On arrival at a machine: its lesson the first time (in the story), or the one left halfway.
function G.arrive(station)
  if G.on and G.on.station == station then return end
  if G.off or not G.LESSONS[station] or stored("guia_" .. station) then return end
  if historia.ch == nil or historia.ch >= 6 then return end
  G.start(station)
end

function G.update(at)
  local l = G.on
  if not l or l.station ~= at then return end
  l.t = l.t + 1
  l.words:update()
  local s = step_of(l)
  if l.ok > 0 then                                -- "¡Eso es!" for a moment, then the next control
    l.ok = l.ok - 1
    if l.ok == 0 then
      l.i = l.i + 1
      if not G.LESSONS[l.station].steps[l.i] then
        store("guia_" .. l.station, true)
        G.on = nil
        return
      end
      begin(l)
    end
    return
  end
  if (s.last and l.t > 240) or (not s.last and l.t > 2 and s.done(l.snap)) then
    l.ok = s.last and 1 or 40
    if not s.last then foley("blip") end
  end
end

function G.skip()
  if G.on then store("guia_" .. G.on.station, true) end
  G.on = nil
end

-- ===== the manual =====

local R, L, K, P, S, M, N, O = "ritmo", "linea", "rack", "pantalla", "golpe", "mesa", "nube", "nogal"
G.TEXT = {
  [R] = {
    step = {"PASO", "Un golpe del instrumento elegido en ese momento del compás. A lo enciende o apaga, B le pone acento (más fuerte), C prueba una variante del ritmo."},
    inst = {"INSTRUMENTO", "Qué instrumento editas en los pasos y con los mandos. A lo elige y lo oyes; manteniendo B lo borras entero."},
    tempo = {"TEMPO", "La velocidad de la canción, en golpes por minuto. Mantén A sobre el mando y mueve la cruceta."},
    swing = {"SWING", "Retrasa un poco los pasos pares: el ritmo se balancea, como en el hip hop. Al 50 va recto."},
    tono = {"TONO", "Más agudo o más grave el instrumento elegido."},
    nivel = {"NIVEL", "El volumen del instrumento elegido."},
    caida = {"CAÍDA", "Lo que dura cada golpe del instrumento: corto, medio o largo."},
    dens = {"DENSIDAD", "Reparte golpes por el compás, lo más parejos posible: de 0 a 16. Un ritmo en un momento."},
    rotar = {"ROTAR", "Corre todos los golpes del instrumento un paso adelante o atrás."},
    play = {"PLAY", "Arranca y para la música. También con START, desde cualquier sitio."},
    mic = {"MICRO", "Graba el instrumento al micro: cuenta un compás y luego cada palmada cae en su paso."},
    modo = {"PASOS / DIRECTO", "En DIRECTO los botones son pads: tocas en vivo y, si suena, se graba. MENU vuelve a PASOS."},
    pat = {"PATRÓN", "Cuatro patrones: A, B, C y D. Uno nuevo empieza como copia del que tenías. En la FRUITERA los ordenas."},
  },
  [L] = {
    step = {"PASO", "A pone o quita una nota; mantén A y mueve arriba o abajo para cambiarla. B: acento. C: slide, resbala hasta la siguiente."},
    ltono = {"TONO", "Sube o baja todo el bajo, nota a nota."},
    corte = {"CORTE", "El filtro: cerrado suena oscuro y redondo, abierto chilla. Muévelo mientras suena."},
    reso = {"RESONANCIA", "El pico del filtro: alto, ese silbido ácido."},
    env = {"ENVOLVENTE", "Cuánto se abre el filtro en cada nota: el golpe del bajo."},
    lcaida = {"CAÍDA", "Lo que tarda el filtro en cerrarse después de cada nota."},
    acento = {"ACENTO", "Lo fuerte y brillante que suenan las notas con acento."},
    onda = {"ONDA", "Sierra o cuadrada: dos voces distintas del bajo."},
    lplay = {"PLAY", "Arranca y para la música. También con START."},
    lmodo = {"PASOS / DIRECTO", "En DIRECTO los botones son notas: A, B y C la base, la cruceta las demás."},
    lpat = {"PATRÓN", "Cuatro patrones de bajo: A, B, C y D."},
  },
  [K] = {
    tiempo = {"TIEMPO DEL ECO", "Cada cuánto vuelve el eco, al compás: de una semicorchea a dos negras."},
    repet = {"REPETICIONES", "Cuántas veces vuelve el eco antes de apagarse."},
    etono = {"TONO DEL ECO", "Cada repetición más oscura o más brillante, como una cinta gastada."},
    eco_ritmo = {"ECO AL RITMO", "Cuánto del ritmo va al eco."},
    eco_bajo = {"ECO AL BAJO", "Cuánto del bajo va al eco."},
    tamano = {"TAMAÑO", "Lo grande que es la sala de la placa."},
    brillo = {"BRILLO", "La placa más apagada o más brillante."},
    rev_ritmo = {"PLACA AL RITMO", "Cuánta sala lleva el ritmo."},
    rev_bajo = {"PLACA AL BAJO", "Cuánta sala lleva el bajo."},
    modo_rev = {"PLACA / GBA", "La placa de verdad, o el eco corto que hacían los juegos de Game Boy Advance."},
    talkback = {"TALKBACK INVERSO", "El micro de la mesa abre la placa con cada golpe y le corta la cola de golpe. Un accidente de estudio."},
    lofi = {"LO-FI GBA", "Todo a 13 kHz y 8 bits: como sonaba una GBA."},
    rplay = {"PLAY", "Arranca y para la música."},
  },
  [S] = {
    pad = {"PAD", "Un sonido: tócalo con su botón (A, B, C o arriba en DIRECTO) o con el dedo. Al elegirlo, sus pasos y mandos son los de abajo."},
    step = {"PASO", "Un golpe del pad elegido en ese momento del compás. A lo enciende o apaga; arrastrando el dedo pintas varios."},
    gtono = {"TONO", "Más agudo o más grave el pad elegido, hasta una octava: la voz de ardilla del soul."},
    gnivel = {"NIVEL", "El volumen del pad elegido."},
    rec = {"REC", "Graba en el pad elegido: pulsa y haz el sonido al micro; empieza solo al oírlo y para con el silencio. Se pierde al apagar la consola."},
    gplay = {"PLAY", "Arranca y para la música. También con START."},
    gmodo = {"PASOS / DIRECTO", "En DIRECTO, A, B, C y arriba son los pads: tocas en vivo y, si suena la música, se queda en su paso."},
  },
  [M] = {
    fader = {"FADER", "El volumen del canal: 8 es como viene, 10 un poco más, 0 nada. Mantén A y sube o baja, o arrástralo con el dedo."},
    mute = {"MUTE", "Calla el canal sin perder su nivel. Otra vez A y vuelve a sonar."},
    solo = {"SOLO", "Solo suenan los canales en SOLO; los demás callan. Para escuchar una cosa sola y arreglarla."},
  },
  [N] = {
    slot = {"ACORDE", "El acorde de ese compás: A el siguiente, B el de antes. Son cuatro compases, y vuelta a empezar."},
    step = {"PASO", "Donde el acorde vuelve a sonar. Entre un paso encendido y el siguiente, se sostiene."},
    nbrillo = {"BRILLO", "El filtro: cerrado suena lejos, como en otra habitación; abierto, brilla."},
    nonda = {"ONDA", "Sierra: cuerdas, como una orquesta de plástico. Cuadrada: un órgano hueco."},
    nplay = {"PLAY", "Arranca y para la música. También con START."},
    narp = {"ARPEGIADOR", "En vez de tocar el acorde de golpe, toca sus tres notas una tras otra: SUBE, OCHO (más lento) o ZIGZAG. Con él, los pasos de abajo no se leen. B vuelve al anterior."},
    nvoz = {"VOZ", "Con qué suena el teclado: piano, órgano, cuerdas o tu voz (el sonido que grabaste en Golpe, afinado en cada tecla). B vuelve a la de antes."},
    nrec = {"GRABAR", "Arma la grabación: arranca la música y lo que toques cae en su paso, y vuelve a sonar cada vuelta. B borra la melodía."},
  },
  [O] = {
    nglide = {"GLIDE", "Cuánto tarda en deslizarse de una nota a la siguiente. Cero: salta; a tope: canta como un theremin."},
    nvib = {"VIBRATO", "El temblor fijo de la nota. La rueda MOD lo sube mientras la tienes."},
    nvol = {"VOLUMEN", "Cuánto suena el Nogal en la mezcla (también lo mueve el canal 8 de la mesa)."},
    nonda = {"ONDA", "Sierra: mordiente. Cuadrada: hueca, de órgano. Triángulo: suave, de flauta. B vuelve a la de antes."},
    nroll = {"ROLLO", "Cambia las teclas por un rollo de notas: cada columna es un paso, cada fila una nota. Toca o arrastra el dedo para pintar la melodía; tocar la misma casilla otra vez la borra."},
    nhum = {"TARAREAR", "Canta o silba al micro: tras un compás de cuenta, el Nogal escucha 16 pasos y deja en cada uno la nota que oyó, ajustada a la escala. Luego la toca él. Mejor con el volumen bajo."},
    nbend = {"RUEDA DE TONO", "Arrástrala con el dedo hacia arriba o abajo: la nota sube o baja hasta dos tonos y vuelve sola al soltarla. A: una caída de prueba."},
    nmod = {"RUEDA MOD", "Arrástrala hacia arriba para dar vibrato. A la deja fija."},
    nrec = {"GRABAR", "Arma la grabación: arranca la música y lo que toques cae en su paso. Una nota sobre otra apretada se une con un deslizamiento. B borra."},
    step = {"PASO", "Una nota de la melodía. A la apaga o la pone (con la última tocada); B la enlaza con la siguiente (~)."},
    nplay = {"PLAY", "Arranca y para la música. También con START."},
  },
  [P] = {
    cell1 = {"RITMO DE LA PARTE", "Qué patrón de la Ritmo 88 suena en esa parte: A cambia (A, B, C, D o nada), B vuelve atrás, C lo abre en la máquina."},
    cell2 = {"BAJO DE LA PARTE", "Qué patrón de la Línea 3 suena en esa parte. C lo abre en la Línea."},
    cell3 = {"COMPASES", "Cuánto dura la parte: 1, 2, 4 u 8 compases."},
    smodo = {"PATRÓN / CANCIÓN", "En PATRÓN, PLAY repite un compás; en CANCIÓN toca las partes seguidas."},
    splay = {"PLAY", "Arranca y para la música."},
    quitar = {"QUITAR", "Quita la parte elegida (siempre queda una)."},
    web = {"WEB", "EspaiSo: tus canciones en internet, cuánta gente las escucha y lo que te escriben. Puedes subir lo que suena."},
  },
}

local function focus_of(station)
  if station == "ritmo" then return focus, require("panel").SPOTS[focus] end
  if station == "linea" then return linea.focus, linea.panel.SPOTS[linea.focus] end
  if station == "rack" then return rack.focus, rack.panel.SPOTS[rack.focus] end
  if station == "pantalla" then return pantalla.focus, pantalla.panel.SPOTS[pantalla.focus] end
  if station == "golpe" then return golpe.focus, golpe.panel.SPOTS[golpe.focus] end
  if station == "mesa" then return mesa.focus, mesa.panel.SPOTS[mesa.focus] end
  if station == "nube" then return nube.focus, nube.panel.SPOTS[nube.focus] end
  if station == "nogal" then return nogal.focus, nogal.panel.SPOTS[nogal.focus] end
end

local function text_for(station, id, s)
  local T = G.TEXT[station]
  if not T or not s then return nil end
  if s.kind == "step" then return T.step end
  if s.kind == "inst" then return T.inst end
  if s.kind == "pad" then return T.pad end
  if s.kind == "cell" then return T["cell" .. s.r] end
  return T[id] or T[s.kind]
end

G.manual = nil
function G.open_manual(station)
  local id, s = focus_of(station)
  local t = text_for(station, id, s)
  if not t then return end
  G.manual = {station = station, title = t[1], body = t[2], t = 0}
  foley("press")
end

function G.update_manual()
  local m = G.manual
  m.t = m.t + 1
  if m.t < 6 then return end
  local _, _, _, tapped = touch()
  if btnp("c") and G.LESSONS[m.station] then
    G.manual = nil
    G.start(m.station)
  elseif btnp("a") or btnp("b") or btnp("menu") or btnp("start") or tapped then
    G.manual = nil
  end
end

-- ===== drawing =====

local SAY = {font = "lcd", color = 0xF2EBDD}
local NAME = {font = "hint", color = 0xFFE9B0}
local OK = {font = "hint", color = 0x9FE07A}
local COUNT = {font = "lcd", color = 0x8A7A60, align = "right"}

local function spot_rect(station, id)
  local P = station == "ritmo" and require("panel") or station == "linea" and linea.panel or
            station == "rack" and rack.panel or station == "golpe" and golpe.panel or
            station == "mesa" and mesa.panel or station == "nube" and nube.panel or
            station == "nogal" and nogal.panel or pantalla.panel
  local s = P.SPOTS[id]
  return s and s.x * 2, s and s.y * 2, s and s.w * 2, s and s.h * 2
end

function G.draw(at)
  local l = G.on
  if not l or l.station ~= at then return end
  local s = step_of(l)
  local id = type(s.spot) == "function" and s.spot() or s.spot
  if id and l.ok == 0 then                        -- the control, framed and breathing
    local x, y, w, h = spot_rect(l.station, id)
    if x then
      local g = 3 + (ticks() // 8) % 3
      box(x - g, y - g, w + 2 * g, h + 2 * g, 0xFFE070)
      box(x - g + 1, y - g + 1, w + 2 * g - 2, h + 2 * g - 2, 0xFFE070)
      box(x - g - 1, y - g - 1, w + 2 * g + 2, h + 2 * g + 2, 0x120E16)
    end
  end
  rect(0, 268, 480, 52, 0x120E16)                 -- the mentor, at the foot of the screen
  line(0, 268, 479, 268, 0xE8742A)
  img(G.FACE[G.LESSONS[l.station].who], 4, 270)
  if l.ok > 0 and not s.last then
    text("¡ESO ES!", 64, 282, OK)
  else
    l.words:draw(62, 272)
  end
  text(l.i .. "/" .. #G.LESSONS[l.station].steps, 474, 270, COUNT)
  text("SALTAR", 474, 296, COUNT)
end
function G.hit_skip(x, y) return G.on ~= nil and x >= 400 and y >= 268 end

local Q = {font = "hint", color = 0x120E16}
G.Q = {x = 446, y = 292, w = 30, h = 24}           -- the ? that opens the manual: at the foot, right of the hand
function G.draw_question()
  local q = G.Q
  rect(q.x, q.y, q.w, q.h, 0xE9B632)
  rect(q.x, q.y + q.h - 3, q.w, 3, 0x8A6A14)
  text("?", q.x + 9, q.y + 1, Q)
end
function G.hit_question(x, y) local q = G.Q return x >= q.x - 6 and y >= q.y - 6 end

local TITLE = {font = "hint", color = 0xFFE9B0, align = "center"}
local BODY = {font = "lcd", color = 0xF2EBDD, width = 360}
local KEYS = {font = "lcd", color = 0x8A8AA0, align = "center"}
function G.draw_manual()
  local m = G.manual
  if not m then return end
  rect(40, 70, 400, 186, 0x120E16)
  box(42, 72, 396, 182, 0xE9D8B0)
  text(m.title, 240, 82, TITLE)
  rich.draw(m.body, 60, 116, BODY)
  text(G.LESSONS[m.station] and "A: VOLVER   C: LA CLASE OTRA VEZ" or "A: VOLVER", 240, 226, KEYS)
end

return G
