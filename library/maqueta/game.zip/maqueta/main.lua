-- MAQUETA: a music producer's story on the Cirera, in first person. The title, the story (historia.lua and
-- story/es.txt, its cutscenes in cine.lua), each studio as a room (sala.lua) and its machines: Ritmo 88 (here),
-- Línea 3, the rack, FRUITERA 4. Everything of the console plays a part: d-pad and A/B/C, touch, the
-- microphone, the LED.
seq = require("seq")
local panel = require("panel")
local pointer = require("pointer")
linea = require("linea")
rack = require("rack")
song = require("song")
pantalla = require("pantalla")
sala = require("sala")
hands = require("hands")
cine = require("cine")
dlg = require("dialogo")
respuesta = require("respuesta")
historia = require("historia")
titulo = require("titulo")
finale = require("finale")
guia = require("guia")
golpe = require("golpe")
mesa = require("mesa")
nube = require("nube")
nogal = require("nogal")
batalla = require("batalla")
espaiso = require("espaiso")
radio = require("radio")
local particles = require("particles")

local fx
local polvo                       -- the dust still on the machine (0..1), while state == "polvo"
local DUST_PIXELS = 0
local dirty, save_in = false, 0
local led_in = 0
local toast_text, toast_in = nil, 0
local drag
pressed = {}                      -- step keys going down, in ticks
state, mode, focus, sel, station = "polvo", "pasos", "step0", 1, "ritmo"
local trans                       -- the mosaic between two machines: {t, to}

-- Measuring on the console: with a bench.txt sent inside the game (never shipped), there is no dust and a
-- "player" uses a control every half second, so the firmware's perf: line shows a real session.
local bench_txt = file("bench.txt") or ""
local bench = bench_txt:find("on") ~= nil              -- "off" undoes it where files cannot be deleted (up here:
                                                       -- switch_station must see it, or the bench player's edits are kept)
local bench_story = bench_txt:find("historia") ~= nil  -- the whole story on autopilot, a line every 50 ticks
local bench_concierto = bench_txt:find("concierto") ~= nil   -- straight to the concert, to measure it
local bench_espaiso = bench_txt:find("espaiso") ~= nil       -- straight to EspaiSo's page, to measure it
local bench_pruebas = bench_txt:find("pruebas") ~= nil       -- every studio open, the Nube about to detune, low volume:
                                                             -- to try the new things by ear

local PADS = {a = 1, b = 2, c = 4, up = 5, down = 6, left = 7, right = 3}  -- DIRECTO: the console is the pads
local PAD_NAMES = {"A", "B", ">", "C", "^", "v", "<"}  -- each instrument's pad, shown on its tile
local PAD_HAND = {a = "right", b = "right", c = "right", up = "left", down = "left", left = "left", right = "left"}

-- The engine turns a MENU press into START for games with no bag (src/game.c:190, a pinyol@1 rule
-- that reaches Lua games too), so MENU is read from its held state and START ignored while it is down.
local menu_was = false
local function menu_pressed() return btn("menu") and not menu_was end
local function start_pressed() return btnp("start") and not btn("menu") end

-- Foley: every control has its sound under the music (made here, no files): a key's click, a knob's detent, the
-- chair when you sit at a machine. Not while the microphone listens: it would hear them.
local FOLEY = {
  press = {id = "F_KEY", gain = 0.5, recipe = {wave = "noise", freq = 2600, sustain = 0.004, decay = 0.035, highpass = 0.35, volume = 0.5}},
  twist = {id = "F_TICK", gain = 0.35, recipe = {wave = "noise", freq = 5200, sustain = 0.002, decay = 0.012, highpass = 0.6, volume = 0.5}},
  sit = {id = "F_SIT", gain = 0.4, recipe = {wave = "noise", freq = 900, slide = -900, attack = 0.03, sustain = 0.05, decay = 0.16, lowpass = 0.25, volume = 0.5}},
  blip = {id = "F_BLIP", gain = 0.25, recipe = {wave = "square", freq = 740, duty = 0.25, sustain = 0.012, decay = 0.02, volume = 0.4}},
}
function foley(kind)
  local f = FOLEY[kind]
  if f and not seq.cap then sfx(f.id, f.gain * seq.volume) end
end
local function make_foley()
  for _, f in pairs(FOLEY) do sound(f.id, f.recipe) end
  hands.foley = foley
end

-- An LCD's words, or the short ones when the long do not fit its glass (106 px of the "lcd" font).
function fit_lcd(long, short) return textw(long, "lcd") <= 106 and long or short end

local function toast(t, ticks) toast_text, toast_in = t, ticks or 90 end
local function touched() dirty, save_in = true, 600 end
-- The machines' state into the saves: ten seconds after the last change, or on the way back to the room, where
-- the mosaic hides the fifth of a second the console's flash takes (the engine writes it a moment later).
local function save_all()
  seq.save(); linea.save(); rack.save(); song.save(); golpe.save(); mesa.save(); nube.save(); nogal.save()
  if espaiso.dirty then espaiso.save() end
  dirty = false
end
local function clamp(v, lo, hi) return math.max(lo, math.min(hi, v)) end

-- The knobs: what each one shows (0..1) and what turning it does.
local KNOBS = {
  tempo = {get = function() return (seq.tempo - seq.BPM_MIN) / (seq.BPM_MAX - seq.BPM_MIN) end,
           turn = function(d) seq.set_tempo(seq.tempo + 2 * d) end},
  swing = {get = function() return (seq.swing - seq.SWING_MIN) / (seq.SWING_MAX - seq.SWING_MIN) end,
           turn = function(d) seq.set_swing(seq.swing + 2 * d) end},
  tono = {get = function() return (seq.tracks[sel].tune + 12) / 24 end,
          turn = function(d) local t = seq.tracks[sel]; t.tune = clamp(t.tune + d, -12, 12) end, hear = true},
  nivel = {get = function() return seq.tracks[sel].level / 10 end,
           turn = function(d) local t = seq.tracks[sel]; t.level = clamp(t.level + d, 0, 10) end, hear = true},
  caida = {get = function() return (seq.tracks[sel].decay - 1) / 2 end,
           turn = function(d) local t = seq.tracks[sel]; t.decay = clamp(t.decay + d, 1, 3) end, hear = true},
  dens = {get = function() return seq.tracks[sel].dens / 16 end,
          turn = function(d) local t = seq.tracks[sel]; t.dens = clamp(t.dens + d, 0, 16); seq.apply_euclid(sel) end},
  rotar = {get = function() return seq.tracks[sel].rot / 15 end,
           turn = function(d) local t = seq.tracks[sel]; t.rot = (t.rot + d) % 16; seq.apply_euclid(sel) end},
}

local function aim()
  if station == "sala" then sala.aim(hands) return end
  if station == "linea" then linea.aim(hands) return end
  if station == "rack" then rack.aim(hands) return end
  if station == "pantalla" then pantalla.aim(hands) return end
  if station == "golpe" then golpe.aim(hands) return end
  if station == "mesa" then mesa.aim(hands) return end
  if station == "nube" then nube.aim(hands) return end
  if station == "nogal" then nogal.aim(hands) return end
  local s = panel.SPOTS[focus]
  hands.point(s.tip[1], s.tip[2], s.kind == "knob" and "pinch" or "point")
end

local function turn(d)
  local k = KNOBS[focus]
  if not k then return end
  local before = k.get()
  k.turn(d)
  if k.get() ~= before then
    hands.twist()
    touched()
    if k.hear and not seq.playing then seq.hit(sel, false) end
  end
end

local function toggle_play()
  if seq.playing then
    seq.stop()
    led()
    seq.save()
    linea.save()
    rack.save()
    song.save()
    golpe.save()
    mesa.save()
    nube.save()
    nogal.save()
    dirty = false
  else
    if song.mode == "cancion" then song.start() end   -- the whole song, from its first section
    seq.start()
  end
end

local function set_mode(m)
  mode = m
  if m == "directo" then
    hands.rest_all()
    toast((station == "linea" or station == "nube" or station == "nogal") and "DIRECTO: LOS BOTONES SON NOTAS" or "DIRECTO: LOS BOTONES SON PADS", 150)
  else
    aim()
  end
end

-- From the room to a machine and back (MENU stands up), through a GBA mosaic (8 frames out, the swap, 8 back).
local NEXT = {ritmo = "linea", linea = "rack", rack = "pantalla", pantalla = "golpe", golpe = "mesa", mesa = "nube", nube = "nogal", nogal = "sala", sala = "ritmo"}  -- the bench's round
local CANVAS = {ritmo = "PANEL", linea = "PANEL_L", rack = "PANEL_R", pantalla = "PANEL_P", golpe = "PANEL_G", mesa = "PANEL_M", nube = "PANEL_N", nogal = "PANEL_O", sala = "SALA"}
function switch_station(to)
  if trans then return end
  trans = {t = 0, to = to or NEXT[station]}
  foley("sit")
  if not bench then
    if dirty then save_all()
    elseif espaiso.dirty then espaiso.save() end
  end
end

local function update_trans()
  trans.t = trans.t + 1
  if trans.t == 8 then
    station = trans.to
    if station ~= "ritmo" and station ~= "linea" then mode = "pasos" end -- each starts in steps
    guia.arrive(station)                             -- the first time at a machine: its mentor shows it
    if station == "ritmo" or station == "linea" then  -- at a machine you edit a pattern: never one the song silenced
      if song.mode == "cancion" then song.mode = "patron"; toast("MODO PATRÓN: EDITAS EL PATRÓN", 150) end
      if station == "ritmo" and seq.pat == 0 then seq.select(1) end
      if station == "linea" and linea.pat == 0 then linea.select(1) end
    end
    bg(2, {image = station == "sala" and sala.canvas_id or CANVAS[station], prio = 2, mosaic = true, x = 0, y = 0})
    if station == "sala" then sala.look(); scroll(2, sala.cam()) end
    lcd_stale = true                                    -- every machine's LCD worked out again on arrival
    aim()
    local first = {linea = "LÍNEA 3, EL BAJO ÁCIDO", rack = "EL RACK: ECO, REVERB Y LO-FI",
                   pantalla = "FRUITERA 4: TU CANCIÓN ENTERA"}
    if first[station] and not stored("vio_" .. station) then
      store("vio_" .. station, true)
      toast(first[station], 200)
    end
  elseif trans.t >= 16 then
    trans = nil
    mosaic(1, 1)
  end
end

local function start_mic()
  if seq.cap then return end
  local level = mic()
  seq.capture(sel)
  hands.rest_all()
  if level then
    toast("UN COMPÁS DE CUENTA... ¡Y PALMAS!", 160)
  else
    toast("SIN MICRO: MARCA CON A, B O C", 160)
  end
end

-- A on a control (or a finger on it).
local function press(id)
  local s = panel.SPOTS[id]
  hands.press()
  if s.kind == "step" then
    local steps = seq.tracks[sel].steps
    steps[s.step + 1] = steps[s.step + 1] > 0 and 0 or 1
    seq.tracks[sel].vars = nil
    pressed[s.step] = 6
    touched()
  elseif s.kind == "inst" then
    sel = s.inst
    if not seq.playing then seq.hit(sel, false) end
  elseif id == "play" then
    toggle_play()
  elseif id == "mic" then
    start_mic()
  elseif id == "modo" then
    set_mode(mode == "pasos" and "directo" or "pasos")
  elseif id == "pat" then
    local p = seq.pat % seq.NPAT + 1
    local new = not seq.used(p)
    seq.select(p)
    toast("PATRÓN " .. ({"A", "B", "C", "D"})[p] .. (new and ": COPIA DEL ANTERIOR" or ""))
    touched()
  end
end

local function press_b(id)
  local s = panel.SPOTS[id]
  if s.kind == "step" then
    local steps = seq.tracks[sel].steps
    steps[s.step + 1] = steps[s.step + 1] == 2 and 1 or 2  -- the accent: louder
    seq.tracks[sel].vars = nil
    pressed[s.step] = 6
    hands.press()
    touched()
  elseif s.kind == "inst" then
    toast("MANTÉN B PARA BORRAR")
  end
end

local function variant()
  local v = seq.next_variant(sel)
  toast(v == 0 and "VUELVE EL ORIGINAL" or ("VARIANTE " .. v .. " DE 3"))
  touched()
end

local function input_pasos()
  local s = panel.SPOTS[focus]
  if s.kind == "knob" and btn("a") then
    if btnp("left", 10, 3) or btnp("down", 10, 3) then turn(-1) end
    if btnp("right", 10, 3) or btnp("up", 10, 3) then turn(1) end
  else
    local dx = (btnp("right", 12, 4) and 1 or 0) - (btnp("left", 12, 4) and 1 or 0)
    local dy = (btnp("down", 12, 4) and 1 or 0) - (btnp("up", 12, 4) and 1 or 0)
    if dx ~= 0 or dy ~= 0 then
      focus = panel.move(focus, dx, dx == 0 and dy or 0)
      aim()
    end
  end
  if btnp("a") then press(focus) end
  if btnp("b") then press_b(focus) end
  if s.kind == "inst" and btnt("b") == 40 then
    seq.set_steps(sel, seq.euclid(0, 16, 0))
    seq.tracks[sel].dens = 0
    toast(seq.INSTS[sel].name .. " BORRADO")
    touched()
  end
  if btnp("c") then variant() end
  if start_pressed() then toggle_play() end
  if menu_pressed() then
    if historia.apagon then toast("SIN LUZ: SOLO LA RITMO") else switch_station("sala") end
  end
end

local function input_directo()
  for b, i in pairs(PADS) do
    if btnp(b) then
      seq.hit(i, false)
      if seq.playing then seq.record(i, false); touched() end
      if historia.apagon then historia.flags.directo = (historia.flags.directo or 0) + 1 end
      hands.press(PAD_HAND[b])
      local h = hands.side[PAD_HAND[b]]
      fx:burst(h.x * 2, (h.y - 4) * 2, 6, {colours = {seq.INSTS[i].col, 0xFFFFFF}, speed = 2, life = 14, size = 2})
    end
  end
  if start_pressed() then toggle_play() end
  if menu_pressed() then set_mode("pasos") end
end

local function input_touch_linea(tx, ty)
  local first = not drag
  if first then drag = {id = linea.panel.at(tx, ty), y = ty, acc = 0} end
  local k = drag.id and linea.KNOBS[drag.id]
  if not k then linea.touch(tx, ty, first, ctx) return end
  if first then linea.focus = drag.id; linea.aim(hands) end
  drag.acc = drag.acc + (drag.y - ty)                 -- a finger up or down turns the knob
  drag.y = ty
  while math.abs(drag.acc) >= 4 do
    local d = drag.acc > 0 and 1 or -1
    k.turn(d)
    hands.twist()
    touched()
    drag.acc = drag.acc - 4 * d
  end
end

local function input_touch_rack(tx, ty)
  local first = not drag
  if first then drag = {id = rack.panel.at(tx, ty), y = ty, acc = 0} end
  if not drag.id then return end
  if first then
    rack.focus = drag.id
    rack.aim(hands)
    if not rack.KNOBS[drag.id] then rack.press(drag.id, ctx) end
  end
  local k = rack.KNOBS[drag.id]
  if not k then return end
  drag.acc = drag.acc + (drag.y - ty)                 -- a finger up or down turns the knob
  drag.y = ty
  while math.abs(drag.acc) >= 4 do
    local d = drag.acc > 0 and 1 or -1
    rack.turn(k, d, ctx)
    drag.acc = drag.acc - 4 * d
  end
end

local function input_touch()
  pointer.update()
  if station == "sala" then                       -- the room: a tap sits down, a drag sideways turns the head
    drag = nil                                     -- (a finger held from a machine into the room is not carried back)
    sala.finger(ctx)
    return
  end
  local tx, ty, down = touch()
  if not down then
    drag = nil
    return
  end
  if not drag and station ~= "sala" then           -- the foot of a machine: the mentor's SALTAR, the manual's ?
    if guia.hit_skip(tx * 2, ty * 2) then guia.skip(); drag = {} return end
    if not guia.on and guia.hit_question(tx * 2, ty * 2) then guia.open_manual(station); drag = {} return end
  end
  if station == "linea" then input_touch_linea(tx, ty) return end
  if station == "rack" then input_touch_rack(tx, ty) return end
  if station == "pantalla" then pantalla.touch(tx, ty, not drag, ctx); drag = drag or {} return end
  if station == "golpe" then golpe.touch(tx, ty, not drag, ctx); drag = drag or {} return end
  if station == "mesa" then mesa.touch(tx, ty, not drag, ctx); drag = drag or {} return end
  if station == "nube" then nube.touch(tx, ty, not drag, ctx); drag = drag or {} return end
  if station == "nogal" then nogal.touch(tx, ty, not drag, ctx); drag = drag or {} return end
  if not drag then
    local id = panel.at(tx, ty)
    drag = {id = id, y = ty, acc = 0}
    if id then
      focus = id
      aim()
      if panel.SPOTS[id].kind ~= "knob" then press(id) end
      if panel.SPOTS[id].kind == "step" then        -- the finger goes on along the keys: it paints them alike
        drag.paint, drag.done = seq.tracks[sel].steps[panel.SPOTS[id].step + 1], {[id] = true}
      end
    end
  elseif drag.paint then
    local id = panel.at(tx, ty)
    local s = id and panel.SPOTS[id]
    if s and s.kind == "step" and not drag.done[id] then
      drag.done[id] = true
      seq.tracks[sel].steps[s.step + 1] = drag.paint
      seq.tracks[sel].vars = nil
      pressed[s.step] = 6
      focus = id
      hands.point(s.tip[1], s.tip[2], "point")
      hands.press()
      touched()
    end
  elseif drag.id and KNOBS[drag.id] then        -- a finger up or down turns the knob
    drag.acc = drag.acc + (drag.y - ty)
    drag.y = ty
    while drag.acc >= 4 do turn(1); drag.acc = drag.acc - 4 end
    while drag.acc <= -4 do turn(-1); drag.acc = drag.acc + 4 end
  end
end

-- Recording from the microphone: its hits (or A, B, C without one) land on the nearest step.
local function input_capture()
  local _, _, hit = mic()
  local any = btnp("a") or btnp("b") or btnp("c")
  if seq.cap.phase == "rec" and (hit or any) then
    local s = seq.capture_hit()
    if s then
      pressed[s] = 6
      hands.press()
      local k = panel.SPOTS["step" .. s]
      fx:burst((k.x + 6) * 2, k.y * 2, 8, {colours = {0xFF3A1E, 0xFFF4E0}, speed = 2.5, life = 16, size = 2})
    end
  end
  if start_pressed() then seq.stop(); mic(false); led(); toast("GRABACIÓN CANCELADA") end
end

seq.on_step = function(s)
  if s % 4 ~= 0 then return end
  local cap = seq.cap
  local colour = cap and (cap.phase == "rec" and 0xFF0000 or 0xFFFF00) or (s == 0 and 0xFFFF00 or 0x00FF00)
  led(colour)
  led_in = 6
  hands.bob()
  if cap and cap.phase == "count" then
    tone(0, s == 0 and "A5" or "A4", {wave = "square", duty = 0.25, decay = 0.05, vol = 0.3})
  end
end

seq.on_capture = function(i)
  if seq.INSTS[i].id == "PALMAS" and seq.count(seq.tracks[i].steps) >= 4 then historia.flags.mic_palmas = true end
  mic(false)
  aim()
  toast(seq.INSTS[i].name .. ": " .. seq.count(seq.tracks[i].steps) .. " GOLPES", 150)
  touched()
end

-- The prologue's moment: the machine comes out of the attic under twenty years of dust (art/dust.png).
local function make_dust()
  state = "polvo"
  hands.rest_all()
  canvas("POLVO", "DUST")
  DUST_PIXELS, polvo = require("art_data").dust_pixels, 1
  bg(1, {image = "POLVO", prio = 1})
  blend(BG1, BG2, 12, 6)
end

function polvo_left() return polvo end         -- (tests)

local function wipe(x, y, r, n)
  target("POLVO")
  for _ = 1, n do
    circ(x + math.random(-r, r), y + math.random(-r // 2, r // 2), 1 + math.random(2), CLEAR)
  end
  target()
  polvo = polvo - n * 3.2 / DUST_PIXELS
end

-- A breath: the engine tells one (its fifth value); an older engine only says loud and without a note.
function blowing(level, pitch, kind, kinds)
  if not level then return 0 end
  if kinds then return kind == "blow" and level or 0 end
  return level > 0.3 and pitch == 0 and level or 0
end

local function update_dust()
  if dlg.auto then polvo = 0 end
  local level, pitch, _, _, kind = mic()
  local blow = blowing(level, pitch, kind, select("#", mic()) >= 5)
  if blow > 0 then
    local p = panel.PANEL
    for _ = 1, 3 do
      local x, y = p.x + math.random(p.w), p.y + math.random(p.h)
      wipe(x, y, 18, math.floor(30 * blow))
      fx:burst(x * 2, y * 2, 2, {colours = {0xA89E92, 0x8A8078}, speed = 3 * blow, angle = -90, spread = 120, life = 30, size = 2, gravity = -0.03})
    end
  end
  local tx, ty, down = touch()
  if down then                                   -- rubbing it with a finger
    hands.point(tx, ty, "point")
    wipe(tx, ty, 6, 12)
  elseif btn("a") then                           -- or with the hand, held
    local t = ticks() % 120
    local x = 20 + math.abs(t - 60) * 3.3
    hands.point(x, 60 + (ticks() // 120 % 3) * 25, "rest")
    wipe(x, 60 + (ticks() // 120 % 3) * 25, 10, 14)
  end
  if polvo < 0.18 then
    bg(1)
    fx_off()
    mic(false)
    state = "juego"
    store("polvo", true)
    aim()
  end
end

local HINTS = {
  step = "A PASO   B ACENTO   C VARIANTE",
  step2 = "MENU: VUELVE A LA SALA",
  inst = "A ELEGIR   C VARIANTE   B LARGO BORRA",
  knob = "MANTÉN A Y MUEVE LA CRUCETA",
  button = "A PULSAR",
  switch = "A CAMBIAR A DIRECTO",
}

local function hint()
  if state == "polvo" then return "SOPLA AL MICRO O FROTA CON EL DEDO" end
  if seq.cap then return seq.cap.phase == "count" and "PREPÁRATE..." or "¡DA PALMAS AL RITMO!" end
  if station == "linea" then return linea.hint(ctx) end
  if station == "rack" then return rack.hint() end
  if station == "pantalla" then return pantalla.hint() end
  if station == "golpe" then return golpe.hint(ctx) end
  if station == "mesa" then return mesa.hint() end
  if station == "nube" then return nube.hint(ctx) end
  if station == "nogal" then return nogal.hint(ctx) end
  if station == "sala" then
    if historia.enc and (ticks() // 150) % 2 == 1 then return "C: ENTREGAR EL ENCARGO" end
    if historia.ch == 6 and (ticks() // 150) % 2 == 1 then return "B: OTRO ESTUDIO   START: PLAY" end
    return sala.hint()
  end
  if historia.apagon then return string.format("¡A MANO! %d DE 16 GOLPES", math.min(16, historia.flags.directo or 0)) end
  if mode == "directo" then return "A B C Y CRUCETA: PADS   MENU: PASOS" end
  if focus == "mic" then return "A GRABAR CON EL MICRO" end
  if focus == "pat" then return "A OTRO PATRÓN (A-D)" end
  local kind = panel.SPOTS[focus].kind
  if kind == "step" and (ticks() // 180) % 2 == 1 then return HINTS.step2 end
  return HINTS[kind]
end

-- What Línea 3 uses of the shell (linea.lua)
ctx = {hands = hands, touched = touched, toggle_play = toggle_play, set_mode = set_mode, toast = toast,
       mode = function() return mode end, go = function(st) switch_station(st) end}

-- The station's picture back on layer 2 when a cutscene is over (or the title is left).
function restore_station()
  bg(2, {image = station == "sala" and sala.canvas_id or CANVAS[station], prio = 2, mosaic = true, x = 0, y = 0})
  if station == "sala" then sala.look(); sala.cx, sala.cy = sala.tx, sala.ty; scroll(2, sala.cam()) end
  if station == "rack" or station == "pantalla" or station == "sala" then mode = historia.apagon and mode or "pasos" end
  lcd_stale = true
  hands.hidden = false
  aim()
end

-- Straight to the machines, every studio open: the bench and the tests.
function dev_skip()
  guia.off = true                                  -- (the tests that want a lesson start one)
  state = "juego"
  store("polvo", true)
  historia.ch, historia.enc = 6, nil
  sala.build("faro")
  station = "ritmo"
  cine.off()
  restore_station()
end

-- The blackout: only a circle of light around the hand that plays (the window, line by line), the LED orange.
local function draw_apagon()
  local h = hands.side[hands.active or "right"]
  local cx, cy, r = math.floor(h.x), math.floor(h.y) - 14, 52
  backdrop(0x000000)
  window(0, 0, 0, 240, 160, ALL)
  for y = 0, 159 do
    local dy = y - cy
    if dy > -r and dy < r then
      local dx = math.floor(math.sqrt(r * r - dy * dy) + math.random(0, 1))
      line_window(0, y, cx - dx, cx + dx)
    else
      line_window(0, y, 0, 0)
    end
  end
  window_out(OBJ)
end

-- What historia.lua uses of the shell; the concert and the credits are 3d's (finale.lua).
local shell = {toast = toast, toggle_play = toggle_play, set_mode = function(m) set_mode(m) end,
               start_polvo = function() make_dust() end}

if bench_txt:find("borrar") then historia.wipe(true) end    -- after the benches: the console as new, no game saved
local BENCH_R = {"tiempo", "repet", "rev_ritmo", "eco_bajo", "tamano", "brillo", "modo_rev", "lofi"}
local BENCH_L = {"lstep2", "corte", "lstep5", "reso", "lstep9", "env", "lstep12", "lcaida"}
local BENCH = {"step3", "tempo", "inst2", "step7", "dens", "inst4", "step12", "nivel", "step1", "swing", "inst1"}  -- no "mic": it costs the engine ~3 ms a tick

local function bench_tick()
  local n = ticks()
  if n % 300 == 0 then log(string.format("bench perf (%s, %s): update %.2f ms, draw %.2f ms, picture %.2f ms, lua %.0f KB", seq.engine and "studio" or "ticks", station, perf())) end
  if n % 600 == 0 then switch_station() return end  -- both machines, ten seconds each
  if n % 30 ~= 0 or seq.cap or trans then return end
  if not seq.playing then seq.start() end
  if station == "nube" then
    local ids = {"n2", "nstep4", "nbrillo", "n3", "nstep8", "n4", "nonda", "nstep12", "nonda"}
    nube.focus = ids[(n // 30) % #ids + 1]
    nube.aim(hands)
    if nube.KNOBS[nube.focus] then nube.turn(nube.focus, (n // 30) % 2 == 0 and 1 or -1, ctx) else nube.press(nube.focus, ctx) end
    return
  end
  if station == "nogal" then
    local ids = {"nglide", "nstep4", "nvib", "nonda", "nstep8", "nvol", "nbend", "nstep12"}
    nogal.focus = ids[(n // 30) % #ids + 1]
    nogal.aim(hands)
    if nogal.KNOBS[nogal.focus] then nogal.turn(nogal.focus, (n // 30) % 2 == 0 and 1 or -1, ctx) else nogal.press(nogal.focus, ctx) end
    return
  end
  if station == "mesa" then
    local ids = {"f1", "m3", "f6", "s2", "f7", "s2", "m3", "f4"}
    mesa.focus = ids[(n // 30) % #ids + 1]
    mesa.aim(hands)
    local s = mesa.panel.SPOTS[mesa.focus]
    if s.kind == "fader" then mesa.set_fader(s.ch, mesa.fader[s.ch] + ((n // 30) % 2 == 0 and 1 or -1), ctx) else mesa.press(mesa.focus, ctx) end
    return
  end
  if station == "golpe" then
    local ids = {"pad1", "gstep3", "pad2", "gtono", "gstep6", "pad3", "gnivel", "pad4", "gstep12"}
    golpe.focus = ids[(n // 30) % #ids + 1]
    golpe.aim(hands)
    if golpe.KNOBS[golpe.focus] then golpe.turn(golpe.focus, (n // 30) % 2 == 0 and 1 or -1, ctx) else golpe.press(golpe.focus, ctx) end
    return
  end
  if station == "sala" then
    sala.focus = sala.focus % #sala.spots() + 1
    sala.look()
    return
  end
  if station == "rack" then
    rack.focus = BENCH_R[(n // 30) % #BENCH_R + 1]
    rack.aim(hands)
    local k = rack.KNOBS[rack.focus]
    if k then rack.turn(k, (n // 30) % 2 == 0 and 1 or -1, ctx) else rack.press(rack.focus, ctx) end
    return
  end
  if station == "linea" then
    linea.focus = BENCH_L[(n // 30) % #BENCH_L + 1]
    linea.aim(hands)
    local k = linea.KNOBS[linea.focus]
    if k then k.turn((n // 30) % 2 == 0 and 1 or -1) else linea.press(linea.focus, ctx) end
    return
  end
  focus = BENCH[(n // 30) % #BENCH + 1]
  aim()
  if KNOBS[focus] then turn((n // 30) % 2 == 0 and 1 or -1) else press(focus) end
end

-- The player's volume (the title's VOLUMEN): the engine's master gain, so everything follows it (a cutscene's tones,
-- the iaia's notes); seq.volume stays the machines' own mix. An engine without volume() turns the machines down.
game_volume = 0.6
local mudo = bench_txt:find("mudo") ~= nil      -- a console that plays its tests on its own: never a sound
function set_volume(v)
  game_volume = v
  if volume then volume(mudo and 0 or v); seq.volume = 1 else seq.volume = mudo and 0 or v end
end

function _init()
  backdrop(0x150e12)
  make_foley()
  set_volume(stored("volumen", 0.6))
  seq.load()
  linea.load()
  rack.load()
  song.load()
  seq.on_fire = linea.fire
  seq.on_heard = song.heard
  panel.build()
  linea.panel.build()
  rack.panel.build()
  pantalla.panel.build()
  golpe.make_sounds()
  golpe.load()
  nube.make_sounds()
  golpe.panel.build()
  mesa.load()
  mesa.panel.build()
  nube.load()
  nube.panel.build()
  nogal.load()
  nogal.panel.build()
  espaiso.load()
  sala.build(stored("sala_room", "desvan"))
  fx = particles.new()
  cine.init(fx)
  cine.restore = restore_station
  dlg.init()
  finale.init(fx)
  shell.start_concierto = finale.start
  shell.concierto_on = function() return finale.on end
  shell.start_creditos = finale.start_creditos
  shell.creditos_on = function() return finale.creditos end
  historia.init(shell)
  local sonido = bench_txt:find("sonido") ~= nil              -- (a bench to watch and hear: the game's own volume)
  if (bench or bench_story or bench_concierto or bench_espaiso) and volume and not sonido then volume(0) end   -- the benches in silence (the user asked)
  if bench_pruebas then
    dev_skip()
    nube.queue_accident()
    if volume then volume(0.4) end
  elseif bench_espaiso then
    dev_skip()
    switch_station("pantalla")
    espaiso.open()
  elseif bench_concierto then
    dev_skip()
    seq.volume = 0
    finale.start()
  elseif bench_story then
    seq.volume = sonido and 1 or 0
    dlg.auto, dlg.auto_every = true, 50
    historia.nueva()
  elseif bench then
    dev_skip()
    seq.volume = 0                                -- measuring on a desk: in silence
    seq.start()
  else
    titulo.enter()
  end
end

function _update()
  seq.update()
  hands.update()
  fx:update()
  for s, n in pairs(pressed) do pressed[s] = n > 1 and n - 1 or nil end
  if toast_in > 0 then toast_in = toast_in - 1 end
  if led_in > 0 then
    led_in = led_in - 1
    if led_in == 0 and seq.playing then led(0x000000) end
  end
  linea.update_anim()
  mesa.update()                                    -- (its LEDs read the hits before golpe.update fades them)
  golpe.update()
  golpe.sync()
  nube.update()
  nogal.update()
  nube.update_accident(ctx)
  nube.sync()
  linea.sync()
  rack.sync()
  cine.update()
  cine.update_hum()
  if state == "juego" and not bench and not bench_story then espaiso.tick(toast) end
  historia.update()
  if bench_story then
    local u = perf()
    if u > (bench_max or 0) then bench_max, bench_at = u, (cine.name or station) .. "/" .. (dlg.knot or "-") end
    if ticks() % 300 == 0 then
      log(string.format("story perf (cap %s, %s, %s): update %.2f ms, draw %.2f ms, picture %.2f ms, lua %.0f KB; max update %.2f ms at %s",
                        tostring(historia.ch), cine.name or station, dlg.knot or "-", u, select(2, perf()), select(3, perf()),
                        select(4, perf()), bench_max, bench_at))
      bench_max = 0
    end
  end
  if historia.kb then historia.update_kb() return end
  if state == "titulo" then titulo.update() return end
  if state == "polvo" then update_dust() return end
  if trans then update_trans() menu_was = btn("menu") return end
  if respuesta.on then respuesta.update() menu_was = btn("menu") return end
  if batalla.on then batalla.update() menu_was = btn("menu") return end
  if espaiso.on then espaiso.update() menu_was = btn("menu") return end
  if radio.on then radio.update() menu_was = btn("menu") return end
  if finale.on then finale.update() menu_was = btn("menu") return end
  if finale.creditos then finale.update_creditos() menu_was = btn("menu") return end
  if dlg.on then dlg.update() menu_was = btn("menu") return end
  if dlg.cool > 0 then dlg.cool = dlg.cool - 1 menu_was = btn("menu") return end
  if guia.manual then guia.update_manual() menu_was = btn("menu") return end
  guia.update(station)
  if bench then bench_tick() end
  if seq.cap then input_capture()
  elseif station == "sala" then
    sala.update(ctx)
    if start_pressed() then toggle_play() end
    if btnp("c") then historia.deliver() end
    if btnp("b") and historia.ch == 6 then           -- free: every studio of the journey
      local i = 1
      for k, r in ipairs(historia.ROOMS) do if r == sala.room then i = k end end
      sala.build(historia.ROOMS[i % #historia.ROOMS + 1])
      foley("sit")
      store("sala_room", sala.room)
    end
  elseif station == "pantalla" then
    pantalla.input(ctx)
    if start_pressed() then toggle_play() end
    if menu_pressed() then switch_station("sala") end
  elseif station == "golpe" then
    if golpe.rec then golpe.update_rec(ctx)
    elseif mode == "pasos" then golpe.input_pasos(ctx)
    else golpe.input_directo(ctx) end
    if start_pressed() then toggle_play() end
    if menu_pressed() and not golpe.rec then if mode == "pasos" then switch_station("sala") else set_mode("pasos") end end
  elseif station == "nube" then
    nube.input(ctx)
    if start_pressed() then toggle_play() end
    if menu_pressed() then if mode == "pasos" then switch_station("sala") else set_mode("pasos") end end
  elseif station == "nogal" then
    nogal.input(ctx)
    if start_pressed() then toggle_play() end
    if menu_pressed() then if mode == "pasos" then switch_station("sala") else set_mode("pasos") end end
  elseif station == "mesa" then
    mesa.input(ctx)
    if start_pressed() then toggle_play() end
    if menu_pressed() then switch_station("sala") end
  elseif station == "rack" then
    rack.input(ctx)
    if start_pressed() then toggle_play() end
    if menu_pressed() then switch_station("sala") end
  elseif station == "linea" then
    if mode == "pasos" then linea.input_pasos(ctx) else linea.input_directo(ctx) end
    if start_pressed() then toggle_play() end
    if menu_pressed() then if mode == "pasos" then switch_station("sala") else set_mode("pasos") end end
  elseif mode == "pasos" then input_pasos()
  else input_directo() end
  input_touch()
  menu_was = btn("menu")
  if dirty and not bench then                      -- the bench player's edits are never kept
    save_in = save_in - 1
    if save_in <= 0 then save_all() end
  end
end

-- The LCD says what the hand holds, big enough to read: the panel itself carries icons, not words.
local DECAY_NAME = {"CORTA", "MEDIA", "LARGA"}
local LCD_OF = {
  tempo = function() return string.format("TEMPO %d BPM", math.floor(seq.bpm() + 0.5)) end,
  swing = function() return "SWING " .. seq.swing_pct() .. "%" end,
  tono = function() local t = seq.tracks[sel].tune; return "TONO " .. (t > 0 and "+" or "") .. t end,
  nivel = function() return "NIVEL " .. seq.tracks[sel].level end,
  caida = function() return "CAÍDA " .. DECAY_NAME[seq.tracks[sel].decay] end,
  dens = function() return "DENSIDAD " .. seq.tracks[sel].dens end,
  rotar = function() return "ROTAR " .. seq.tracks[sel].rot end,
  play = function() return seq.playing and "STOP" or string.format("PLAY  %d BPM", math.floor(seq.bpm() + 0.5)) end,
  mic = function() return fit_lcd("GRABAR " .. seq.INSTS[sel].name, "MIC " .. seq.INSTS[sel].name) end,
  modo = function() return mode == "pasos" and "MODO PASOS" or "MODO DIRECTO" end,
  pat = function() return seq.pat > 0 and ("PATRÓN " .. ({"A", "B", "C", "D"})[seq.pat]) or "PATRÓN: CALLA" end,
}

local function lcd()
  if state == "polvo" then return "..." end
  if seq.cap then return seq.cap.phase == "count" and ("CUENTA " .. (4 - (seq.step // 4))) or "¡PALMAS!" end
  if mode == "directo" then return "DIRECTO" end
  local s = panel.SPOTS[focus]
  if LCD_OF[focus] then return LCD_OF[focus]() end
  if s.kind == "inst" then return seq.INSTS[s.inst].name end
  return fit_lcd(seq.INSTS[sel].name .. "  PASO " .. (s.step + 1), seq.INSTS[sel].name .. " P" .. (s.step + 1))
end

ritmo_lcd = lcd                                -- (tests/textos.script)

local view = {knobs = {}}                       -- reused every frame: no garbage at 60 a second
local TOAST_STYLE = {font = "hint", color = 0xFFD84A, align = "center"}  -- one line: 34 letters at most
local HINT_STYLE = {font = "hint", color = 0xE9E1CF, align = "center", shadow = 0x000000}

local lcd_l, lcd_for                      -- the LCD's text, and which machine it was worked out for
function _draw()
  if state == "titulo" then
    if historia.kb then historia.kb:draw() else titulo.draw() end
    hands.draw()
    return
  end
  if lcd_stale then view.lcd, lcd_for, lcd_stale = nil, nil, false end
  if trans then local m = trans.t <= 8 and trans.t or 16 - trans.t; mosaic(1 + m, 1 + m) end
  if historia.apagon and not cine.s then draw_apagon() end
  if cine.s then                               -- a cutscene has layer 2: no machine to draw
  elseif station == "linea" then
    if ticks() % 4 == 0 or lcd_for ~= station then lcd_l, lcd_for = seq.cap and lcd() or linea.lcd(ctx), station end
    linea.panel.draw(linea.view(ctx, lcd_l))
  elseif station == "rack" then
    if ticks() % 4 == 0 or lcd_for ~= station then lcd_l, lcd_for = seq.cap and lcd() or rack.lcd(), station end
    rack.panel.draw(rack.view(lcd_l))
  elseif station == "pantalla" then
    if ticks() % 4 == 0 or lcd_for ~= station then lcd_l, lcd_for = pantalla.lcd(), station end
    pantalla.panel.draw(pantalla.view(lcd_l))
  elseif station == "golpe" then
    if ticks() % 4 == 0 or lcd_for ~= station then lcd_l, lcd_for = golpe.lcd(ctx), station end
    golpe.panel.draw(golpe.view(ctx, lcd_l))
  elseif station == "mesa" then
    if ticks() % 4 == 0 or lcd_for ~= station then lcd_l, lcd_for = mesa.lcd(), station end
    mesa.panel.draw(mesa.view(lcd_l))
  elseif station == "nube" then
    if ticks() % 4 == 0 or lcd_for ~= station then lcd_l, lcd_for = nube.lcd(), station end
    nube.panel.draw(nube.view(lcd_l, ctx))
  elseif station == "nogal" then
    if ticks() % 4 == 0 or lcd_for ~= station then lcd_l, lcd_for = nogal.lcd(), station end
    nogal.panel.draw(nogal.view(lcd_l))
  elseif station == "sala" then
    if not trans and not dlg.on then sala.draw(); historia.draw_card() end
  else
    draw_ritmo()
  end
  if not cine.s and not dlg.on and not trans and station ~= "sala" and state == "juego" then
    guia.draw(station)
    if not guia.on then guia.draw_question() end
  end
  cine.draw()
  if finale.on then finale.draw() end
  if finale.creditos then finale.draw_creditos() end
  if (dlg.on and not dlg.blocked()) or cine.s or cine.card or finale.on or respuesta.on or batalla.on or espaiso.on or radio.on or historia.kb then   -- words of their own
  elseif toast_in > 0 then                     -- news take the top line for a moment
    rect(0, 0, 480, 26, 0x2a1810)
    line(0, 26, 479, 26, 0xE8742A)
    text(toast_text, 240, 3, TOAST_STYLE)
  else
    text(hint(), 240, 3, HINT_STYLE)
  end
  respuesta.draw()
  batalla.draw()
  espaiso.draw()
  guia.draw_manual()
  dlg.draw()
  if historia.kb then historia.kb:draw() end
  hands.draw()
  fx:draw()
  radio.draw()
end

function draw_ritmo()
  local v = view
  for id, k in pairs(KNOBS) do v.knobs[id] = k.get() end
  v.sel, v.pressed, v.mode, v.pat = sel, pressed, mode, seq.pat
  if ticks() % 4 == 0 or not v.lcd then v.lcd = lcd() end   -- its text 15 times a second: less garbage for the GC
  v.mic_lit = seq.cap ~= nil and (seq.cap.phase == "rec" or ticks() % 30 < 15)
  v.pads = mode == "directo" and PAD_NAMES or nil
  panel.draw(v)
end
