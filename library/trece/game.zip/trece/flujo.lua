-- The story's order: cutscene, chapter cards, conversations and games, one after another. Each step done is saved
-- ("progreso"), so Continue starts at the next one.

local scene = require("scene")
local lang = require("lang")
local F = require("fisica")
local P = require("partida")
local R = require("rival")

local flujo = {}

-- The patio: Remei shows Tina how it is done. Three throws to learn, then as many as it takes to get within 30 cm.
local function tutorial(api)
  local c = F.CIRCLE
  local function new_end()
    api.round()
    api.jack(c.x + 6, c.y - 200)     -- the jack 5 m away
  end
  new_end()
  api.talk("tuto_1")
  api.throw()
  api.talk("tuto_2")
  api.throw()
  api.talk("tuto_3")
  STORY.vars.intentos = 0
  while true do
    if P.left[1] == 0 then new_end() end
    local r = api.throw()
    STORY.vars.cm = r.gap and math.max(1, math.floor(r.gap + 0.5)) or 0
    if r.gap and r.gap < 30 then break end
    api.talk("tuto_fallo")
  end
  api.talk("tuto_bien")
end

-- The square: a game to 7 against Quim, again until it is won.
local function partida_quim(api)
  api.talk("cap2_pista")
  while api.match() ~= 1 do api.talk("cap2_pierde") end
  api.talk("cap2_gana")
end

-- The beach: a game to 7 against the Paqui, on sand.
local function partida_paqui(api)
  api.talk("cap3_pista")
  while api.match() ~= 1 do api.talk("cap3_pierde") end
  api.talk("cap3_gana")
end

-- The beach: Tina's first shots, at five soda tins in a row, 6.5 m away. Five boules.
local function latas(api)
  local c = F.CIRCLE
  local tins, down = {}, 0
  api.round()
  P.left[1] = 5
  for k = 0, 4 do tins[#tins + 1] = api.place("tin", 0, c.x - 16 + k * 8, c.y - 260) end
  api.focus(c.x, c.y - 260)
  api.shot(4)
  api.hud(function() return lang.tr("tins_hud", {n = down, b = P.left[1]}) end)
  api.talk("cap3_latas")
  for _ = 1, 5 do
    for _, t in ipairs(tins) do  -- the mark starts on the next tin still standing
      if not t.knocked then api.focus(t.x, t.y); break end
    end
    local r = api.throw()
    down = 0
    for _, t in ipairs(tins) do if t.knocked then down = down + 1 end end
    if r.body then api.remove(r.body) end   -- the boule picked up again, so it does not hide the next tins
  end
  STORY.vars.latas = down
  if down == 5 then achieve("cinco_latas") end
  api.hud(nil)
  api.talk("cap3_latas_fin")
end

-- The riera: Tina against Pol, five shots each at a boule 7 m away. A carreau is 3, a boule struck 1.
local function duelo(api)
  local c = F.CIRCLE
  local tx, ty = c.x, c.y - 280
  local pts = {0, 0}
  local function score(r) return r.carreau and 3 or (r.hit and (r.moved or 0) > 8) and 1 or 0 end
  local function reset()
    F.reset()
    P.left = {5, 5}
    return api.place("boule", 2, tx, ty)
  end
  api.focus(tx, ty)
  api.shot(4)
  api.hud(function() return string.format("Tina %d · %d Pol", pts[1], pts[2]) end)
  api.talk("cap4_duelo")
  for round = 1, 5 do
    local target = reset()
    local r = api.rival_throw(R.shoot_at("pol", target))
    pts[2] = pts[2] + score(r)
    reset()
    api.shot(4)
    r = api.throw()
    pts[1] = pts[1] + score(r)
  end
  STORY.vars.puntos_tina, STORY.vars.puntos_pol = pts[1], pts[2]
  STORY.vars.duelo_gana = pts[1] >= pts[2]
  api.hud(nil)
  api.talk("cap4_duelo_fin")
end

-- The square on Tuesday noon: the semifinal in pairs, Remei and Tina against Quim and Paqui, until it is won.
local function semifinal(api)
  api.talk("cap5_semi_pista")
  while api.match() ~= 1 do api.talk("cap5_semi_pierde") end
  api.talk("cap5_semi_gana")
end

-- The night of Sant Joan: the final in pairs to 13, Remei and Tina against Ximo and Pol, until it is won.
local function final(api)
  while api.match() ~= 1 do api.talk("cap6_pierde") end
  api.talk("cap6_gana")
end

flujo.steps = {
  {"cine"},
  {"tarjeta", top = "card_c1_top", name = "card_c1_name"},
  {"historia", fondo = "FONDO_CASA", knot = "cap1_llegada"},
  {"historia", fondo = "FONDO_COMEDOR", knot = "cap1_comedor"},
  {"historia", fondo = "FONDO_LATA", knot = "cap1_lata", anim = "lata"},
  {"juego", terreno = "patio", director = tutorial},
  {"tarjeta", top = "card_c2_top", name = "card_c2_name"},
  {"historia", fondo = "FONDO_BAR", knot = "cap2_bar"},
  {"juego", terreno = "plaza", rival = "quim", goal = 7, director = partida_quim, knots = {medir = "cap2_medir"}},
  {"historia", fondo = "FONDO_BAR", knot = "cap2_fin"},
  {"tarjeta", top = "card_c3_top", name = "card_c3_name"},
  {"historia", fondo = "FONDO_CHIRINGUITO", knot = "cap3_llegada"},
  {"juego", terreno = "playa", rival = "paqui", goal = 7, director = partida_paqui},
  {"historia", fondo = "FONDO_CHIRINGUITO", knot = "cap3_sombrilla"},
  {"juego", terreno = "playa", player = "Tina", hands = "MANOS_TINA", director = latas},
  {"tarjeta", top = "card_c4_top", name = "card_c4_name"},
  {"historia", fondo = "FONDO_RIERA", knot = "cap4_llegada"},
  {"juego", terreno = "riera", player = "Tina", hands = "MANOS_TINA", rival = "pol", director = duelo},
  {"historia", fondo = "FONDO_RIERA_OCASO", knot = "cap4_ocaso"},
  {"tarjeta", top = "card_c5_top", name = "card_c5_name"},
  {"historia", fondo = "FONDO_BAR", knot = "cap5_bar"},
  {"fotos"},
  {"historia", fondo = "FONDO_BAR", knot = "cap5_perro"},
  {"juego", terreno = "plaza", doubles = {partner = "Tina", rivals = {"quim", "paqui"}, per = 4}, goal = 7,
   director = semifinal},
  {"historia", fondo = "FONDO_BAR", knot = "cap5_fin"},
  {"tarjeta", top = "card_c6_top", name = "card_c6_name"},
  {"historia", fondo = "FONDO_REVETLLA", knot = "cap6_revetlla"},
  {"juego", terreno = "revetlla", doubles = {partner = "Tina", rivals = {"ximo", "pol"}, per = 4, handicap = 1.4}, goal = 13,
   dog = {mene = 3, knot = "cap6_perro"},
   director = final},
  {"historia", fondo = "FONDO_BAR", knot = "cap6_epilogo"},
  {"creditos"},
}

local scenes = {}
function flujo.setup(s) scenes = s end

-- The step to continue from: 1 if what is saved is not a step of this story.
function flujo.saved()
  local n = stored("progreso")
  return flujo.steps[n] and n or 1
end

function flujo.run(n)
  local step = flujo.steps[n]
  if not step then
    FLUJO_FIN = (FLUJO_FIN or 0) + 1   -- the tests read it
    store("progreso", 1)
    scene.go(scenes.titulo, {pick = flujo.pick}, {fade = 0.5})
    return
  end
  store("progreso", n)
  local done = function() flujo.run(n + 1) end
  local kind = step[1]
  local a = {done = done}
  for k, v in pairs(step) do if type(k) == "string" then a[k] = v end end
  scene.go(scenes[kind], a, {fade = 0.4})
end

-- The title's menu.
function flujo.pick(id)
  if id == "nueva" then
    store("story", nil)
    STORY = new_story()
    flujo.run(1)
  elseif id == "seguir" then
    flujo.run(flujo.saved())
  elseif id == "rapida" then
    local function to_title() scene.go(scenes.titulo, {pick = flujo.pick}, {fade = 0.4}) end
    local play
    local function setup() scene.go(scenes.rapida, {play = play, back = to_title}, {fade = 0.4}) end
    play = function(s)  -- a game, and back to the setup when it ends
      s.goal, s.director, s.done = 7, function(api) api.match() end, setup
      scene.go(scenes.juego, s, {fade = 0.4})
    end
    setup()
  end
end

return flujo
