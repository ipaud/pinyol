-- The rules of a game of petanque: one against one (tête-à-tête) with three boules each, or in pairs (doubles) with
-- four a team, two for each player; to 7 points (13 in the final).
-- Who throws next: the team that does not hold the point, while it has boules; then the other one.

local F = require("fisica")
local T = require("tiro")

local P = {}

P.names = {"Remei", "Quim"}
P.score = {0, 0}
P.per = 3                  -- boules a team has in a round
P.left = {3, 3}
P.starter = 1
P.goal = 7
P.mene = 0

function P.new_match(goal, per)
  P.score, P.starter, P.goal, P.mene, P.per = {0, 0}, 1, goal or 7, 0, per or 3
end

function P.new_mene()
  F.reset()
  P.left = {P.per, P.per}
  P.mene = P.mene + 1
end

-- The starter throws the jack, between 6 and 10 m from the circle.
function P.throw_jack()
  local d = 240 + math.random() * 160
  local x = F.CIRCLE.x + (math.random() - 0.5) * 50
  local y = F.CIRCLE.y - d
  local shot = F.SHOTS[2]
  local rx, ry = F.CIRCLE.x, F.CIRCLE.y - 20
  local land = F.landing_for(shot, math.sqrt((x - rx) ^ 2 + (y - ry) ^ 2), F.R_JACK, F.MU * 2.2)
  local ux, uy = x - rx, y - ry
  local n = math.sqrt(ux * ux + uy * uy)
  T.last = F.launch("jack", 0, rx, ry, rx + ux / n * land, ry + uy / n * land, shot)
  return T.last
end

-- The team holding the point (nil with no boules down), and how far its best boule is.
function P.holder()
  local rank = F.ranking()
  if rank[1] then return rank[1].team, F.gap(rank[1]) end
end

-- Who throws next, or nil when the round (mène) is over.
function P.next_team()
  local l = P.left
  if l[1] == 0 and l[2] == 0 then return nil end
  local holder = P.holder()
  if not holder then return l[P.starter] > 0 and P.starter or 3 - P.starter end
  local other = 3 - holder
  return l[other] > 0 and other or holder
end

-- The round's points: the winner's boules nearer the jack than the loser's best.
function P.count()
  local rank = F.ranking()
  if not rank[1] then return nil, 0 end
  local w = rank[1].team
  local n = 0
  for _, b in ipairs(rank) do
    if b.team ~= w then break end
    n = n + 1
  end
  return w, n
end

-- The two nearest boules of different teams, if a tape is needed to tell them apart (within 3 cm).
function P.close_call()
  local rank = F.ranking()
  local a = rank[1]
  if not a then return end
  for i = 2, #rank do
    local b = rank[i]
    if b.team ~= a.team then
      if F.gap(b) - F.gap(a) < 3 * F.CM then return a, b end
      return
    end
  end
end

return P
