-- What is drawn over the square at full resolution (480x320): the scoreboard, the shot, the mark on the sauló,
-- the swing and the breath, signs, the tape when it is close, and the cards before and after.

local F = require("fisica")
local lang = require("lang")
local C = require("campo")
local T = require("tiro")
local P = require("partida")

local U = {}

local INK, PAPER, SHADOW = 0xFFF4DC, 0x2A1E18, 0x000000
local TEAM = {0xE8EEF6, 0xFF8A50}
local board = {font = "marcador", color = INK, outline = PAPER}
local big = {font = "gran", color = 0xFFE7A0, gradient = 0xFFB040, outline = PAPER, shadow = SHADOW, align = "center"}

U.sign, U.sign_timer, U.sign_colour = nil, 0, INK

function U.say(words, ticks_shown, colour)
  U.sign, U.sign_timer, U.sign_colour = words, ticks_shown or 90, colour or INK
end

-- Text with a ring round each letter is dear to draw on the console: panels and signs are drawn once on a canvas,
-- again only when what they say changes, and the canvas is shown every frame.
local drawn = {}
local function cached(id, w, h, key, paint)
  if drawn[id] ~= key then
    canvas(id, w, h)
    target(id)
    paint()
    target()
    drawn[id] = key
  end
end

local function dots(x, y, n, colour, right)
  for i = 0, P.per - 1 do
    local cx = right and x - i * 12 or x + i * 12
    if i < n then circ(cx, y, 4, colour) else circ(cx, y, 4, colour, false) end
  end
end

function U.scoreboard()
  local key = table.concat({P.score[1], P.score[2], P.left[1], P.left[2], P.names[1], P.names[2]}, " ")
  -- wide enough for the two names and the score between them (a pair's names are longer), in steps of 32: a canvas
  -- keeps its size
  local names = {P.names[1]:upper(), P.names[2]:upper()}
  local need = textw(names[1], board) + textw(names[2], board) + 110
  local w = math.max(200, (need + 31) // 32 * 32)
  local id = "HUD_MARCADOR" .. w
  cached(id, w, 44, key, function()
    local mid = w // 2
    panel(0, 0, w, 44)
    text(names[1], 10, 4, {font = "marcador", color = TEAM[1], outline = PAPER})
    text(tostring(P.score[1]), mid - 10, 2, {font = "gran", color = INK, outline = PAPER, align = "center"})
    text("·", mid, 4, board)
    text(tostring(P.score[2]), mid + 12, 2, {font = "gran", color = INK, outline = PAPER, align = "center"})
    text(names[2], w - 10, 4, {font = "marcador", color = TEAM[2], outline = PAPER, align = "right"})
    dots(14, 34, P.left[1], TEAM[1])
    dots(w - 14, 34, P.left[2], TEAM[2], true)
  end)
  img(id, 8, 6)
end

-- A challenge's scoreboard: one line in a panel, drawn again only when it changes.
function U.panel_text(words)
  cached("HUD_RETO", 260, 34, words, function()
    panel(0, 0, 260, 34)
    text(words, 130, 6, {font = "marcador", color = INK, outline = PAPER, align = "center"})
  end)
  img("HUD_RETO", 8, 6)
end

-- The mark: a ring on the ground, seen in perspective, every point projected.
function U.mark()
  local mx, my = T.mark()
  local pts, ok = {}, true
  for i = 0, 15 do
    local a = i / 16 * math.pi * 2
    local sx, sy, _, vis = C.screen(mx + math.cos(a) * 8, my + math.sin(a) * 8, 0)
    if not vis then ok = false end
    pts[#pts + 1] = {sx * 2, sy * 2}
  end
  if not ok then return end
  local shot = F.SHOTS[T.shot]
  local colour = shot.direct and 0xFF6A4A or 0xFFF0B0
  for i = 1, 16, 2 do
    local p, q = pts[i], pts[i % 16 + 1]
    line(p[1], p[2] + 1, q[1], q[2] + 1, PAPER)
    line(p[1], p[2], q[1], q[2], colour)
  end
  local cx, cy = C.screen(mx, my, 0)
  cx, cy = cx * 2, cy * 2
  line(cx - 4, cy, cx + 4, cy, colour)
  local top = cy - 18 - math.floor(math.abs(math.sin(ticks() / 10)) * 5)  -- a little arrow over it, bobbing
  tri(cx - 6, top - 1, cx + 6, top - 1, cx, top + 9, PAPER)
  tri(cx - 4, top, cx + 4, top, cx, top + 6, colour)
end

function U.shot()
  local shot = F.SHOTS[T.shot]
  cached("HUD_TIRO", 212, 56, shot.id, function()
    panel(0, 0, 212, 56)
    text(lang.tr("shot_" .. shot.id), 10, 6, {font = "marcador", color = shot.direct and 0xFF8A6A or INK, outline = PAPER})
    text(lang.tr("shot_help"), 12, 26, {font = "main", color = 0xC8B8A0, outline = PAPER})
  end)
  img("HUD_TIRO", 8, 258)
end

function U.swing()
  local x, y, w = 200, 300, 180
  if T.state == "barrido" or T.state == "atras" then
    rect(x, y, w, 10, PAPER)
    rect(x + w / 2 - 12, y + 1, 24, 8, 0x5FBF5A)
    local nx = x + (T.needle + 1) / 2 * w
    rect(nx - 2, y - 4, 4, 18, INK)
  end
  -- the breath: a small bar by the hand
  local bx, by = 452, 210
  rect(bx, by, 10, 64, PAPER)
  local h = math.floor(62 * T.breath)
  rect(bx + 1, by + 63 - h, 8, h, T.out_of_breath and 0xD04A3A or 0x8FD0F0)
end

-- A tape from the jack to two boules, and how far each is.
function U.tape(a, b)
  local jack = F.jack()
  local jx, jy = C.screen(jack.x, jack.y, 0)
  local LABEL_H = 14
  local ys = {}
  for i, bl in ipairs({a, b}) do
    local x, y = C.screen(bl.x, bl.y, 0)
    line(jx * 2, jy * 2, x * 2, y * 2, 0xF0D040)
    ys[i] = y * 2 + 8
    -- two boules close together would print their distances on top of each other: the second drops below the first
    if i == 2 and math.abs(ys[2] - ys[1]) < LABEL_H then ys[2] = ys[1] + LABEL_H end
    local cm = string.format("%.1f cm", F.gap(bl, jack) / F.CM):gsub("%.", ",")
    text(cm, x * 2, ys[i], {font = "marcador", color = TEAM[bl.team], outline = PAPER, align = "center"})
  end
end

function U.tick()
  if U.sign_timer > 0 then U.sign_timer = U.sign_timer - 1 end
end

function U.signs()
  if U.sign and U.sign_timer > 0 then
    local style = {font = "gran", color = U.sign_colour, outline = PAPER, shadow = SHADOW}
    -- the canvas only as wide as the words (less to copy every frame), in steps of 32: a canvas keeps its size
    local w = math.min(SCREEN_W, (textw(U.sign, style) + 12 + 31) // 32 * 32)
    local id = "HUD_CARTEL" .. w
    cached(id, w, 36, U.sign .. U.sign_colour, function() text(U.sign, w // 2, 4, {font = "gran", align = "center",
      color = U.sign_colour, outline = PAPER, shadow = SHADOW}) end)
    img(id, (SCREEN_W - w) // 2, 66)
  end
end

function U.card(lines, portrait, mood)
  shade(0, 0, SCREEN_W, SCREEN_H)
  panel(40, 70, 400, 180)
  if portrait then img(portrait, 60, 92) end
  local x, y = portrait and 204 or 70, 92
  for _, l in ipairs(lines) do
    local _, h = text(l.text, x, y, {font = l.font or "main", color = l.color or INK, outline = PAPER, width = 220})
    y = y + h + 8
  end
end

function U.title(words, sub)
  text(words, SCREEN_W // 2, 120, big)
  if sub then text(sub, SCREEN_W // 2, 160, {font = "marcador", color = INK, outline = PAPER, align = "center"}) end
end

return U
