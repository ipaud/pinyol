-- The square seen through Remei's eyes: the pitch in Mode 7 (BG2), the houses round it (BG3, a bitmap that turns),
-- the sky by lines, and the boules, the jack and their shadows as sprites drawn at the size their distance asks for.

local F = require("fisica")
local SIZES = require("sizes")
local paleta = require("paleta")
local juice = require("juice")

local C = {}

C.HORIZON = 44
C.FOV = 257                  -- pixels a map unit is wide at one unit away: about 50 degrees across
C.EYE = 60                   -- Remei's eyes, 1.5 m up
local PANO_CENTER, PX_PER_DEG = 512, 4.5
local EX_BOULE, EX_JACK = 1.6, 2.2   -- drawn bigger than life, or they would be two pixels across from the circle

C.cam = {x = 256, y = 950, h = C.EYE, a = 0, fov = C.FOV}
C.goal = {x = 256, y = 950, h = C.EYE, a = 0, fov = C.FOV, k = 0.1}

local sheets = {}
C.hand = {on = false, frame = 0, x = 112, y = 66}

-- A place to throw (terrenos.lua): its floor, its view, its sky, and Remei's hands of that time.
function C.init(t, hands)
  C.terrain = t
  sheets.hand = sheet(hands or "MANOS")
  sheets.hands = {[hands or "MANOS"] = sheets.hand}
  sheets[1] = sheet("BOLA_REMEI")
  sheets[2] = sheet("BOLA_QUIM")
  sheets.jack = sheet("BOLICHE")
  sheets.shadow = sheet("SOMBRA")
  sheets.tin = sheet("LATA")
  bg(2, {map = t.map, mode = "affine", prio = 1, wrap = false})
  bg(3, {image = t.view, prio = 2, wrap = false})  -- 64 rows: below them the backdrop is the ground's colour
  if t.sepia then
    paleta.sepia("OBJ", true, 1, 0.8)
    paleta.sepia(t.pal, false, 1, 0.55)
  elseif t.night then
    paleta.night("OBJ", true, 0.3, 1)   -- the boules and the hands stay readable
    paleta.night(t.pal, false, 0.9, 0.5)
  else
    palette("OBJ", true)
  end
  local top, hor, gr = t.sky.top, t.sky.horizon, t.ground
  for y = 0, H - 1 do  -- the sky by lines, darker above; below the horizon, the ground beyond the floor
    local k = math.min(y / C.HORIZON, 1)
    line_backdrop(y, y <= C.HORIZON and rgb(top[1] + (hor[1] - top[1]) * k, top[2] + (hor[2] - top[2]) * k,
                                            top[3] + (hor[3] - top[3]) * k) or rgb(gr[1], gr[2], gr[3]))
  end
  -- haze: the floor goes paler the nearer the horizon (a fade of BG2 whose amount follows the line: line_fx). The sepia
  -- night of 1983 has none: its colours are already turned
  local haze = t.sepia and 0 or t.haze or 5
  if haze > 0 then
    fade("light", BG2, 0)
    for y = 0, H - 1 do
      local d = math.max(0, y - C.HORIZON) / (H - 1 - C.HORIZON)   -- 0 at the horizon, 1 at the bottom of the screen
      line_fx(y, math.floor(haze * (1 - d) ^ 2 + 0.5))
    end
  end
  F.use(t)
  C.from_circle(F.CIRCLE.x, F.CIRCLE.y - 300, 1)
  C.snap()
  C.update()
end

-- Another pair of hands (doubles: Remei's, then Tina's), each sheet made once.
function C.set_hand(id)
  sheets.hands[id] = sheets.hands[id] or sheet(id)
  sheets.hand = sheets.hands[id]
end

function C.off()  -- leaving the pitch: no floor, no view, no sprites, no haze
  fx_off()
  line_off()
  bg(2)
  bg(3)
  spr_clear()
  C.hand.on = false
end

-- Where the camera should go: a table {x, y, h, a, fov}, reached a fraction k of the way each tick.
function C.aim(x, y, h, a, fov, k)
  local g = C.goal
  g.x, g.y, g.h, g.a, g.fov, g.k = x, y, h or C.EYE, a or 0, fov or C.FOV, k or 0.1
end

function C.snap()
  for _, f in ipairs({"x", "y", "h", "a", "fov"}) do C.cam[f] = C.goal[f] end
end

function C.update()
  local c, g = C.cam, C.goal
  for _, f in ipairs({"x", "y", "h", "a", "fov"}) do c[f] = c[f] + (g[f] - c[f]) * g.k end
  -- the floor's perspective is set here, not in draw: project() needs it every tick (the tests draw seldom).
  -- A blow on the pitch jolts the eyes (juice.trauma, from juego.lua): a step aside, a nod, a turn of the head
  local jx, jy, ja = juice.offset()
  local a = c.a + ja * 2
  mode7(2, c.x + jx * 0.3, c.y, a, c.h + jy * 0.15, C.HORIZON, c.fov)
  scroll(3, PANO_CENTER - W / 2 + a * PX_PER_DEG, 0)
  for _, b in ipairs(F.bodies) do  -- a boule just let go catches up with its own path
    if b.ox then
      b.ox, b.oy = b.ox * 0.8, b.oy * 0.8
      if math.abs(b.ox) + math.abs(b.oy) < 1 then b.ox, b.oy = nil, nil end
    end
  end
end

-- Where, on the 240-wide picture, a point of the panorama stands: its azimuth in degrees from the north (a bonfire).
function C.pano_x(azimuth)
  return W / 2 + (azimuth - C.cam.a) * PX_PER_DEG
end

-- The camera standing in the circle, turned towards a point on the pitch.
function C.from_circle(tx, ty, k, fov)
  local a = math.deg(math.atan(tx - F.CIRCLE.x, F.CIRCLE.y - ty))
  C.aim(F.CIRCLE.x, F.CIRCLE.y + 6, C.EYE, a * 0.8, fov, k)
end

-- A map point at height z: where it shows (world pixels), how many pixels a unit is there, and whether it is in view.
function C.screen(x, y, z)
  local sx, sy, scale, vis = project(2, x, y)
  return sx, sy - (z or 0) * scale, scale, vis
end

-- The frame whose size is nearest each whole diameter, worked out once (a loop per boule per frame is dear in Lua).
local nearest = {}
for _, list in ipairs({SIZES.boule, SIZES.boliche, SIZES.lata}) do
  local t = {}
  for d = 0, list[#list] + 8 do
    local best, bi = 1e9, 1
    for i, s in ipairs(list) do
      if math.abs(s - d) < best then best, bi = math.abs(s - d), i end
    end
    t[d] = bi - 1
  end
  nearest[list] = t
end

local function pick(list, d)
  local t = nearest[list]
  return t[math.max(0, math.min(#t, math.floor(d + 0.5)))]
end

-- A tin: standing, flying and turning, or lying on its side (a matrix turns it).
local function draw_tin(b, slot, mats)
  local sx, sy, scale, vis = C.screen(b.x, b.y, 0)
  if not vis or sy > H + 40 then return slot, mats end
  local h = F.H_TIN * scale * 1.3
  local list = SIZES.lata
  local f = pick(list, h)
  local cy = sy - (b.z + F.H_TIN * 0.5) * scale * 1.3
  if (b.knocked and mats < 31) or h > list[#list] + 2 then
    mats = mats + 1
    mat(mats, b.spin or 0, math.max(h, 1) / list[#list])
    spr(slot, sheets.tin, #list - 1, sx - SIZES.cell, cy - SIZES.cell, prio(1) | spr_mat(mats) | DOUBLE)
  else
    spr(slot, sheets.tin, f, sx - SIZES.cell // 2, cy - SIZES.cell // 2, prio(1))
  end
  return slot + 1, mats, sx, sy, h * 0.8
end

local function draw_body(b, slot, mats)
  if b.kind == "tin" then return draw_tin(b, slot, mats) end
  local ex = b.kind == "jack" and EX_JACK or EX_BOULE
  local sx, sy, scale, vis = C.screen(b.x, b.y, 0)
  if not vis or sy > H + 40 then return slot, mats end
  local d = 2 * b.r * scale * ex
  local cy = sy - (b.z + b.r * (ex - 1)) * scale
  local list = b.kind == "jack" and SIZES.boliche or SIZES.boule
  local cell = b.kind == "jack" and SIZES.jack_cell or SIZES.cell
  local sh = b.kind == "jack" and sheets.jack or sheets[b.team]
  local f = pick(list, d)
  local ox, oy = b.ox or 0, b.oy or 0   -- a boule just let go is still drawn by the hand, and catches up
  sx, cy = sx + ox, cy + oy
  if d > list[#list] + 2 and mats < 31 then  -- nearer than the biggest frame: the biggest, scaled up
    mats = mats + 1
    mat(mats, 0, d / list[#list])
    spr(slot, sh, #list - 1, sx - cell, cy - cell, prio(1) | spr_mat(mats) | DOUBLE)
  else
    spr(slot, sh, f, sx - cell // 2, cy - cell // 2, prio(1))
  end
  return slot + 1, mats, sx - ox, sy, d
end

-- Everything on the pitch, nearest first (sprite 0 is drawn over sprite 1); the hand over all of it.
function C.draw()
  local c = C.cam
  spr_clear()
  local slot, mats = 0, 0
  if C.hand.on then
    spr(0, sheets.hand, C.hand.frame, C.hand.x, C.hand.y, prio(0))
    slot = 1
  end
  local order = {}
  for _, b in ipairs(F.bodies) do
    if not b.dead then order[#order + 1] = {b = b, d = (b.x - c.x) ^ 2 + (b.y - c.y) ^ 2} end
  end
  table.sort(order, function(p, q) return p.d < q.d end)
  local shadows = {}
  for _, o in ipairs(order) do
    local sx, sy, d
    slot, mats, sx, sy, d = draw_body(o.b, slot, mats)
    if sx and slot < 120 then shadows[#shadows + 1] = {sx = sx, sy = sy, d = d} end
  end
  for _, s in ipairs(shadows) do
    local f = pick(SIZES.boule, s.d)
    spr(slot, sheets.shadow, f, s.sx - SIZES.cell // 2, s.sy - SIZES.cell // 2, prio(1))
    slot = slot + 1
  end
end

return C
