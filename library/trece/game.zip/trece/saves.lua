-- Between the game and the card: the game goes on calling store and stored.
--   local saves = require("saves")
--   saves.open()      first thing in _init
--   saves.update()    each tick: what failed is tried again
--   saves.failed()    true while something is not on the card: tell the player
-- Saves carry a version, and a save with none is version 1. One from a newer game is refused (SAVE_NEWER): it stays on
-- the card as it is and this game plays from memory. On the console a failed card write is not seen here, the engine
-- answers before it writes; a save too big or a value store cannot keep is.

local M = {}

local VERSION = 1
local RETRY_TICKS = 120
local FORGET = {}                                   -- stands for store(key, nil) among what is due
local card_store, card_stored = store, stored
local due, wait = {}, 0

local function put(key, value)
  if value == FORGET then value = nil end
  local ok, err = pcall(card_store, key, value)
  if not ok then log(err) end
  return ok
end

local function save(key, value)
  if not SAVE_NEWER and put(key, value) then
    due[key] = nil
  elseif value == nil then
    due[key] = FORGET
  else
    due[key] = value
  end
end

local function read(key, default)
  local value = due[key]
  if value == FORGET then return default end
  if value ~= nil then return value end
  if SAVE_NEWER then return default end
  return card_stored(key, default)
end

function M.open()
  local version = card_stored("version")
  SAVE_NEWER = type(version) == "number" and version > VERSION
  store, stored = save, read
  if not SAVE_NEWER and version ~= VERSION then store("version", VERSION) end
end

function M.update()
  if SAVE_NEWER or next(due) == nil then return end
  wait = wait + 1
  if wait < RETRY_TICKS then return end
  wait = 0
  for key, value in pairs(due) do
    if put(key, value) then due[key] = nil end
  end
end

function M.failed() return not SAVE_NEWER and next(due) ~= nil end

return M
