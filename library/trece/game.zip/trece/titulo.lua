-- The title: the square at the end of the afternoon, the camera turning slowly; TRECE's logo falls like a boule
-- and clacks; then the menu (with the difficulty).

local C = require("campo")
local lang = require("lang")
local D = require("dificultad")
local flujo = require("flujo")
local TERRENOS = require("terrenos")

local M = {}
local timer, sel, items = 0, 1, {}
local args = {}
local LOGO_W, LOGO_H, LOGO_Y = 340, 167, 6   -- the logo (art/logo.png, made with an image model): where it comes to rest
local landed = {}

local function bounce(p)  -- out_bounce: falls and bounces twice, as a boule on the sauló
  if p < 1 / 2.75 then return 7.5625 * p * p
  elseif p < 2 / 2.75 then p = p - 1.5 / 2.75; return 7.5625 * p * p + 0.75
  elseif p < 2.5 / 2.75 then p = p - 2.25 / 2.75; return 7.5625 * p * p + 0.9375
  else p = p - 2.625 / 2.75; return 7.5625 * p * p + 0.984375 end
end

local function difficulty_label()
  return lang.tr("dif_label", {name = lang.tr(D.get().key)})
end

function M.enter(a)
  args, timer, sel, landed = a or {}, 0, 1, {}
  C.init(TERRENOS.plaza)
  C.aim(256, 760, 70, -20, C.FOV, 1)
  C.snap()
  items = {{id = "nueva", text = lang.tr("title_new")}}
  if flujo.saved() > 1 then table.insert(items, 1, {id = "seguir", text = lang.tr("title_continue")}) end
  items[#items + 1] = {id = "rapida", text = lang.tr("title_quick")}
  items[#items + 1] = {id = "dificultad", text = difficulty_label()}
end

function M.leave() C.off() end

function M.update()
  timer = timer + 1
  C.aim(256, 760, 70, -20 + math.sin(timer / 300) * 18, C.FOV, 0.02)
  C.update()
  if timer > 110 then
    if btnp("up") then sel = (sel - 2) % #items + 1 end
    if btnp("down") then sel = sel % #items + 1 end
    if btnp("a") then
      local it = items[sel]
      if it.id == "dificultad" then D.next(); it.text = difficulty_label() else args.pick(it.id) end
    end
  elseif btnp("a") then
    timer = 110
  end
end

function M.draw()
  C.draw()
  local p = math.max(0, math.min(1, (timer - 10) / 44))   -- the logo falls like a boule, and clacks
  if p >= 1 and not landed[1] then landed[1] = true; sfx("CLAC", 0.6) end
  if p > 0 then img("LOGO", (SCREEN_W - LOGO_W) // 2, math.floor(-LOGO_H + (LOGO_Y + LOGO_H) * bounce(p))) end
  if timer > 90 then
    text(lang.tr("title_sub"), SCREEN_W // 2, 170, {font = "marcador", color = 0xFFF4DC, outline = 0x2A1E18,
                                                         align = "center"})
  end
  if timer > 110 then
    for i, it in ipairs(items) do
      local on = i == sel
      text((on and "> " or "  ") .. it.text, SCREEN_W // 2, 196 + (i - 1) * 26,
           {font = "marcador", color = on and 0xFFE070 or 0xE8DCC8, outline = 0x2A1E18, align = "center"})
    end
    if SAVE_NEWER then
      text(lang.tr("save_newer"), SCREEN_W // 2, 294, {font = "marcador", color = 0xFFE070, outline = 0x2A1E18, align = "center"})
    end
  end
end

return M
