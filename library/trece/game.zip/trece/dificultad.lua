-- How hard the game is, chosen on the title and kept: what the rivals' errors and Remei's tremor are multiplied by.
--   local D = require("dificultad")
--   D.get().rival, D.get().tremor     the level in use
--   D.next()                          the next level (a circle), saved; returns it

local D = {}

D.levels = {
  {id = "easy", key = "dif_easy", rival = 1.5, tremor = 0.6},     -- rivals miss more, the hand shakes less
  {id = "normal", key = "dif_normal", rival = 1, tremor = 1},
  {id = "hard", key = "dif_hard", rival = 0.7, tremor = 1.25},    -- rivals are nearer to Ximo, the hand shakes more
}

function D.index()
  local i = stored("dificultad")
  return D.levels[i] and i or 2
end

function D.get() return D.levels[D.index()] end

function D.next()
  local i = D.index() % #D.levels + 1
  store("dificultad", i)
  return D.levels[i]
end

return D
