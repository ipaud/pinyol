-- The credits: the cast and the thanks, rolling up over the night of the revetlla. A speeds them up; at the end the
-- scene calls done.
--   scene.go(creditos, {done = fn})

local lang = require("lang")

local K = {}

local LINES = {"credits_title", "credits_sub", "", "credits_with", "credits_remei", "credits_tina", "credits_rest",
               "credits_dogs", "", "credits_made", "credits_console", "credits_art", "", "credits_thanks"}
local SPACING, SPEED = 30, 0.5     -- pixels between lines, pixels a tick
local args, timer, y0 = {}, 0, 0

function K.enter(a)
  args, timer = a or {}, 0
  bg(2)
  bg(3, {image = "FONDO_REVETLLA", prio = 3, wrap = false})
  palette("OBJ", true)
  music("REVETLLA", 1500)   -- the song of the night comes back
  y0 = SCREEN_H + 20
end

function K.leave()
  bg(3)
  music()
end

function K.update()
  timer = timer + 1
  y0 = y0 - SPEED * ((AUTO or btn("a")) and 8 or 1)
  if y0 + #LINES * SPACING < -20 then args.done() end
end

function K.draw()
  shade(0, 0, SCREEN_W, SCREEN_H)
  for i, key in ipairs(LINES) do
    local y = math.floor(y0 + (i - 1) * SPACING)
    if key ~= "" and y > -40 and y < SCREEN_H + 10 then
      local title = i <= 2
      local style = title and {font = i == 1 and "gran" or "marcador", color = i == 1 and 0xFFE7A0 or 0xFFF4DC,
                               gradient = i == 1 and 0xFFB040 or nil, outline = 0x2A1E18, align = "center"}
                         or {font = "marcador", color = key == "credits_with" and 0xC8B8A0 or 0xFFF4DC, outline = 0x2A1E18,
                             align = "center"}
      text(lang.tr(key), SCREEN_W // 2, y, style)
    end
  end
end

return K
