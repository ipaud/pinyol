-- The places to throw: their floor (an affine map, one pixel 2.5 cm), the view round them, where the pitch's edges
-- and the circle are, how the ground slows a boule, and the light.

return {
  plaza = {
    map = "PISTA", pal = "WORLD", view = "PLAZA", pitch = {x0 = 176, y0 = 384, x1 = 336, y1 = 984},
    circle = {x = 256, y = 944}, mu = 0.06, keep = 1, bumps = 1, heat = true,
    sky = {top = {96, 150, 214}, horizon = {216, 230, 240}}, ground = {176, 168, 154},
  },
  patio = {  -- packed earth between whitewashed walls; the walls are the edges
    map = "PATIO", pal = "PATIOPAL", view = "PATIO_VISTA", pitch = {x0 = 40, y0 = 40, x1 = 216, y1 = 500}, circle = {x = 128, y = 470},
    mu = 0.08, keep = 0.9, bumps = 1.6,
    sky = {top = {110, 160, 220}, horizon = {226, 232, 236}}, ground = {150, 104, 70},
  },
  playa = {  -- sand: a boule lands and stays (high shots win here), lines drawn with a heel
    map = "PLAYA", pal = "PLAYAPAL", view = "PLAYA_VISTA", pitch = {x0 = 176, y0 = 384, x1 = 336, y1 = 984},
    circle = {x = 256, y = 944}, mu = 0.32, keep = 0.3, bumps = 0.6, ambient = "OLAS", heat = true,
    sky = {top = {70, 140, 222}, horizon = {200, 226, 244}}, ground = {226, 204, 152},
  },
  riera = {  -- the dry riverbed: stones that kick a boule aside; the light of the end of the afternoon
    map = "RIERA", pal = "RIERAPAL", view = "RIERA_VISTA", pitch = {x0 = 176, y0 = 384, x1 = 336, y1 = 984},
    circle = {x = 256, y = 944}, mu = 0.075, keep = 0.85, bumps = 3.5, ambient = "RIERA",
    sky = {top = {120, 120, 180}, horizon = {244, 190, 140}}, ground = {150, 142, 128},
  },
  revetlla = {  -- the night of Sant Joan, 2026: the square in blue, two bonfires at the edges, the crackers (juego.lua)
    map = "PISTA", pal = "WORLD", view = "PLAZA_NOCHE", pitch = {x0 = 176, y0 = 384, x1 = 336, y1 = 984},
    circle = {x = 256, y = 944}, mu = 0.06, keep = 1, bumps = 1, night = true, ambient = "GRILLOS", music = "REVETLLA",
    sky = {top = {8, 12, 36}, horizon = {96, 58, 70}}, ground = {34, 40, 62},
  },
  plaza83 = {  -- the night of Sant Joan, 1983: the same square, in sepia (paleta.lua turns the colours)
    map = "PISTA", pal = "WORLD", view = "PLAZA83", pitch = {x0 = 176, y0 = 384, x1 = 336, y1 = 984},
    circle = {x = 256, y = 944}, mu = 0.06, keep = 1, bumps = 0, sepia = true,  -- nothing left to chance tonight
    sky = {top = {14, 10, 8}, horizon = {70, 46, 26}}, ground = {58, 44, 30},
  },
}
