-- The game on the pitch, as a scene. A director (a coroutine) says what happens: a conversation, one throw, a whole
-- game, the jack put somewhere. Without one, games follow one another (the bench).
--
--   scene.go(juego, {terreno = "plaza", rival = "quim", goal = 7, director = function(api) ... end,
--                    done = function(result) ... end, knots = {medir = "cap2_medir"}})
--   api.talk(knot)  api.match() -> winner  api.throw() -> {gap, body}  api.jack(x, y)  api.wait(ticks)
--   api.say(words, ticks, colour)  api.round()  (a new round: no boules down, three each)
--   doubles = {partner = "Tina", rivals = {"quim", "paqui"}, per = 4, handicap = 1}: two against two, the pair taking
--   turns (handicap: what the rivals' errors are multiplied by)

local F = require("fisica")
local lang = require("lang")
local particles = require("particles")
local C = require("campo")
local T = require("tiro")
local R = require("rival")
local P = require("partida")
local U = require("hud")
local TERRENOS = require("terrenos")
local D = require("dificultad")
local juice = require("juice")

local J = {}

local args, director, request = {}, nil, nil
local state, timer = "director", 0
local thrower, flying = nil, nil
local roll_sound = nil
local measured = false
local plan = nil     -- the rival's next boule, decided when it is their turn (so the sign can say what they mean to do)
local fx = particles.new()   -- sparks where steel meets steel (full-resolution, over the picture)
local MAX_PARTICLES = 60                        -- each costs ~50 us of Lua on the board: a few bursts, not a storm
local looks = require("rng").new(0xF1A3)     -- fires and crackers: how many fly must not change a throw
local BONFIRES = {-22.2, 22.2}    -- where the two bonfires stand on the panorama (azimuths; tools/scenes.py plaza_noche)
local FLAME = {0xFFE080, 0xFF8030, 0x802010}
local CRACKERS = {{0xFFF0A0, 0xFF8030, 0x803020}, {0xA0F0FF, 0x4090FF, 0x203080}, {0xFFA0C0, 0xFF3070, 0x701030}}
local dog = {on = false, x = 0, y = 0, frame = 0, x0 = 0}   -- Llampet crossing the pitch (the night of the final)
local dog_done = false
local crack_in = 120     -- ticks to the next firecracker over the square
local rings = {}     -- where steel met steel: a ring runs over the picture from there ({x, y, t} in map units)
-- The face a rival wears when they win (the portraits each one has: only Quim shouts).
local TRIUMPH = {quim = "_GRITO", paqui = "_RISA", pol = "_BURLA", ximo = "_RISA"}
local INTENT = {arrima = "sign_arrima", tira = "sign_tira", boliche = "sign_boliche"}

local function go(s) state, timer = s, 0; _G.state = s end

-- Who throws a team's next boule. One against one it is always the same; in doubles the two of a team take turns, the
-- first the first boule, the partner the second.
local function who_throws(team)
  local d = args.doubles
  if not d then return team == 1 and (args.player or "Remei") or (args.rival or "quim") end
  local k = (P.per - P.left[team]) % 2 + 1
  if team == 1 then return k == 1 and "Remei" or d.partner end
  return d.rivals[k]
end

-- Doubles: the hands, the pulse and the sign of whoever throws now (Remei's tremble, Tina's do not).
local function take_turn()
  local name = who_throws(1)
  T.steady = name == "Tina"
  C.set_hand(name == "Tina" and "MANOS_TINA" or "MANOS")
  U.say(lang.tr("sign_turn", {name = name}), 50)
end

-- The director's side: each call waits (yields) until the game has done it.
local api = {}
function api.talk(knot) return coroutine.yield({"talk", knot}) end
function api.match() return coroutine.yield({"match"}) end
function api.throw() return coroutine.yield({"throw"}) end
function api.wait(n) return coroutine.yield({"wait", n}) end
function api.rival_throw(plan) return coroutine.yield({"rival_throw", plan}) end
function api.say(words, n, colour) U.say(words, n, colour) end
function api.round() P.new_mene() end
function api.place(kind, team, x, y) return F.place(kind, team, x, y) end
function api.remove(b) F.remove(b) end
function api.focus(x, y) args.focus = {x = x, y = y} end   -- where the camera looks when there is no jack
function api.shot(i) T.shot = i end
function api.hud(fn) args.hud = fn end                    -- a challenge's own scoreboard: fn() -> its line
function api.jack(x, y)
  local j = F.launch("jack", 0, x, y, x, y, F.SHOTS[1])
  j.state, j.z, j.vx, j.vy, j.vz = "rest", j.r, 0, 0, 0
  return j
end
api.F, api.P, api.T, api.C = F, P, T, C

local function default_director(a)
  while true do a.match() end
end

local function resume(...)
  if not director or coroutine.status(director) == "dead" then return end
  local ok, req = coroutine.resume(director, ...)
  if not ok then error(req, 0) end
  request = req
  if coroutine.status(director) == "dead" then
    request = nil
    if args.done then args.done() end
    return
  end
  local kind = req[1]
  if kind == "talk" then
    STORY:go(req[2])
    go("talk")
  elseif kind == "match" then
    P.new_match(TEST_GOAL or args.goal or 7, args.doubles and args.doubles.per)
    P.new_mene()
    measured = false
    C.from_circle(F.CIRCLE.x, F.CIRCLE.y - 300, 0.06)
    go("boliche")
  elseif kind == "throw" then
    thrower = 1
    T.bot = AUTO
    T.begin(F.jack() or args.focus)
    local j = F.jack() or args.focus
    if j then C.from_circle(j.x, j.y, 0.08) end
    go("jugador")
  elseif kind == "rival_throw" then
    thrower = 2
    local f = F.jack() or args.focus
    if f then C.from_circle(f.x, f.y, 0.08) end
    go("rival")
  elseif kind == "wait" then
    go("espera")
  end
end

function J.enter(a)
  args = a or {}
  C.init(TERRENOS[args.terreno or "plaza"], args.hands)
  R.handicap = D.get().rival * (args.doubles and args.doubles.handicap or 1)   -- the level, and the scene's own
  if args.doubles then
    local d = args.doubles
    P.names = {"Remei+" .. d.partner, R.people[d.rivals[1]].name .. "+" .. R.people[d.rivals[2]].name}
  else
    P.names = {args.player or "Remei", R.people[args.rival or "quim"].name}
  end
  P.new_match(TEST_GOAL or args.goal or 7, args.doubles and args.doubles.per)
  P.new_mene()
  T.state, C.hand.on = "fuera", false
  T.steady = args.player == "Tina"
  U.say(nil)
  local t = TERRENOS[args.terreno or "plaza"]
  fx = particles.new()
  crack_in = 120
  dog.on, dog_done = false, false
  local amb = t.ambient or (args.terreno == "plaza83" and "GRILLOS") or "CIGARRAS"
  -- read from the card now, behind the fade: the first blow or landing would stall the frame for 300 ms otherwise
  preload({sounds = {"RUEDA", "CLAC", "TOC", "GRAVA", "LATA_GOLPE", "SWING", "PETARDO", amb}})
  roll_sound = sfx("RUEDA", 0, {loop = true})
  ambient(amb, 0.25)
  if t.music then music(t.music, 1500) end   -- the revetlla has its song (tools/music.py), under the crowd
  director = coroutine.create(args.director or default_director)
  go("director")
  resume(api)
end

function J.leave()
  if roll_sound then sfx_stop(roll_sound) end
  if C.terrain and C.terrain.music then music() end
  C.off()
end

-- What happened on the sauló, heard and felt: steel on steel jolts the view by the blow (juice.trauma, campo.lua
-- reads it) and sends a ring over the picture from where it struck (shock, drawn below); a landing, a small jolt.
-- Sparks where steel meets steel (a soft light; plain squares for a player who wants less flashing). (x, y) in map units.
local function sparks(x, y, n)
  if #fx.list > MAX_PARTICLES then return end
  local sx, sy, _, vis = C.screen(x, y, 0)
  if not vis then return end
  local soft = not settings().reduce_flashing
  fx:burst(sx * 2, sy * 2 - 6, n, {speed = 3.2, angle = -90, spread = 200, gravity = 0.12, drag = 0.03, life = 22, size = 3,
                                   colours = {0xFFF0A0, 0xFF8030, 0x803020}, shape = soft and "glow" or "square"})
end

-- A night with bonfires: flames on the two fires and, now and then, a firecracker over the roofs (squares of colour,
-- not lights, for a player who wants less flashing).
-- a flame's particles cost the board dearly (two per tick per fire took the final from 59 to 49 fps on the board): one a tick
local function night_fx()
  if not (C.terrain and C.terrain.night) then return end
  if ticks() % 2 == 0 and #fx.list < MAX_PARTICLES then
    for _, az in ipairs(BONFIRES) do
      local x = C.pano_x(az) * 2
      if x > -20 and x < SCREEN_W + 20 then
        fx:burst(x + (looks:float() - 0.5) * 12, (C.HORIZON - 2) * 2, 1, {speed = 1.2, angle = -90, spread = 36,
                 life = 20, size = 4, colours = FLAME, shape = "square"})
        if ticks() % 12 == 0 then  -- the glow round the fire
          fx:burst(x, (C.HORIZON - 6) * 2, 1, {speed = 0, life = 18, size = 14, colours = {0xA04818, 0x301008}, shape = "glow"})
        end
      end
    end
  end
  crack_in = crack_in - 1
  if crack_in <= 0 then
    crack_in = 240 + looks:int(0, 200)
    if #fx.list < MAX_PARTICLES - 20 then
      local soft = not settings().reduce_flashing
      fx:burst(120 + looks:int(0, 240), 30 + looks:int(0, 50), soft and 18 or 10,
               {speed = 2.4, angle = -90, spread = 360, gravity = 0.04, drag = 0.03, life = 34, size = 2,
                colours = CRACKERS[looks:int(#CRACKERS)], shape = soft and "glow" or "square"})
      sfx("PETARDO", 0.25)
    end
  end
end

local function sounds()
  for _, e in ipairs(F.events) do
    if e.kind == "clac" then
      sfx("CLAC", 0.25 + 0.75 * e.gain)
      juice.trauma(0.15 + 0.35 * e.gain)
      if #rings < 4 then rings[#rings + 1] = {x = e.x, y = e.y, t = 0} end
      if e.gain > 0.5 then sparks(e.x, e.y, 5) end
    elseif e.kind == "toc" then sfx("TOC", 0.3 + 0.7 * e.gain) juice.trauma(0.08)
    elseif e.kind == "land" then sfx("GRAVA", 0.3 + 0.7 * e.gain) juice.trauma(0.04 + 0.1 * e.gain)
    elseif e.kind == "tin" then
      sfx("LATA_GOLPE", 0.4 + 0.6 * e.gain)
      juice.trauma(0.2 + 0.2 * e.gain)
      if #rings < 4 then rings[#rings + 1] = {x = e.x, y = e.y, t = 0} end
    elseif e.kind == "wall" and e.gain > 0.2 then sfx("TOC", 0.3 * e.gain) end
  end
  local fastest = 0
  for _, b in ipairs(F.bodies) do
    if b.state == "roll" then fastest = math.max(fastest, math.sqrt(b.vx * b.vx + b.vy * b.vy)) end
  end
  if roll_sound then sfx_set(roll_sound, {gain = math.min(0.5, fastest * 0.35), pitch = 0.8 + math.min(fastest, 2) * 0.2}) end
end

-- The camera after a thrown boule: behind it and low, further back the higher it flies.
local function follow(b)
  if timer < 16 then return end
  local dx, dy = b.x - F.CIRCLE.x, b.y - F.CIRCLE.y
  local n = math.max(math.sqrt(dx * dx + dy * dy), 1)
  local back = 90 + (b.state == "air" and b.z * 0.9 or 0)
  local cy = math.min(b.y - dy / n * back, F.CIRCLE.y + 6)
  C.aim(b.x - dx / n * back, cy, 38, math.deg(math.atan(dx, -dy)), C.FOV, 0.07)
end

-- Low, by the jack (or what a challenge looks at), looking up the pitch: who holds the point?
local function look_at_jack(k)
  local j = F.jack() or args.focus
  if j then C.aim(j.x, math.min(j.y + 90, F.CIRCLE.y), 16, 0, C.FOV, k or 0.06) end
end

-- After a shot that struck a boule: did the shooter's boule take its place? (moved it 50 cm, stayed within 20)
local function carreau()
  local h = F.last_hit
  if not h or not flying or h.shooter ~= flying then return false end
  local moved = math.sqrt((h.target.x - h.x) ^ 2 + (h.target.y - h.y) ^ 2)
  local stay = math.sqrt((flying.x - h.x) ^ 2 + (flying.y - h.y) ^ 2)
  return moved > 20 and stay < 8, moved, stay
end
J.carreau = carreau
J.particles = function() return #fx.list end  -- (the tests count them)
J.sparks = function(x, y, n) sparks(x, y, n) end
J.dog_seen = function() return dog_done end  -- (the tests ask)
J.rings = rings  -- (the tests put rings on the picture)

local function carreau_made()  -- said, and the player's kept by the console
  U.say(lang.tr("sign_carreau"), 100, 0xFFD040)
  local h = F.last_hit
  if h then sparks(h.x, h.y, 14) end
  C.cam.fov = C.cam.fov * 1.14   -- a punch in: the view eases back to its own fov (campo.lua)
  if flying and flying.team == 1 then achieve("carreau") end
end

local function throw_next()
  thrower = P.next_team()
  if not thrower then go("fin_mano"); return end
  if thrower == 1 then
    if args.doubles then take_turn() end
    T.bot = AUTO
    T.begin()
    go("jugador")
  else
    go("rival")
  end
  local j = F.jack()
  C.from_circle(j.x, j.y, 0.08)
end

local function after_flight()
  if carreau() then carreau_made() ; return go("mira") end
  local holder = P.holder()
  local a = P.close_call()
  if a then
    go("medir")
    U.say(lang.tr("sign_measure"), 90, 0xF0D040)
  else
    go("mira")
    if holder then
      U.say(holder == 1 and lang.tr("sign_you_point") or lang.tr("sign_they_point", {name = P.names[2]}), 90,
            holder == 1 and 0x9AF07A or 0xFF8A50)
    end
  end
end

-- After a single throw asked by the director: how close it stopped, what it struck.
local function throw_result()
  local j = F.jack()
  local b = flying or T.last
  local c, moved, stay = carreau()
  return {gap = (j and b) and F.gap(b, j) / F.CM or nil, body = b, carreau = c, hit = F.last_hit ~= nil and
          F.last_hit.shooter == b, moved = moved, stay = stay}
end

local function update_match()
  if state == "boliche" then
    if timer == 30 then
      flying = P.throw_jack()
      U.say(lang.tr("sign_throws_jack", {name = P.names[P.starter]}), 70)
      go("vuelo")
    end
  elseif state == "jugador" then
    local j = F.jack()
    local mx, my = T.mark()
    local tx, ty = j and (mx * 0.5 + j.x * 0.5) or mx, j and (my * 0.5 + j.y * 0.5) or my
    -- far away, Remei puts her glasses on: the view closes in on the mark
    C.from_circle(tx, ty, 0.08, math.min(520, math.max(C.FOV, C.FOV * T.dist / 220)))
    local b = T.update()
    if b then
      P.left[1] = math.max(0, P.left[1] - 1)
      flying = b
      go("vuelo")
    end
  elseif state == "rival" then
    if timer == 1 then  -- the rival makes up their mind, and the sign says what they mean to do
      local forced = request and request[1] == "rival_throw" and request[2]
      plan = forced or R.plan(who_throws(2), thrower, P.left[thrower])
      plan.forced = forced and true or false
      U.say(lang.tr(INTENT[plan.what] or INTENT.tira, {name = R.people[who_throws(2)].name}), 60, 0xFF8A50)
    end
    if timer >= (AUTO and 20 or 70) then
      flying = R.throw(plan, thrower)
      if not plan.forced then P.left[thrower] = P.left[thrower] - 1 end
      go("vuelo")
    end
  elseif state == "vuelo" then
    T.follow()
    F.step(F.terrain)
    if btn("a") and timer > 30 and T.state == "fuera" then F.step(F.terrain); F.step(F.terrain) end  -- A: faster
    sounds()
    if flying then follow(flying) end
    if timer > 20 and not F.moving() then
      look_at_jack()
      if flying and flying.kind == "jack" then
        U.say(lang.tr("sign_jack_at", {m = (string.format("%.1f", (F.CIRCLE.y - flying.y) * 0.025):gsub("%.", ","))}), 70)
        go("mira")
      elseif request and (request[1] == "throw" or request[1] == "rival_throw") then
        if carreau() then carreau_made() end
        go("mira")
      else
        after_flight()
      end
    end
  elseif state == "mira" or state == "medir" then
    sounds()
    local wait = state == "medir" and 150 or 80
    if timer > wait or (timer > 20 and btnp("a")) or (AUTO and timer > 10) then
      if state == "medir" and P.holder() == 1 then achieve("milimetro") end  -- the tape gave it to the player
      if request and (request[1] == "throw" or request[1] == "rival_throw") then
        go("director")
        resume(throw_result())
      elseif state == "medir" and not measured and args.knots and args.knots.medir then
        measured = true
        STORY:go(args.knots.medir)
        go("talk_medir")
      elseif args.dog and not dog_done and P.mene >= args.dog.mene and F.jack() and #F.ranking() >= 2 then
        dog_done = true  -- Llampet crosses the pitch, once
        go("perro")
      else
        throw_next()
      end
    end
  elseif state == "perro" then
    -- Llampet trots in from the left, sniffs by the jack, brushes it with his nose and goes on to the right
    local j = F.jack()
    if timer == 1 then dog.on, dog.x0, dog.y, dog.frame = true, j.x - 90, j.y + 10, 0 end
    look_at_jack(0.05)
    sounds()
    if timer <= 120 then
      dog.x, dog.frame = dog.x0 + timer * 0.65, (timer // 6) % 4
    elseif timer <= 200 then
      dog.frame = 4
      if timer == 160 then j.x, j.y = j.x + 1.2, j.y - 0.6 end   -- a centimetre or two: it is enough
    elseif timer <= 330 then
      dog.x, dog.frame = dog.x0 + 78 + (timer - 200) * 0.8, (timer // 5) % 4
    else
      dog.on = false
      STORY:go(args.dog.knot)
      go("talk_medir")
    end
  elseif state == "fin_mano" then
    if timer == 1 then
      local w, n = P.count()
      if w then
        P.score[w] = P.score[w] + n
        log(string.format("mano %d: +%d %s -> %d-%d (%d ticks)", P.mene, n, P.names[w], P.score[1], P.score[2], ticks()))
        U.say(string.format("+%d %s", n, P.names[w]), 120, w == 1 and 0x9AF07A or 0xFF8A50)
        P.starter = w
      end
      look_at_jack(0.04)
    end
    if timer > (AUTO and 20 or 150) then
      if P.score[1] >= P.goal or P.score[2] >= P.goal then
        go("fin")
      else
        P.new_mene()
        C.from_circle(F.CIRCLE.x, F.CIRCLE.y - 300, 0.06)
        go("boliche")
      end
    end
  elseif state == "fin" then
    if timer == 1 then
      MATCHES = (MATCHES or 0) + 1
      if P.score[1] >= P.goal and P.score[2] == 0 then achieve("siete_cero") end
    end
    if timer > (AUTO and 30 or 60) and (AUTO or btnp("a")) then
      log(string.format("bench: match over %d-%d", P.score[1], P.score[2]))
      go("director")
      resume(P.score[1] >= P.goal and 1 or 2)
    end
  end
end

function J.update()
  timer = timer + 1
  if state == "talk" or state == "talk_medir" then
    story_step()
    if STORY:update() == "done" or not STORY:running() then
      if state == "talk_medir" then throw_next() else go("director"); resume() end
    end
  elseif state == "espera" then
    if timer >= request[2] then go("director"); resume() end
  elseif state ~= "director" then
    update_match()
  end
  C.update()
  night_fx()
  fx:update()
  U.tick()
end

function J.draw()
  C.draw()
  if C.terrain and C.terrain.heat then  -- the summer's heat: only the far sauló shimmers; further up it bent windows and walls into wedges
    haze(C.HORIZON, C.HORIZON + 10, 1, t() * 4, 7)
  end
  fx:draw()
  if dog.on then  -- Llampet, at the size the pitch's perspective gives a dog of 60 cm, in the night's blue
    local sx, sy, scale, vis = C.screen(dog.x, dog.y, 0)
    if vis then img("PERRO_P", math.floor(sx * 2 - 24 * scale), math.floor(sy * 2 - 34 * scale), {frame = dog.frame, scale = scale, mul = 0x98A4D4}) end
  end
  for i = #rings, 1, -1 do  -- the rings of the blows, running outwards and fading over sixteen frames
    local r = rings[i]
    local sx, sy, _, vis = C.screen(r.x, r.y, 0)
    if vis then shock(sx, sy, 3 + r.t * 2.5, 6, 4 * (1 - r.t / 16)) end
    r.t = r.t + 1
    if r.t >= 16 then table.remove(rings, i) end
  end
  if NOHUD then return end
  if args.hud then U.panel_text(args.hud())
  elseif request and request[1] == "match" or state == "fin_mano" then U.scoreboard() end
  if state == "jugador" then
    if T.state == "apunta" or T.state == "atras" or T.state == "barrido" then U.mark() end
    U.shot()
    U.swing()
  elseif state == "medir" then
    local a, b = P.close_call()
    if a then U.tape(a, b) end
  elseif state == "fin" then
    local won = P.score[1] > P.score[2]
    local rival = args.rival or (args.doubles and args.doubles.rivals[1]) or "quim"
    local face = "RET_" .. rival:upper()
    U.card({{text = won and lang.tr("end_win") or lang.tr("end_lose", {name = P.names[2]}), font = "gran", color = won and 0x9AF07A or 0xFF8A50},
            {text = string.format("%s %d · %d %s", P.names[1], P.score[1], P.score[2], P.names[2]), font = "marcador"},
            {text = lang.tr("end_next"), color = 0xC8B8A0}}, face .. (won and "_NORMAL" or TRIUMPH[rival]))
    return
  end
  U.signs()
  if state == "talk" or state == "talk_medir" then STORY:draw() end
end

J.api = api
return J
