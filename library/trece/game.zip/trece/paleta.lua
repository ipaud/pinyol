-- Colours turned by code: a palette of the game read from its file and set again in sepia, darker for a night, or
-- part of the way back to its own colours (a memory fading into today).

local M = {}

local function read(name)  -- assets/<name>.pal: RGB565 colours, little-endian, entry 0 see-through
  local data = file("assets/" .. name .. ".pal")
  local out = {}
  if not data then return out end
  for i = 1, #data - 1, 2 do
    local v = string.unpack("<I2", data, i)
    out[#out + 1] = {((v >> 11) & 31) * 255 // 31, ((v >> 5) & 63) * 255 // 63, (v & 31) * 255 // 31}
  end
  return out
end

local cache = {}

-- k = 0: the palette's own colours; k = 1: all sepia, times the light (night: below 1).
function M.sepia(name, obj, k, light)
  cache[name] = cache[name] or read(name)
  light = light or 1
  for i, c in ipairs(cache[name]) do
    if i > 1 then
      local l = (c[1] * 0.299 + c[2] * 0.587 + c[3] * 0.114) * light
      local s = {l * 1.12, l * 0.92, l * 0.66}
      local mix = function(j) return math.max(0, math.min(255, math.floor(c[j] + (s[j] - c[j]) * k))) end
      pal(i - 1, rgb(mix(1), mix(2), mix(3)), obj)
    end
  end
end

-- A blue night (a night with bonfires): k = 0 the palette's own colours, k = 1 all turned towards blue and darker.
function M.night(name, obj, k, light)
  cache[name] = cache[name] or read(name)
  light = light or 1
  for i, c in ipairs(cache[name]) do
    if i > 1 then
      local l = (c[1] * 0.299 + c[2] * 0.587 + c[3] * 0.114) * light
      local s = {l * 0.62 + 8, l * 0.78 + 12, l * 1.15 + 30}
      local mix = function(j) return math.max(0, math.min(255, math.floor(c[j] + (s[j] - c[j]) * k))) end
      pal(i - 1, rgb(mix(1), mix(2), mix(3)), obj)
    end
  end
end

function M.restore(name, obj)
  palette(name, obj)
end

return M
