-- The rival: decides what to do with the next boule as that person would (lib/brain: each choice scored from the
-- facts of the moment, the best one taken), and throws it with that person's errors. No cheating: the same physics
-- as Remei, only the errors differ.

local F = require("fisica")
local T = require("tiro")
local brain = require("brain")
local D = require("dificultad")

local R = {}

R.people = {  -- how keen each one is to shoot or to push the jack, how true they point and shoot, where they stand
  quim = {name = "Quim", shoot = 0.3, push = 0.5, point = 0.045, aim = 0.022, side = -8},
  paqui = {name = "Paqui", shoot = 0.15, push = 0.2, point = 0.035, aim = 0.025, side = -8, shot = 3},   -- high shots on sand
  pol = {name = "Pol", shoot = 0.8, push = 0.3, point = 0.05, aim = 0.014, side = -8},                   -- a shooter
  ximo = {name = "Ximo", shoot = 0.6, push = 0.6, point = 0.04, aim = 0.016, side = -8},
}

R.handicap = 1  -- what a scene may multiply every rival's errors by (the final, against the best shots, is gentler); the level comes on top
R.last = nil  -- what the rival chose for the last boule: "arrima" (point), "tira" (shoot), "boliche" (push the jack)

-- The facts a player weighs: e.p who, e.left my boules, e.d the jack's distance from the circle, e.best their best
-- boule and e.gap its distance to the jack, e.mine my best's, e.push how many ends a push of the jack could turn
-- (mine lying beyond it while theirs lie before it).
local function facts(who, team, left)
  local jack = F.jack()
  local e = {p = R.people[who], team = team, left = left, jack = jack, push = 0}
  e.d = math.sqrt((jack.x - F.CIRCLE.x) ^ 2 + (jack.y - F.CIRCLE.y) ^ 2)
  local mine_beyond, theirs_before = 0, 0
  for _, b in ipairs(F.ranking()) do
    local beyond = (b.y - jack.y) * (F.CIRCLE.y - jack.y) < 0  -- past the jack, seen from the circle
    if b.team ~= team then
      if not e.best then e.best, e.gap = b, F.gap(b, jack) end
      if not beyond then theirs_before = theirs_before + 1 end
    else
      if not e.mine then e.mine = F.gap(b, jack) end
      if beyond then mine_beyond = mine_beyond + 1 end
    end
  end
  e.push = math.min(mine_beyond, theirs_before)
  e.holding = e.mine ~= nil and (e.gap == nil or e.mine < e.gap)  -- I hold the point (they are out of boules)
  return e
end

local choices = brain.new({
  arrima = {score = function(e)  -- point: the safe thing; better the farther their best is from the jack, with boules to spare
    local s = 0.45 + (e.gap and math.min(e.gap, 40) / 40 or 1) * 0.4
    if e.left >= 2 then s = s + 0.1 end
    return s
  end},
  tira = {score = function(e)  -- shoot their best: worth it when it sits by the jack, by someone who likes to; less sure far away
    if not e.best or e.holding or e.gap > 24 then return 0 end
    local s = 0.4 + e.p.shoot * 0.6 + (1 - e.gap / 24) * 0.3 - math.max(0, e.d - 320) / 400
    return s
  end, curve = "quad"},  -- (a shot almost not worth it is worth even less)
  boliche = {score = function(e)  -- push the jack towards mine: with mine beyond it and theirs before, and a boule hard to beat
    if e.push == 0 or e.holding or not e.best or e.gap > 12 then return 0 end
    return 0.3 + 0.4 * e.p.push + 0.1 * e.push
  end},
}, {stick = 0})

-- What to do with the next boule: {shot, x, y, sigma_across, sigma_along, side, what}.
function R.plan(who, team, left)
  local e = facts(who, team, left)
  local p, jack, d = e.p, e.jack, e.d
  local what = choices:think(e)
  R.last = what
  local ux, uy = (F.CIRCLE.x - jack.x) / d, (F.CIRCLE.y - jack.y) / d  -- from the jack towards the circle
  if what == "tira" then
    return {shot = F.SHOTS[4], x = e.best.x, y = e.best.y, across = p.aim * d * R.handicap, along = p.aim * d * 1.3 * R.handicap,
            side = p.side, what = what}
  elseif what == "boliche" then  -- rolling, to just past the jack: the boule arrives with speed and takes it along
    return {shot = F.SHOTS[1], x = jack.x - ux * 14, y = jack.y - uy * 14, across = p.point * d * 0.8 * R.handicap,
            along = p.point * d * R.handicap, side = p.side, what = what}
  end
  -- point: a little short of the jack, the side the boules come from ("better in front than behind")
  return {shot = F.SHOTS[p.shot or 2], x = jack.x + ux * 6, y = jack.y + uy * 6, across = p.point * d * R.handicap,
          along = p.point * d * 1.25 * R.handicap, side = p.side, what = what}
end

-- A shot at a given boule (the carreaux duel): its errors only.
function R.shoot_at(who, target)
  local p = R.people[who]
  local d = math.sqrt((target.x - F.CIRCLE.x) ^ 2 + (target.y - F.CIRCLE.y) ^ 2)
  R.last = "tira"
  local k = R.handicap
  return {shot = F.SHOTS[4], x = target.x, y = target.y, across = p.aim * d * k, along = p.aim * d * 1.3 * k, side = p.side, what = "tira"}
end

function R.throw(plan, team)
  return T.throw(team, plan.x, plan.y, plan.shot, T.gauss() * plan.across, T.gauss() * plan.along, plan.side)
end

return R
