-- Remei's throw: choose the shot (C), put the mark where the boule should stop (the d-pad), hold the breath (B)
-- against the tremor, then the swing (hold A, let go when the needle passes the middle).
-- Also the throw itself, shared with the rival: from the circle towards a point, with its errors.

local F = require("fisica")
local C = require("campo")
local D = require("dificultad")

local T = {}

T.state = "fuera"      -- fuera, entra, apunta, atras, barrido, suelta
T.shot = 2             -- index in F.SHOTS
T.dist, T.angle = 320, 0          -- where the mark is: units from the circle, degrees off the pitch's line
T.breath, T.shake = 1, 2.4        -- breath left (0..1), the tremor's size (units)
T.needle = -1                     -- the swing: -1 .. 1, the middle is a good throw
T.tx, T.ty = 0, 0                 -- the tremor right now
T.timer = 0
T.last = nil                      -- the body thrown last
T.out_of_breath = false
T.steady = false                  -- Tina: fifteen, steady hands, no tremor to fight
T.bot = false                     -- the bench: Remei throws by herself, with the hand and all
T.bot_at = 0
local bench = require("rng").new(0xBE7C) -- the bench's swing: a player's game draws nothing from here

local HAND_X, HAND_Y = 128, 70     -- where the hand rests (world pixels, the sheet's top-left corner)
local BOULE_IN_HAND = {40, 61}     -- the boule's centre inside the hand's frame
local REST, CALM, GASP = 2.4, 0.5, 4.5
local BACK_TICKS, SWEEP_TICKS = 18, 54
local LAT, LON = 26, 34            -- error at the needle's ends, in units, for a throw of 8 m

local function gauss()
  local u, v = math.max(math.random(), 1e-6), math.random()
  return math.sqrt(-2 * math.log(u)) * math.cos(2 * math.pi * v)
end
T.gauss = gauss

function T.mark()  -- where the boule should stop, tremor included (map units)
  local a = math.rad(T.angle)
  return F.CIRCLE.x + math.sin(a) * T.dist + T.tx, F.CIRCLE.y - math.cos(a) * T.dist + T.ty
end

-- A boule thrown from the circle by team towards (x, y), its errors given in units across and along the throw.
function T.throw(team, x, y, shot, across, along, side)
  local rx, ry = F.CIRCLE.x + (side or 3), F.CIRCLE.y - 20
  local dx, dy = x - rx, y - ry
  local d = math.sqrt(dx * dx + dy * dy)
  local ux, uy = dx / d, dy / d
  x, y = x + ux * along - uy * across, y + uy * along + ux * across
  d = math.sqrt((x - rx) ^ 2 + (y - ry) ^ 2)
  local land = F.landing_for(shot, d, F.R_BOULE)
  local b = F.launch("boule", team, rx, ry, rx + ux * land, ry + uy * land, shot)
  T.last = b
  return b
end

-- A new boule in the hand: it comes up from below. The mark starts on what there is to aim at (the jack, or a
-- challenge's target): just short of it to point, right on it to shoot.
function T.begin(target)
  T.state, T.timer, T.needle = "entra", 0, -1
  T.bot_at = (bench:float() - 0.5) * 0.16  -- the bench's Remei: a good swing, not a perfect one
  if T.bot and F.terrain and F.terrain.mu > 0.2 and T.shot ~= 4 then T.shot = 3 end  -- on sand she throws high
  local j = target or F.jack()
  if j then
    local dx, dy = j.x - F.CIRCLE.x, F.CIRCLE.y - j.y
    local short = F.SHOTS[T.shot].direct and 0 or 6
    T.dist = math.max(120, math.min(520, math.sqrt(dx * dx + dy * dy) - short))
    T.angle = math.max(-14, math.min(14, math.deg(math.atan(dx, dy))))
  end
  C.hand.on, C.hand.frame, C.hand.y = true, 0, HAND_Y + 100
end

local function tremor()
  local t = ticks() / 60
  local holding = btn("b") and not T.out_of_breath
  if holding and T.breath > 0 then
    T.breath = T.breath - 1 / 200
    T.shake = T.shake + (CALM - T.shake) * 0.08
    if T.breath <= 0 then T.out_of_breath = true end
  else
    if not btn("b") then T.out_of_breath = false end
    T.breath = math.min(1, T.breath + 1 / 150)
    local want = T.steady and CALM or T.out_of_breath and GASP or REST
    T.shake = T.shake + (want - T.shake) * 0.05
  end
  if T.steady then T.shake = math.min(T.shake, CALM) end
  local s = T.shake * D.get().tremor   -- the level: how much the hand shakes
  T.tx = s * (0.6 * math.sin(1.9 * t) + 0.3 * math.sin(4.7 * t + 1.3) + 0.25 * math.sin(11.3 * t + 0.4))
  T.ty = s * (0.6 * math.sin(1.4 * t + 2.1) + 0.3 * math.sin(5.3 * t + 0.2) + 0.25 * math.sin(9.7 * t + 2.9))
end

local function steer()
  local fast = function(b) return btnt(b) > 20 and 3 or 1 end
  if btn("left") then T.angle = math.max(-14, T.angle - 0.12 * fast("left")) end
  if btn("right") then T.angle = math.min(14, T.angle + 0.12 * fast("right")) end
  if btn("up") then T.dist = math.min(520, T.dist + fast("up")) end
  if btn("down") then T.dist = math.max(120, T.dist - fast("down")) end
  if btnp("c") then T.shot = T.shot % #F.SHOTS + 1 end
end

local function release()
  local shot = F.SHOTS[T.shot]
  local mx, my = T.mark()
  local k = T.dist / 320
  local n = T.needle
  local b = T.throw(1, mx, my, shot, n * LAT * k + gauss() * 1.2, n * LON * k + gauss() * 1.5)
  -- the boule starts where the hand held it, then joins its own path
  local sx, sy = C.screen(b.x, b.y, b.z)
  b.ox, b.oy = C.hand.x + BOULE_IN_HAND[1] - sx, C.hand.y + BOULE_IN_HAND[2] - sy
  T.state, T.timer = "suelta", 0
  C.hand.frame = 2
  sfx("SWING", 0.35)
  return b
end

-- One tick of Remei's turn. Returns the boule once it has left her hand.
function T.update()
  T.timer = T.timer + 1
  tremor()
  local hand = C.hand
  local jiggle = math.floor(T.tx * 0.25 + 0.5)
  if T.state == "entra" then
    hand.y = hand.y + (HAND_Y - hand.y) * 0.18
    if T.timer > 20 then T.state = "apunta" end
  elseif T.state == "apunta" then
    steer()
    hand.frame, hand.x = 0, HAND_X + jiggle
    hand.y = HAND_Y + math.floor(math.sin(ticks() / 25) * 1.5)
    if btnp("a") or (T.bot and T.timer > 40) then T.state, T.timer = "atras", 0; hand.frame = 1 end
  elseif T.state == "atras" then  -- the arm goes back: the hand drops out of sight
    hand.y = HAND_Y + math.floor(110 * (T.timer / BACK_TICKS) ^ 2)
    if not (btn("a") or T.bot) then T.state, hand.frame = "entra", 0; T.timer = 0
    elseif T.timer >= BACK_TICKS then T.state, T.timer, T.needle = "barrido", 0, -1 end
  elseif T.state == "barrido" then  -- the arm comes forward; the needle crosses
    T.needle = -1 + 2 * T.timer / SWEEP_TICKS
    hand.y = HAND_Y + 110 - math.floor(116 * (T.needle + 1) / 2)
    hand.x = HAND_X + jiggle
    if btnr("a") or (T.bot and T.needle >= T.bot_at) or T.timer >= SWEEP_TICKS then return release() end
  elseif T.state == "suelta" then  -- the hand opens, follows the boule up, then goes down
    if T.timer == 6 then hand.frame = 3 end
    if T.timer < 30 then hand.y = hand.y + (HAND_Y - 24 - hand.y) * 0.15
    else hand.y = hand.y + 4 end
    if T.timer > 60 then T.state, hand.on = "fuera", false end
  end
end

-- The rest of the throw goes on while the boule flies (the hand keeps moving out of sight).
function T.follow()
  if T.state == "suelta" then T.update() end
end

return T
