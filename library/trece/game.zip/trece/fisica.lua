-- The boules and the jack: flight, landing, rolling on the sauló, and steel hitting steel.
-- Units: one map pixel is 2.5 cm; time is in ticks (1/60 s). The pitch's sleepers are walls.

local F = {}

F.CM = 0.4                         -- units in a centimetre
F.G = 0.109                        -- 9.81 m/s2 in units per tick squared
F.R_BOULE, F.R_JACK = 1.5, 0.6     -- 3.75 cm and 1.5 cm
F.R_TIN, F.H_TIN = 1.3, 4.8        -- a soda tin: 3.3 cm round, 12 cm tall
F.PITCH = {x0 = 176, y0 = 384, x1 = 336, y1 = 984}
F.CIRCLE = {x = 256, y = 944}
F.MU = 0.06                        -- rolling on the sauló: how fast a boule slows, times G
local MAX_SUB = 4                  -- substeps a tick, so a fast shot does not pass through a boule
local looks = require("rng").new(0x71A1) -- how a tin turns as it flies: a look, it must not move the throws
local JITTER = 0.004               -- the gravel turns a rolling boule by a little, at random

-- Shots: the apex (units above the ground), the hand's height when it lets go, and how much of the speed is kept
-- when it lands. A shot "al hierro" flies to land on what it aims at.
F.SHOTS = {
  {id = "rodando", name = "Rodando", apex = 22, z0 = 16, keep = 0.85},
  {id = "media", name = "Media altura", apex = 60, z0 = 20, keep = 0.55},
  {id = "alta", name = "Alta", apex = 150, z0 = 24, keep = 0.22},
  {id = "hierro", name = "Al hierro", apex = 64, z0 = 36, keep = 0.45, direct = true},
}

-- The place: its pitch, its circle and how its ground rolls (terrenos.lua).
function F.use(t)
  F.PITCH, F.CIRCLE, F.MU = t.pitch, t.circle, t.mu
  F.terrain = {mu = t.mu, keep = t.keep, bumps = t.bumps}
end

F.bodies = {}
F.events = {}   -- what happened this tick, for the sounds and the feel: {kind = "clac" | "toc" | "land" | "wall" | "tin", gain, x, y}

function F.reset() F.bodies = {} end

local function new_body(kind, team, x, y)
  local b = {kind = kind, team = team, x = x, y = y, z = 0, vx = 0, vy = 0, vz = 0, state = "rest", dead = false,
             r = kind == "jack" and F.R_JACK or kind == "tin" and F.R_TIN or F.R_BOULE,
             m = kind == "jack" and 0.022 or kind == "tin" and 0.03 or 1, keep = 1, landed = false, spin = 0}
  b.z = kind == "tin" and 0 or b.r
  F.bodies[#F.bodies + 1] = b
  return b
end

-- A body put down at rest (a jack, a target boule, a tin): no flight.
function F.place(kind, team, x, y)
  local b = new_body(kind, team, x, y)
  return b
end

function F.remove(b)
  for i, o in ipairs(F.bodies) do if o == b then table.remove(F.bodies, i) return end end
end

function F.jack()
  for _, b in ipairs(F.bodies) do if b.kind == "jack" then return b end end
end

-- How long a shot flies before its centre comes down to its radius.
function F.flight_time(shot, r)
  local up = math.sqrt(2 * F.G * math.max(shot.apex - shot.z0, 0.01)) / F.G
  local down = math.sqrt(2 * (shot.apex - r) / F.G)
  return up + down, math.sqrt(2 * F.G * math.max(shot.apex - shot.z0, 0.01))
end

-- Where to land so that the boule stops at distance s from where it is let go (rolling on flat ground). On landing
-- the shot keeps part of its speed (the ground, F.terrain.keep, a little less or more), hops once (a sixth of its
-- fall), then rolls to a stop:  s = L + v * t_hop + v^2 / 2a,  with v = keep * L / T.
function F.landing_for(shot, s, r, mu)
  if shot.direct then return s end
  local T = F.flight_time(shot, r)
  local a = (mu or F.MU) * F.G
  local keep = shot.keep * (F.terrain and F.terrain.keep or 1)
  local vz_land = math.sqrt(2 * F.G * math.max(shot.apex - r, 0.01))
  local t_hop = vz_land > 0.6 and 2 * 0.15 * vz_land / F.G or 0
  local c = keep * keep / (2 * a * T * T)
  local b = 1 + keep * t_hop / T
  return (-b + math.sqrt(b * b + 4 * c * s)) / (2 * c)
end

-- Let a body go from (x, y) at the shot's height towards a landing point (lx, ly).
function F.launch(kind, team, x, y, lx, ly, shot)
  local b = new_body(kind, team, x, y)
  local T, vz = F.flight_time(shot, b.r)
  b.z, b.vz = shot.z0, vz
  b.vx, b.vy = (lx - x) / T, (ly - y) / T
  b.state, b.keep, b.landed = "air", shot.keep, false
  F.last_hit = nil  -- a new throw: no boule struck yet
  return b
end

local function event(kind, gain, x, y) F.events[#F.events + 1] = {kind = kind, gain = math.min(gain, 1), x = x, y = y} end

local function walls(b)
  local P = F.PITCH
  if b.x - b.r < P.x0 then b.x, b.vx = P.x0 + b.r, -b.vx * 0.35; event("wall", math.abs(b.vx), b.x, b.y) end
  if b.x + b.r > P.x1 then b.x, b.vx = P.x1 - b.r, -b.vx * 0.35; event("wall", math.abs(b.vx), b.x, b.y) end
  if b.y - b.r < P.y0 then b.y, b.vy = P.y0 + b.r, -b.vy * 0.35; event("wall", math.abs(b.vy), b.x, b.y) end
  if b.y + b.r > P.y1 then b.y, b.vy = P.y1 - b.r, -b.vy * 0.35; event("wall", math.abs(b.vy), b.x, b.y) end
end

-- Two bodies touching: pushed apart by their masses, and an impulse along the line between their centres.
-- A boule in the air hits one on the ground in 3D (a shot from above); the one on the ground only moves along it.
-- A boule against a standing tin: a cylinder, hit side-on at any height up to its top. The tin flies off,
-- turning, and lies where it falls.
local function hit_tin(ball, tin)
  if tin.knocked then return end
  local dx, dy = tin.x - ball.x, tin.y - ball.y
  local rr = ball.r + tin.r
  if dx * dx + dy * dy >= rr * rr or ball.z - ball.r > F.H_TIN then return end
  local d = math.max(math.sqrt(dx * dx + dy * dy), 0.01)
  local nx, ny = dx / d, dy / d
  local sp = math.max(math.sqrt(ball.vx * ball.vx + ball.vy * ball.vy), 0.8)
  tin.knocked, tin.state, tin.landed = true, "air", true
  tin.vx, tin.vy, tin.vz = ball.vx * 1.4 + nx * sp * 0.6, ball.vy * 1.4 + ny * sp * 0.6, 1.2 + sp * 0.5
  tin.z, tin.keep, tin.spin_v = 2, 0.4, (looks:float() - 0.5) * 30
  ball.vx, ball.vy = ball.vx * 0.85, ball.vy * 0.85
  event("tin", sp / 3, tin.x, tin.y)
end

local function collide(a, b)
  if a.dead or b.dead then return end
  if a.kind == "tin" or b.kind == "tin" then
    if a.kind == "tin" and b.kind ~= "tin" then hit_tin(b, a)
    elseif b.kind == "tin" and a.kind ~= "tin" then hit_tin(a, b) end
    return
  end
  local az, bz = a.z, b.z
  local dx, dy, dz = b.x - a.x, b.y - a.y, bz - az
  local rr = a.r + b.r
  local d2 = dx * dx + dy * dy + dz * dz
  if d2 >= rr * rr or d2 < 1e-9 then return end
  local d = math.sqrt(d2)
  local nx, ny, nz = dx / d, dy / d, dz / d
  local ia, ib = 1 / a.m, 1 / b.m
  local push = (rr - d) / (ia + ib)
  a.x, a.y = a.x - nx * push * ia, a.y - ny * push * ia
  b.x, b.y = b.x + nx * push * ib, b.y + ny * push * ib
  if a.state == "air" then a.z = a.z - nz * push * ia end
  if b.state == "air" then b.z = b.z + nz * push * ib end
  local rv = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny + (b.vz - a.vz) * nz
  if rv >= 0 then return end
  for _, pair in ipairs({{a, b}, {b, a}}) do  -- a still boule struck: where it stood (for a carreau)
    local struck, by = pair[1], pair[2]
    if struck.kind == "boule" and struck.state == "rest" and not F.last_hit then
      F.last_hit = {target = struck, shooter = by, x = struck.x, y = struck.y}
    end
  end
  local e = (a.kind == "jack" or b.kind == "jack") and 0.6 or 0.82
  local j = -(1 + e) * rv / (ia + ib)
  a.vx, a.vy, a.vz = a.vx - nx * j * ia, a.vy - ny * j * ia, a.vz - nz * j * ia
  b.vx, b.vy, b.vz = b.vx + nx * j * ib, b.vy + ny * j * ib, b.vz + nz * j * ib
  for _, o in ipairs({a, b}) do
    if o.state ~= "air" then o.vz = 0; o.state = "roll" end
  end
  event((a.kind == "jack" or b.kind == "jack") and "toc" or "clac", -rv / 4, (a.x + b.x) / 2, (a.y + b.y) / 2)
end

local function step_body(b, h, terrain)
  if b.dead or b.state == "rest" then return end
  if b.kind == "tin" then  -- a tin knocked flying: ballistic, turning, and it stays where it lands
    b.vz = b.vz - F.G * h
    b.x, b.y, b.z = b.x + b.vx * h, b.y + b.vy * h, b.z + b.vz * h
    b.spin = b.spin + (b.spin_v or 0) * h
    if b.z <= 0 then
      b.z = 0
      if b.vz < -0.8 then b.vz = -b.vz * 0.3; b.vx, b.vy = b.vx * 0.5, b.vy * 0.5; event("tin", 0.3, b.x, b.y)
      else b.vx, b.vy, b.vz, b.state, b.spin = 0, 0, 0, "rest", 90 end
    end
    return
  end
  if b.state == "air" then
    b.vz = b.vz - F.G * h
    b.x, b.y, b.z = b.x + b.vx * h, b.y + b.vy * h, b.z + b.vz * h
    if b.z <= b.r then
      b.z = b.r
      if not b.landed then  -- the first touch of the sauló takes most of the speed
        b.landed = true
        b.vx, b.vy = b.vx * b.keep * terrain.keep, b.vy * b.keep * terrain.keep
        event("land", -b.vz / 3, b.x, b.y)
      end
      if b.vz < -0.6 then b.vz = -b.vz * 0.15 else b.vz, b.state = 0, "roll" end
    end
  else
    local s = math.sqrt(b.vx * b.vx + b.vy * b.vy)
    local dec = (b.kind == "jack" and 2.2 or 1) * terrain.mu * F.G * h
    if s <= dec then
      b.vx, b.vy, b.state = 0, 0, "rest"
    else
      local k = (s - dec) / s
      local turn = (math.random() - 0.5) * 2 * JITTER * terrain.bumps * math.min(s, 1)
      local c, sn = math.cos(turn), math.sin(turn)
      b.vx, b.vy = (b.vx * c - b.vy * sn) * k, (b.vx * sn + b.vy * c) * k
      b.x, b.y = b.x + b.vx * h, b.y + b.vy * h
    end
  end
  walls(b)
end

function F.step(terrain)
  F.events = {}
  local list = F.bodies
  -- as many substeps as the fastest body needs to move less than half a boule's radius each (1 to 4): rolling
  -- slowly costs a quarter of a flight
  local fast = 0
  for _, b in ipairs(list) do
    if b.state ~= "rest" then fast = math.max(fast, math.abs(b.vx) + math.abs(b.vy) + math.abs(b.vz)) end
  end
  local sub = math.max(1, math.min(MAX_SUB, math.ceil(fast / 0.75)))
  local h = 1 / sub
  for _ = 1, sub do
    for _, b in ipairs(list) do step_body(b, h, terrain) end
    for i = 1, #list do
      for j = i + 1, #list do
        local a, b = list[i], list[j]
        if a.state ~= "rest" or b.state ~= "rest" then collide(a, b) end
      end
    end
  end
end

function F.moving()
  for _, b in ipairs(F.bodies) do if not b.dead and b.state ~= "rest" then return true end end
  return false
end

-- Distance from the jack to a boule's nearest point, as a tape measures it (units).
function F.gap(b, jack)
  jack = jack or F.jack()
  return math.sqrt((b.x - jack.x) ^ 2 + (b.y - jack.y) ^ 2) - b.r - jack.r
end

-- The boules on the ground, nearest the jack first.
function F.ranking()
  local jack, list = F.jack(), {}
  if not jack then return list end
  for _, b in ipairs(F.bodies) do
    if b.kind == "boule" and not b.dead then list[#list + 1] = b end
  end
  table.sort(list, function(a, b) return F.gap(a, jack) < F.gap(b, jack) end)
  return list
end

return F
