-- A conversation in a place: the place's picture as the background (BG3, a 240x160 bitmap) and the story's box.
--   scene.go(historia, {fondo = "FONDO_BAR", knot = "cap2_bar", anim = "lata", done = fn})

local H = {}
local args, timer = {}, 0
local lid = {x = 96, y = 16, on = false}

function H.enter(a)
  args, timer = a, 0
  bg(2)
  bg(3, {image = args.fondo, prio = 3, wrap = false})
  palette("OBJ", true)
  lid.on = args.anim == "lata"
  lid.x = 96
  STORY:go(args.knot)
end

function H.leave() bg(3) end

function H.update()
  timer = timer + 1
  if lid.on and timer > 40 then  -- the lid comes off: Tina opens the tin
    if timer == 41 then sfx("LATA", 0.6) end
    lid.x = lid.x + (560 - lid.x) * 0.08
  end
  story_step()
  if STORY:update() == "done" or not STORY:running() then
    store("story", STORY.vars)
    if args.done then args.done() end
  end
end

function H.draw()
  if lid.on then img("TAPA", math.floor(lid.x), lid.y, {scale = 2}) end
  STORY:draw()
end

return H
