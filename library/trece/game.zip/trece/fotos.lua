-- Chapter 5's game of differences: the print on the bar's wall and the newspaper's clipping, side by side. Five things
-- differ (tools/scenes.py, FOTO_DIFS). The d-pad moves the cursor, A marks, B shows one not yet found (three wrong marks
-- in a row do it by themselves). The last one found, the dog's tail, is the one that matters.
--   scene.go(fotos, {done = fn})

local lang = require("lang")

local K = {}

-- Where each difference is in the 200x112 photo, in the order of FOTO_DIFS: a cigarette end, the referee's watch, a
-- pair of light trousers in the crowd, chalk on Remei's boule, the tail.
local DIFFS = {{x = 103, y = 99}, {x = 183, y = 64}, {x = 63, y = 16}, {x = 76, y = 78}, {x = 12, y = 95}}
local PHOTO_W, PHOTO_H = 200, 112
local SCALE = 1.19                        -- two photos of 238 px across the screen's 480
local OX, OY = {1, 241}, 70               -- where each photo's corner is
local REACH = 15                          -- photo pixels from a difference that count as finding it
local INK, PAPER, GOLD = 0xFFF4DC, 0x2A1E18, 0xFFD040

local args, timer, found, count, misses, hint, cx, cy, finished_at = {}, 0, {}, 0, 0, 0, 240, 140, nil

function K.enter(a)
  args, timer, found, count, misses, hint, cx, cy, finished_at = a or {}, 0, {}, 0, 0, 0, 240, 140, nil
  bg(2)
  bg(3)
  for y = 0, H - 1 do line_backdrop(y, 0x120C0A) end
end

function K.leave() line_off() end

-- The cursor's place in a photo's own pixels (it works on whichever photo it is over).
local function photo_pos(px, py)
  local ox = px < 240 and OX[1] or OX[2]
  return (px - ox) / SCALE, (py - OY) / SCALE
end

local function first_missing()
  for i = 1, #DIFFS do if not found[i] then return i end end
end

local function mark()
  local lx, ly = photo_pos(cx, cy)
  for i, d in ipairs(DIFFS) do
    if not found[i] and (lx - d.x) ^ 2 + (ly - d.y) ^ 2 <= REACH * REACH then
      found[i], count, misses = true, count + 1, 0
      sfx("CLAC", 0.5)
      return
    end
  end
  misses = misses + 1
  sfx("TOC", 0.4)
  if misses >= 3 then hint, misses = 120, 0 end
end

local function steer()
  local fast = function(b) return btnt(b) > 20 and 6 or 2.5 end
  if btn("left") then cx = cx - fast("left") end
  if btn("right") then cx = cx + fast("right") end
  if btn("up") then cy = cy - fast("up") end
  if btn("down") then cy = cy + fast("down") end
  cx = math.max(OX[1], math.min(OX[2] + PHOTO_W * SCALE, cx))
  cy = math.max(OY, math.min(OY + PHOTO_H * SCALE, cy))
end

function K.update()
  timer = timer + 1
  if finished_at then
    if timer - finished_at > 100 or (timer - finished_at > 30 and btnp("a")) then args.done() end
    return
  end
  if AUTO then  -- the bench: every so often the cursor goes to the next one and marks it
    if timer % 20 == 0 then
      local i = first_missing()
      cx, cy = OX[1] + DIFFS[i].x * SCALE, OY + DIFFS[i].y * SCALE
      mark()
    end
  else
    steer()
    if btnp("a") then mark() end
    if btnp("b") then hint = 90 end
  end
  if hint > 0 then hint = hint - 1 end
  if count == #DIFFS then finished_at = timer; hint = 0 end
end

function K.found() return count end  -- (the tests read it)

local function ring(x, y, r, colour)  -- a coloured ring between two dark ones: it reads on black and on white dots
  circ(x, y, r + 1, PAPER, false)
  circ(x, y, r, colour, false)
  circ(x, y, r - 1, PAPER, false)
end

function K.draw()
  text(lang.tr("fotos_title"), SCREEN_W // 2, 22, {font = "marcador", color = INK, outline = PAPER, align = "center"})
  for k = 1, 2 do  -- the paper behind each photo, then the photo
    rect(OX[k] - 1, OY - 3, PHOTO_W * SCALE + 2, PHOTO_H * SCALE + 6, 0xE2DAC4)
    img(k == 1 and "FOTO_A" or "FOTO_B", OX[k], OY, {scale = SCALE})
  end
  for i, d in ipairs(DIFFS) do
    if found[i] then
      for k = 1, 2 do ring(OX[k] + d.x * SCALE, OY + d.y * SCALE, REACH * SCALE * 0.8, 0x9AF07A) end
    end
  end
  if hint > 0 and (hint // 8) % 2 == 0 then  -- the next one not found, a wide blinking ring on both photos
    local i = first_missing()
    if i then
      for k = 1, 2 do ring(OX[k] + DIFFS[i].x * SCALE, OY + DIFFS[i].y * SCALE, REACH * SCALE * 1.7, GOLD) end
    end
  end
  if not finished_at then  -- the cursor, and its twin on the other photo
    local lx, ly = photo_pos(cx, cy)
    for k = 1, 2 do
      local x, y = OX[k] + lx * SCALE, OY + ly * SCALE
      local mine = (cx < 240) == (k == 1)
      ring(x, y, 9, mine and GOLD or 0xB08A30)
      if mine then
        for _, o in ipairs({{-1, 0}, {1, 0}, {0, -1}, {0, 1}}) do  -- the crosshair, outlined
          line(x - 15 + o[1], y + o[2], x + 15 + o[1], y + o[2], PAPER)
          line(x + o[2], y - 15 + o[1], x + o[2], y + 15 + o[1], PAPER)
        end
        line(x - 15, y, x + 15, y, GOLD)
        line(x, y - 15, x, y + 15, GOLD)
      end
    end
  end
  text(lang.tr(finished_at and "fotos_done" or "fotos_count", {n = count}), SCREEN_W // 2, 222,
       {font = "gran", color = finished_at and 0x9AF07A or GOLD, outline = PAPER, align = "center"})
  text(lang.tr("fotos_help"), SCREEN_W // 2, 284, {font = "marcador", color = 0xC8B8A0, outline = PAPER, align = "center"})
end

return K
