-- TRECE: a petanque story for the Cirera. Scenes: the title, the 1983 cutscene, chapter cards, conversations in
-- places, and the game on the pitch (juego.lua), in the order flujo.lua keeps. Art and sound are made by code
-- (tools/build.sh).
--
-- bench.txt in the game folder: "auto" plays game after game by itself, silent, and logs the frame times
-- ("auto sinhud" without the overlay); "cine" plays the 1983 cutscene again and again; "historia" plays the whole
-- story by itself.

local scene = require("scene")
local lang = require("lang")
local story = require("story")
local voice = require("voice")
local juice = require("juice")
local flujo = require("flujo")
local saves = require("saves")

AUTO, NOHUD = false, false
MATCHES = 0                        -- games finished (the tests read it)

-- Each one's voice (lib/voice): the same blip, at their pitch, one every three letters as the line types. Remei is
-- 78 and low, Tina fifteen and high, Ximo the lowest.
local PITCH = {Remei = 0.75, Tina = 1.35, Quim = 0.9, Paqui = 1.1, Pol = 1.2, Ximo = 0.65}
local VOICES = {}
local function voice_of(who)
  local v = VOICES[who]
  if not v then
    v = voice.new({sound = "BLIP", pitch = PITCH[who] or 1, spread = 2, every = 3, gain = 0.5})
    VOICES[who] = v
  end
  return v
end
local function blip(ch)  -- the story's typing calls it letter by letter: the voice of whoever is speaking
  local l = STORY and STORY:line()
  voice_of(l and l.who or "Remei"):say(ch)
end

local PORTRAITS = {
  Remei = "RET_REMEI_NORMAL", Remei_seria = "RET_REMEI_SERIA", Remei_risa = "RET_REMEI_RISA",
  Tina = "RET_TINA_NORMAL", Tina_sorpresa = "RET_TINA_SORPRESA", Tina_burla = "RET_TINA_BURLA",
  Quim = "RET_QUIM_NORMAL", Quim_grito = "RET_QUIM_GRITO",
  Paqui = "RET_PAQUI_NORMAL", Paqui_risa = "RET_PAQUI_RISA",
  Pol = "RET_POL_NORMAL", Pol_burla = "RET_POL_BURLA", Pol_sorpresa = "RET_POL_SORPRESA",
  Ximo = "RET_XIMO_NORMAL", Ximo_seria = "RET_XIMO_SERIA", Ximo_risa = "RET_XIMO_RISA",
}

-- What the story saved, kept only where it has the shape the story expects: a wrong value would stop it at that line.
local STORY_LISTS = {seen = "number", taken = "boolean", seq = "number"}
local function restore_story(vars, saved)
  if type(saved) ~= "table" then return end
  for k, v in pairs(saved) do
    local kind = STORY_LISTS[k]
    if kind and type(v) == "table" then
      for name, value in pairs(v) do
        if type(name) == "string" and type(value) == kind then vars[k][name] = value end
      end
    elseif not kind and (vars[k] == nil or type(vars[k]) == type(v)) then
      vars[k] = v
    end
  end
end

-- The story is written once per language (story/es.txt, story/ca.txt); a language without one reads Spanish.
function new_story()
  local path = "story/" .. lang.code .. ".txt"
  if not file(path) then path = "story/es.txt" end
  local s = story.new(file(path), {
    name = path:match("[^/]+$"),
    ui = {font = "main", color = 0xF4E6C8, name_color = 0xFFB060, choice_color = 0xC8B8A0, pick_color = 0xFFF4DC,
          box = 0x1E1612, border = 0xD8B878, portraits = PORTRAITS, blip = blip, speed = 1,
          y = 198, h = 114},
  })
  restore_story(s.vars, stored("story"))
  return s
end

-- One sound for the place (cicadas, crickets, the crowd), looping; ambient(nil) stops it.
local amb, amb_id = nil, nil
function ambient(id, gain)
  if id == amb_id then return end
  if amb then sfx_stop(amb) end
  amb, amb_id = id and sfx(id, gain or 0.25, {loop = true}) or nil, id
end

-- The story by itself (benches and tests): every 40 ticks the next line, or the first choice.
AUTO_STORY = false
local story_ticks = 0
function story_step()
  if not AUTO_STORY then return end
  story_ticks = story_ticks + 1
  if story_ticks % 40 == 0 and STORY:running() then
    if STORY:choices() then STORY:choose(1) else STORY:next() end
  end
end

local frames, worst, since = 0, 0, 0

function _init()
  saves.open()
  local bench = file("bench.txt")
  AUTO = bench ~= nil and bench:find("auto") ~= nil
  NOHUD = bench ~= nil and bench:find("sinhud") ~= nil
  lang.load()  -- strings.csv, in the console's language
  volume(AUTO and 0 or 0.6)
  sound("BLIP", {wave = "square", freq = 760, duty = 0.25, sustain = 0.01, decay = 0.03, volume = 0.12})
  STORY = new_story()
  local scenes = {titulo = require("titulo"), cine = require("cine83"), tarjeta = require("tarjeta"),
                  historia = require("historia"), juego = require("juego"), fotos = require("fotos"),
                  creditos = require("creditos"), rapida = require("rapida")}
  flujo.setup(scenes)
  if bench and bench:find("historia") then  -- the whole story by itself, silent: every scene, every game
    AUTO, AUTO_STORY = true, true
    volume(0)
    store("story", nil)
    STORY = new_story()
    flujo.run(tonumber(bench:match("historia%s+(%d+)")) or 1)  -- "historia 11": from that step on
  elseif bench and bench:find("cine") then  -- the 1983 cutscene again and again, silent, to measure it
    AUTO = true
    volume(0)
    local function again() scene.go(scenes.cine, {done = again}) end
    again()
  elseif AUTO then
    scene.go(scenes.juego, {terreno = "plaza", rival = "quim", goal = 7})
  else
    scene.go(scenes.titulo, {pick = flujo.pick})
  end
end

function _update()
  saves.update()
  juice.update()  -- (the jolts of the blows wear off)
  scene.update()
  if AUTO then  -- frames a second over the last 600, and the slowest frame's update + draw + picture
    frames = frames + 1
    local u, d, pic, mem = perf()
    worst = math.max(worst, (u or 0) + (d or 0) + (pic or 0))
    if frames % 600 == 0 then
      local fps = 600 / math.max(t() - since, 0.001)
      log(string.format("bench: %.1f fps, worst %.1f ms, lua %d KB (%s)", fps, worst, math.floor(mem or 0),
                        tostring(state)))
      since, worst = t(), 0
    end
  end
end

function _draw()
  scene.draw()
  if saves.failed() then
    text(lang.tr("save_failed"), SCREEN_W // 2, 2, {font = "marcador", color = 0xFFE070, outline = 0x2A1E18, align = "center"})
  end
end
