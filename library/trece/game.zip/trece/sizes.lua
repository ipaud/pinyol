-- made by tools/objects.py: the diameters (pixels) of each frame of the boule and jack sheets
return {boule = {2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14, 16, 18, 20, 24, 28, 32}, boliche = {1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 14, 16},
        lata = {3, 4, 5, 6, 7, 8, 10, 12, 14, 16, 20, 24, 28, 32},
        cell = 32, jack_cell = 16}
