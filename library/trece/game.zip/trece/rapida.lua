-- The quick game's setup: who to play, where, and how (one against one, or in pairs with Tina). Up and down pick a row,
-- left and right change it, A on "start" plays, B goes back to the title. When a game ends it comes back here.
--   scene.go(rapida, {play = function(setup) ... end, back = fn})     setup = {terreno, rival, doubles}

local lang = require("lang")
local R = require("rival")
local D = require("dificultad")

local K = {}

local RIVALS = {"quim", "paqui", "pol", "ximo"}
local TERRAINS = {"plaza", "playa", "riera", "revetlla"}
local PARTNER = {quim = "paqui", paqui = "quim", pol = "ximo", ximo = "pol"}   -- who plays with the rival in pairs
local ROWS = {"rival", "pista", "modo", "dif", "start"}
local INK, PAPER, GOLD, DIM = 0xFFF4DC, 0x2A1E18, 0xFFE070, 0xC8B8A0

local args, row = {}, 1
local pick = {rival = 1, pista = 1, modo = 1}   -- what each row is on (kept between games)

function K.enter(a)
  args, row = a or {}, 1
  bg(2)
  bg(3)
  for y = 0, H - 1 do line_backdrop(y, 0x120C0A) end
end

function K.leave() line_off() end

local function cycle(name, n, d) pick[name] = (pick[name] - 1 + d) % n + 1 end

function K.setup()
  local rival = RIVALS[pick.rival]
  local setup = {terreno = TERRAINS[pick.pista], rival = rival}
  if pick.modo == 2 then
    setup.rival = nil
    setup.doubles = {partner = "Tina", rivals = {rival, PARTNER[rival]}, per = 4, handicap = 1}
    if setup.terreno == "revetlla" then setup.dog = {mene = 3, knot = "cap6_perro"} end  -- Llampet, as in the final
  end
  return setup
end

function K.update()
  if btnp("up") then row = (row - 2) % #ROWS + 1 end
  if btnp("down") then row = row % #ROWS + 1 end
  local d = (btnp("right") and 1 or 0) - (btnp("left") and 1 or 0)
  local name = ROWS[row]
  if d ~= 0 then
    if name == "rival" then cycle("rival", #RIVALS, d)
    elseif name == "pista" then cycle("pista", #TERRAINS, d)
    elseif name == "modo" then cycle("modo", 2, d)
    elseif name == "dif" then D.next(); if d < 0 then D.next() end end   -- three levels: back is two forward
  end
  if btnp("a") then
    if name == "start" then args.play(K.setup())
    elseif name == "modo" then cycle("modo", 2, 1)
    elseif name == "dif" then D.next()
    elseif name == "rival" then cycle("rival", #RIVALS, 1)
    elseif name == "pista" then cycle("pista", #TERRAINS, 1) end
  end
  if btnp("b") then args.back() end
end

local function value(name)
  if name == "rival" then return R.people[RIVALS[pick.rival]].name
  elseif name == "pista" then return lang.tr("pista_" .. TERRAINS[pick.pista])
  elseif name == "modo" then return lang.tr("modo_" .. pick.modo)
  elseif name == "dif" then return lang.tr(D.get().key) end
  return lang.tr("rapida_start")
end

function K.draw()
  text(lang.tr("title_quick"), SCREEN_W // 2, 30, {font = "gran", color = 0xFFE7A0, gradient = 0xFFB040, outline = PAPER,
                                                    align = "center"})
  for i, name in ipairs(ROWS) do
    local y = 90 + (i - 1) * 36
    local on = i == row
    if name ~= "start" then
      text(lang.tr("rapida_" .. name), 90, y, {font = "marcador", color = DIM, outline = PAPER})
      text((on and "< " or "  ") .. value(name) .. (on and " >" or ""), 390, y,
           {font = "marcador", color = on and GOLD or INK, outline = PAPER, align = "right"})
    else
      text((on and "> " or "  ") .. value(name), SCREEN_W // 2, y + 10,
           {font = "marcador", color = on and GOLD or INK, outline = PAPER, align = "center"})
    end
  end
  text(lang.tr("rapida_help"), SCREEN_W // 2, 290, {font = "main", color = DIM, outline = PAPER, align = "center"})
end

return K
