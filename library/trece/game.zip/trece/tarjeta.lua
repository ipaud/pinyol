-- A chapter's card: its number and its name over black, a few seconds (A skips).
--   scene.go(tarjeta, {top = "Capítulo 1", name = "La caja de galletas", done = fn})

local lang = require("lang")

local K = {}
local args, timer = {}, 0

function K.enter(a)
  args, timer = {top = lang.tr(a.top), name = lang.tr(a.name), done = a.done}, 0
  bg(2)
  bg(3)
  for y = 0, H - 1 do line_backdrop(y, 0x120C0A) end
end

function K.leave() line_off() end

function K.update()
  timer = timer + 1
  if timer > 200 or (timer > 30 and btnp("a")) then args.done() end
end

function K.draw()
  local k = math.min(1, timer / 40)
  text(args.top, SCREEN_W // 2, 116, {font = "marcador", color = 0xC8B8A0, align = "center",
                                       chars = math.floor(#args.top * k + 0.5)})
  if timer > 30 then
    text(args.name, SCREEN_W // 2, 148, {font = "gran", color = 0xFFE7A0, gradient = 0xFFB040, outline = 0x2A1E18,
                                          align = "center", chars = math.floor((timer - 30) / 2)})
  end
end

return K
