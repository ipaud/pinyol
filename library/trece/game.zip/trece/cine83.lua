-- The opening: the night of Sant Joan, 1983. Twelve shots on a timeline, the square in sepia, Remei's hands at 35,
-- the last boule, the tape, a dog nobody sees, the flash of the newspaper's camera; then the photo on the bar's wall
-- in 2026, the tin closed by older hands, and the title. START skips it.

local F = require("fisica")
local lang = require("lang")
local C = require("campo")
local U = require("hud")
local paleta = require("paleta")
local TERRENOS = require("terrenos")

local K = {}
local args, t = {}, 0
local calm = false  -- the console set to less flashing: the old film does not flicker and the camera's flash is mild
local jack, mine, his, flying
local dog = {x = -40, y = 0, frame = 0, on = false}
local ink = {font = "main", color = 0xF4E6C8, outline = 0x1A120C}

-- Shots: when each starts (ticks). The scene moves on by itself; each shot is code below.
local S = {black = 0, wide = 240, hand = 480, ximo = 720, throw = 900, low = 1260, tape = 1500, words = 1760,
           flash = 1980, wall = 2160, tin = 2460, title = 2760, finish = 2900}
local sheets = {}

local function at(name) return t >= S[name] end
local function since(name) return t - S[name] end

function K.enter(a)
  args, t = a or {}, 0
  calm = settings().reduce_flashing
  sheets.dog = sheet("PERRO")
  C.init(TERRENOS.plaza83, "MANOS_JOVEN")
  F.reset()
  jack = F.launch("jack", 0, 252, 600, 252, 600, F.SHOTS[1])
  jack.state, jack.z = "rest", jack.r
  his = F.launch("boule", 2, 259, 604, 259, 604, F.SHOTS[1])   -- Ximo's, already there, very close
  his.state, his.z = "rest", his.r
  local other = F.launch("boule", 2, 236, 640, 236, 640, F.SHOTS[1])
  other.state, other.z = "rest", other.r
  local older = F.launch("boule", 1, 270, 572, 270, 572, F.SHOTS[1])
  older.state, older.z = "rest", older.r
  ambient("GRILLOS", 0.35)
  bg(3, {image = "PLAZA83", prio = 2, wrap = false})
  C.aim(256, 1000, 150, 0, C.FOV, 1)
  C.snap()
  for y = 0, H - 1 do line_backdrop(y, 0x000000) end
  show(0)                                     -- black first
end

function K.leave()
  line_off()
  show(ALL)
  fx_off()
  C.off()
  palette("OBJ", true)
  ambient(nil)
end

local weave = 0
local looks = require("rng").new(0xC183)   -- the film's grain is a look: it must not change a throw
local function film_grain()  -- the old film: the picture jumps a pixel now and then, the light flickers (not when calm)
  if t % 4 == 0 then weave = (looks:float() < 0.25) and (looks:float() < 0.5 and -1 or 1) or 0 end
  if not calm and looks:float() < 0.15 then fade("dark", ALL, looks:int(1, 3)) else fx_off() end
end

local function throw_last()  -- Remei's last boule, made to stop just short of the jack, a hair behind Ximo's
  local tx, ty = jack.x - 5.6, jack.y + 3.2
  local shot = F.SHOTS[2]
  local rx, ry = F.CIRCLE.x + 3, F.CIRCLE.y - 20
  local d = math.sqrt((tx - rx) ^ 2 + (ty - ry) ^ 2)
  local land = F.landing_for(shot, d, F.R_BOULE)
  mine = F.launch("boule", 1, rx, ry, rx + (tx - rx) / d * land, ry + (ty - ry) / d * land, shot)
  flying = mine
  sfx("SWING", 0.4)
end

function K.update()
  t = t + 1
  CINE_T = t
  if btnp("start") or (t > 60 and btnp("b")) then t = S.title end
  if t == S.black + 1 then show(0) end
  if t == S.wide then
    show(ALL)
    C.init(TERRENOS.plaza83, "MANOS_JOVEN")
    bg(3, {image = "PLAZA83", prio = 2, wrap = false})
    C.aim(256, 1010, 150, 0, C.FOV, 1); C.snap()
    C.aim(256, 900, 90, 0, C.FOV, 0.006)
    ambient("MURMULLO", 0.3)
  end
  if at("wide") and not at("wall") then film_grain() end
  if t == S.hand then
    C.from_circle(jack.x, jack.y, 1); C.snap()
    C.hand.on, C.hand.frame, C.hand.x, C.hand.y = true, 0, 128, 170
  end
  if at("hand") and not at("throw") then
    C.hand.y = C.hand.y + (70 - C.hand.y) * 0.08 + math.floor(math.sin(t / 25) * 0.6)
  end
  if t == S.throw then C.hand.frame = 1 end
  if at("throw") and not at("low") then
    local k = since("throw")
    if k < 20 then C.hand.y = 70 + k * k / 4 end                 -- down and back
    if k >= 20 and k < 50 then C.hand.y = 170 - (k - 20) * 4 end -- forward
    if k == 50 then throw_last(); C.hand.frame = 2 end
    if k == 56 then C.hand.frame = 3 end
    if k > 50 and k < 90 then C.hand.y = C.hand.y + (40 - C.hand.y) * 0.1 end
    if k >= 90 then C.hand.y = C.hand.y + 5 end
    if k > 130 then C.hand.on = false end
    if mine then
      F.step(F.terrain)
      for _, e in ipairs(F.events) do if e.kind == "land" then sfx("GRAVA", 0.6) end end
      if k > 66 then
        local dx, dy = mine.x - F.CIRCLE.x, mine.y - F.CIRCLE.y
        local n = math.max(1, math.sqrt(dx * dx + dy * dy))
        local back = 90 + (mine.state == "air" and mine.z * 0.9 or 0)
        C.aim(mine.x - dx / n * back, math.min(mine.y - dy / n * back, F.CIRCLE.y + 6), 38,
              math.deg(math.atan(dx, -dy)), C.FOV, 0.07)
      end
    end
  end
  if t == S.low then
    while F.moving() do F.step(F.terrain) end
    C.aim(jack.x - 4, jack.y + 34, 5, 0, C.FOV, 1); C.snap()
    ambient("GRILLOS", 0.35)
  end
  if t == S.tape then
    dog.on, dog.x, dog.y = true, jack.x - 26, jack.y + 6
  end
  if at("tape") and not at("words") and dog.on then  -- the dog crosses the corner of the picture, and nudges the jack
    local k = since("tape")
    if k > 70 and k < 120 then
      dog.x = dog.x + 0.5
      dog.frame = (k // 6) % 4
      if k == 104 then jack.x, jack.y = jack.x + 0.7, jack.y - 0.35 end
    elseif k >= 120 and k < 128 then dog.frame = 4
    elseif k >= 128 then dog.x, dog.frame = dog.x - 1.2, (k // 5) % 4 end
    if k > 200 then dog.on = false end
  end
  if t == S.words + 90 then ambient("MURMULLO", 0.55); sfx("PETARDO", 0.4) end
  if t == S.flash then sfx("FLASH", 0.7) end
  if at("flash") and not at("wall") then
    local k = since("flash")
    if k < 16 then fade("light", ALL, calm and math.min(16 - k, 5) or 16 - k) end
    if k == 8 then
      C.off()
      fx_off()
      line_off()
      bg(3, {image = "FOTO83", prio = 3, wrap = false})
      for y = 0, H - 1 do line_backdrop(y, 0x000000) end
    end
  end
  if t == S.wall then
    bg(3, {image = "FONDO_BAR", prio = 3, wrap = false})
    ambient("CIGARRAS", 0.2)
  end
  if t == S.tin then
    bg(3, {image = "FONDO_LATA", prio = 3, wrap = false})
    palette("OBJ", true)
    C.hand.on = false
  end
  if t == S.tin + 130 then sfx("LATA", 0.7) end
  if t == S.title then
    C.off()
    bg(3)
    for y = 0, H - 1 do line_backdrop(y, 0x120C0A) end
    ambient(nil)
  end
  if t >= S.finish or (at("title") and since("title") > 40 and btnp("a")) then args.done() end
  C.update()
  if weave ~= 0 and at("wide") and not at("flash") then  -- the film's weave: the whole view a pixel aside
    scroll(3, 512 - W / 2 + C.cam.a * 4.5 + weave, 0)
  end
end

local function typed(words, x, y, from, style)
  local n = math.max(0, math.floor((t - from) / 2))
  text(words, x, y, setmetatable({chars = n, width = SCREEN_W - x - 16}, {__index = style}))
end

function K.draw()
  if at("wide") and not at("flash") then C.draw() end
  if dog.on then
    local sx, sy, scale, vis = C.screen(dog.x, dog.y, 0)
    if vis then spr(1, sheets.dog, dog.frame, sx - 24, sy - 34, prio(0)) end
  end
  if not at("wide") then
    typed(lang.tr("cine_date"), 40, 150, 30, ink)
    typed(lang.tr("cine_night"), 40, 176, 120, ink)
  elseif at("hand") and not at("ximo") then
    rect(150, 12, 180, 40, 0x1A120C)
    box(152, 14, 176, 36, 0x8A6A40)
    text("BAIX 12 · 12 DALT", 240, 20, {font = "marcador", color = 0xF4E6C8, align = "center"})
    typed(lang.tr("cine_last"), 24, 280, S.hand + 60, ink)
  elseif at("ximo") and not at("throw") then
    local k = since("ximo")
    local x = math.max(300, 520 - k * 8)
    img("RET_XIMO83_NORMAL", x, 120)
    typed(lang.tr("cine_ximo"), 24, 252, S.ximo + 30, ink)
    typed(lang.tr("cine_dalt"), 24, 280, S.ximo + 80, ink)
  elseif at("tape") and not at("words") then
    local jx, jy = C.screen(jack.x, jack.y, 0)
    local hx, hy = C.screen(his.x, his.y, 0)
    local k = math.min(1, since("tape") / 60)
    line(jx * 2, jy * 2, (jx + (hx - jx) * k) * 2, (jy + (hy - jy) * k) * 2, 0xF0D040)
    line(jx * 2, jy * 2 + 1, (jx + (hx - jx) * k) * 2, (jy + (hy - jy) * k) * 2 + 1, 0xB08A20)
  elseif at("words") and not at("flash") then
    shade(0, 0, SCREEN_W, SCREEN_H)
    typed(lang.tr("cine_mm"), SCREEN_W // 2 - 150, 120, S.words, {font = "gran", color = 0xF4E6C8,
                                                                      outline = 0x1A120C, shake = 1})
    if since("words") > 70 then
      text(lang.tr("cine_point"), SCREEN_W // 2, 170, {font = "gran", align = "center", color = 0xFFB060,
                                                     outline = 0x1A120C, shake = 2})
    end
  elseif at("flash") and not at("wall") and since("flash") >= 8 then
    text("La Veu de la Cirera", SCREEN_W // 2, 14, {font = "diario", color = 0x1A1612, align = "center"})
    text("Dalt guanya per un mil·límetre", SCREEN_W // 2, 44, {font = "marcador", color = 0x1A1612,
                                                                align = "center"})
  elseif at("wall") and not at("tin") then  -- the photo shrinks into its frame on the bar's wall: 2026
    local k = math.min(1, since("wall") / 150)
    local e = 1 - (1 - k) ^ 3
    local scale = 2 + (0.34 - 2) * e
    local x, y = (0 + (46 - 0) * e), (0 + (34 - 0) * e)
    img("FOTO83", math.floor(x), math.floor(y), {scale = scale, alpha = 1 - e * 0.3})
    if k >= 1 then typed(lang.tr("cine_after"), 40, 280, S.wall + 160, ink) end
  elseif at("tin") and not at("title") then  -- older hands close the tin
    local k = since("tin")
    local lid_x = math.max(96, 560 - k * 4)
    img("TAPA", lid_x, 16, {scale = 2})
    if k > 136 then typed(lang.tr("cine_age"), 40, 280, S.tin + 140, ink) end
  elseif at("title") then
    local k = since("title")
    text("TRECE", SCREEN_W // 2, 110, {font = "gran", scale = 3, align = "center", color = 0xFFF0C0,
                                        gradient = 0xFF9A30, outline = 0x2A1E18, chars = math.floor(k / 8)})
  end
end

return K
