-- tiles: the world's blocks, put on the screen with `img` from the packed pictures of its tile set (prefix BG_ for the playroom, FT_ for the market; a set the data
-- does not have yet is the playroom's, tinted: core/worlds.lua). A floor top with two floor bodies under it is one picture, and runs of floor, shelves and boxes
-- are strips of 8, 4, 2 or 1 tiles, which spares most commands.
local K = require("core.const")
local L = require("core.level")
local W = require("core.worlds")
local Deco = require("core.deco")
local T = {}

local TILE = K.TILE
local FRAME = {["="] = 7, T = 6, a = 8, b = 9, c = 10, d = 11}
local FLOORISH = {["#"] = true, [">"] = true, ["<"] = true, P = true}

local plain, crate, one7, one6 = {frame = 0}, {frame = 6, dim = 0.6}, {frame = 7}, {frame = 6}
local black = {frame = 6, dim = 0.3} -- a black key
local HOP_S = 0.45 -- CT_HOP (110x37 board with chalk 1 2 3) shrunk to sit on one 32 px tile with a little overhang
local BLACKKEY = {[0] = true, [1] = true, [3] = true, [4] = true, [5] = true} -- which white keys (column % 7) carry a raised black key
local keyl, ramps = {frame = 0}, {{frame = 0}, {frame = 1}, {frame = 2}, {frame = 3}} -- (looks of the black key and the four ramp halves)
local hopl = {{frame = 0, scale_x = HOP_S, scale_y = HOP_S}, {frame = 1, scale_x = HOP_S, scale_y = HOP_S}}
local RAMP_I = {a = 1, b = 2, c = 3, d = 4}
local prefix, STRIP, BODY, RUNS
local NAMES = {KT = {SHELF = "COUNTER", TBOX = "CRATES"}, BG = {SHELF = "SHELF", TBOX = "TBOX"}, FT = {SHELF = "COUNTER", TBOX = "CRATES"}, CT = {SHELF = "COUNTER", TBOX = "CRATES"}} -- (the market's shelves are stall counters, its boxes crates)
local function build(pre, mul)
  prefix = pre
  plain.mul, crate.mul, one7.mul, one6.mul, black.mul = mul, mul, mul, mul, mul
  crate.frame, crate.dim = (pre == "FT") and 3 or (pre == "CT" and 4 or 6), (pre == "BG") and 0.6 or nil
  local tf0 = W.tile_frames or {}
  black.frame, black.dim = tf0.B or 6, (not tf0.B) and 0.3 or nil -- (a black key: the art's own block, else a darkened case) -- (an orange crate in the market, a darkened toy box in the playroom)
  local nm = NAMES[pre] or NAMES.BG
  local function strips(name, one) name = nm[name] return {{8, pre .. "_" .. name .. "8"}, {4, pre .. "_" .. name .. "4"}, {2, pre .. "_" .. name .. "2"}, one} end
  STRIP = {{8, pre .. "_FLOOR8"}, {4, pre .. "_FLOOR4"}, {2, pre .. "_FLOOR2"}, {1, pre .. "_FLOORCOL"}}
  BODY = {{8, pre .. "_BODY8"}, {4, pre .. "_BODY4"}, {2, pre .. "_BODY2"}, {1, pre .. "_BODY1"}}
  local tf = W.tile_frames or {}
  FRAME.H, FRAME.h = tf.H or 4, tf.h or 5
  RUNS = {["="] = strips("SHELF", {1, pre .. "_TILES", one7}), T = strips("TBOX", {1, pre .. "_TILES", one6})}
end

function T.init() end -- (the pictures are assets)

-- the pictures of a stretch of tiles only change when the camera crosses a tile: they are kept as a list (id, x, y, look...) and drawn again until it does
local cache, cache_key, looks = {}, nil, {}
local k_c0, k_c1, k_r0, k_r1, k_pre, k_mul, k_rev
local function emit(id, x, y, look)
  if look then -- (the shared `look` tables change between calls: each picture keeps its own, one per kind)
    local k = (look.frame or "") .. "|" .. (look.dim or "") .. "|" .. (look.mul or "") .. "|" .. (look.scale_x or "")
    local own = looks[k]
    if not own then own = {frame = look.frame, dim = look.dim, mul = look.mul, scale_x = look.scale_x, scale_y = look.scale_y} looks[k] = own end
    look = own
  end
  local n = #cache
  cache[n + 1], cache[n + 2], cache[n + 3], cache[n + 4] = id, x, y, look or false
  img(id, x, y, look)
end

local used = {}
local fcr, fbody = {}, {} -- for each visible column: the row of its floor column (a floor top with two bodies under it), or false
local belts = {}

-- the tiles that show: cam_x, cam_y is the screen's top-left in level pixels; returns how many pictures
function T.draw(cam_x, cam_y)
  if prefix ~= W.tile_prefix or plain.mul ~= W.tile_mul then build(W.tile_prefix, W.tile_mul) end
  local c0, c1 = math.max(0, math.floor(cam_x / TILE)), math.min(K.COLS - 1, math.floor((cam_x + K.W - 1) / TILE))
  local r0, r1 = math.max(0, math.floor(cam_y / TILE)), math.min(K.ROWS - 1, math.floor((cam_y + K.H - 1) / TILE))
  local g = L.grid
  local n = 0
  local rev, pm = L.rev or 0, plain.mul or false
  if cache_key and k_c0 == c0 and k_c1 == c1 and k_r0 == r0 and k_r1 == r1 and k_pre == prefix and k_mul == pm and k_rev == rev then
    for i = 1, #cache, 4 do img(cache[i], cache[i + 1], cache[i + 2], cache[i + 3] or nil) end
    n = #cache // 4
  else
  for k in pairs(looks) do looks[k] = nil end
  for i = #cache, 1, -1 do cache[i] = nil end
  for c = c0, c1 do
    local fr = false
    for r = r0, r1 do
      if FLOORISH[g[r][c]] then
        local up = L.at(c, r - 1)
        if r + 2 == K.ROWS - 1 and L.at(c, r + 1) == "#" and L.at(c, r + 2) == "#" then
          fr = r
          fbody[c] = not (up == " " or up == "=")
          break
        end
      end
    end
    fcr[c] = fr
  end
  local c = c0
  while c <= c1 do
    local fr = fcr[c]
    if fr then
      local run = 1
      while c + run <= c1 and fcr[c + run] == fr and fbody[c + run] == fbody[c] do run = run + 1 end
      local i = c
      while i < c + run do
        for _, st in ipairs(fbody[c] and BODY or STRIP) do
          if i + st[1] <= c + run then emit(st[2], i * TILE, fr * TILE, plain.mul and {mul = plain.mul} or nil) n = n + 1 i = i + st[1] break end
        end
      end
      c = c + run
    else
      c = c + 1
    end
  end
  -- the stage's black keys: a raised key on some white-key columns (KT_FLOORKEY frame 0), over the floor column
  if prefix == "KT" and Deco.has("KT_FLOORKEY") then
    for c = c0, c1 do
      if fcr[c] == K.FLOOR and g[K.FLOOR][c] == "P" and BLACKKEY[c % 7] then emit("KT_FLOORKEY", c * TILE, K.FLOOR * TILE, keyl) n = n + 1 end
    end
  end
  -- stacks of body stone under a ramp: three rows at a time, one picture (BODY1)
  for k in pairs(used) do used[k] = nil end
  for c = c0, c1 do
    local r = r0
    while r <= r1 do
      local fr = fcr[c]
      if g[r][c] == "#" and not (fr and r >= fr) and L.at(c, r - 1) ~= " " and L.at(c, r - 1) ~= "=" and L.at(c, r - 1) ~= "#" then
        local e = r
        while e + 1 <= r1 and g[e + 1][c] == "#" and not (fr and e + 1 >= fr) do e = e + 1 end
        local rr = r
        while rr + 2 <= e do
          emit(prefix .. "_BODY1", c * TILE, rr * TILE, plain.mul and {mul = plain.mul} or nil) n = n + 1
          used[rr * 512 + c], used[(rr + 1) * 512 + c], used[(rr + 2) * 512 + c] = true, true, true
          rr = rr + 3
        end
        r = e + 1
      else
        r = r + 1
      end
    end
  end
  for r = r0, r1 do
    local row = g[r]
    local c = c0
    while c <= c1 do
      local ch, fr = row[c], fcr[c]
      if ch == " " or (fr and r >= fr) or used[r * 512 + c] then
        c = c + 1
      elseif RUNS[ch] then -- a run of shelf or toy boxes: strips of 8, 4, 2 or 1
        local e = c
        while e < c1 and row[e + 1] == ch and not (fcr[e + 1] and r >= fcr[e + 1]) do e = e + 1 end
        local i = c
        while i <= e do
          local took = false
          for _, st in ipairs(RUNS[ch]) do
            if i + st[1] - 1 <= e then emit(st[2], i * TILE, r * TILE, st[3] or (plain.mul and {mul = plain.mul} or nil)) n = n + 1 i = i + st[1] took = true break end
          end
          if not took then i = i + 1 end
        end
        c = e + 1
      else
        local look = plain
        local alt = false
        if prefix == "CT" and RAMP_I[ch] and Deco.has("CT_RAMP_RB") then -- the chalk-rainbow ramps
          emit("CT_RAMP_RB", c * TILE, r * TILE, ramps[RAMP_I[ch]]) n = n + 1 alt = true
        elseif prefix == "CT" and (ch == "H" or ch == "h") and Deco.has("CT_HOP") then -- the hopscotch board: normal, cracked
          emit("CT_HOP", c * TILE + TILE // 2 - math.floor(55 * HOP_S), r * TILE - math.floor(3 * HOP_S), hopl[ch == "H" and 1 or 2]) n = n + 1 alt = true
        elseif ch == "K" then
          look = crate
        elseif ch == "B" then
          look = black
        elseif ch == "#" or ch == ">" or ch == "<" or ch == "P" then
          local up = L.at(c, r - 1)
          look.frame = (up == " " or up == "=") and 0 or 1
        else
          look.frame = ch == "W" and (2 + ((c * 7 + r * 3) % 4)) or FRAME[ch]
        end
        if not alt then
          emit(prefix .. "_TILES", c * TILE, r * TILE, look)
          n = n + 1
        end
        c = c + 1
      end
    end
  end
  cache_key, k_c0, k_c1, k_r0, k_r1, k_pre, k_mul, k_rev = true, c0, c1, r0, r1, prefix, pm, rev
  end
  -- the conveyor belts: the market's tiles have the belt (4 frames sliding, an end cap on each side); the playroom has none (a dark band with dashes as a fallback)
  local tk = ticks()
  local c = c0
  while c <= c1 do
    local ch = g[K.FLOOR][c]
    if ch == ">" or ch == "<" then
      local e = c
      while e < c1 and g[K.FLOOR][e + 1] == ch do e = e + 1 end
      local f = (tk // 5) % 4
      if ch == "<" then f = 3 - f end
      for i = c, e do
        local fr = 12 + f
        if prefix == "FT" then
          if i == c and L.at(i - 1, K.FLOOR) ~= ch then fr = 16 elseif i == e and L.at(i + 1, K.FLOOR) ~= ch then fr = 17 end
          plain.frame = fr
          img("FT_TILES", i * TILE, K.FLOOR * TILE, plain)
          n = n + 1
        end
      end
      if prefix ~= "FT" then
        local x0, w = c * TILE, (e - c + 1) * TILE
        rect(x0, K.FLOOR * TILE, w, 8, 0x3A3F5A)
        for i = 0, w // 32 - 1 do
          local px = (i * 32 + (ch == ">" and 1 or -1) * (tk // 2)) % w
          if px + 14 <= w then rect(x0 + px, K.FLOOR * TILE + 2, 14, 4, 0xFFD43A) end
        end
        n = n + 1 + w // 32
      end
      c = e + 1
    else
      c = c + 1
    end
  end
  return n
end

return T
